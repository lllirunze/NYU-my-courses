function _1(md){return(
md`# From Questions to Data Transformations - Exercise`
)}

function _2(md){return(
md`
In this exercise you will have to do two things (1) transform the question into something that can be actually computed using the data and (2) write the code to generate the information that is needed to answer the question. Both steps are important.

For the first step, you should feel free to interpret the question any way you like, but make sure you rephrase it in a way that includes direct references to the data attributes (read below for more details). A good "translation" of a domain question is a data question that can be readily transformed into code and that is not ambiguous. For example, if the domain question is "What are the hotspots of vehicle collisions in NYC?", then one possible data question is "What are the top 5 zip codes in NYC that have highest number of people injurred or killed in collisions?"

The exercise will be graded according to these parameters:

1. Is the data question an actual translation of the domain question?
2. Is the data question specific enough that it can be readily translated into code without major ambiguity?
3. Does the code provided produce the right information from the data?

To get started, **create a fork** of this notebook, using the fork button at the top right (next to share). When you click on fork, you will be prompted to select visibility options. Set the visibility to **"unlisted"**. When you are finished, submit the link to your notebook without changing the visibility.`
)}

function _3(md){return(
md`## Data`
)}

function _4(md){return(
md`We'll be using NYC vehicle collision data from [NYC Open Data](https://data.cityofnewyork.us/Public-Safety/Motor-Vehicle-Collisions-Crashes/h9gi-nx95). I've uploaded a modified subset of this data for 2019 as a [Gist](https://gist.github.com/DanielKerrigan/d01fc44e4cee0c5c2434f464497ba260). Each row is a crash and contains the date, time, borough, zip code, number of people injured, number of people killed, and the main factor. Some rows have missing values.`
)}

function _5(md){return(
md`We can use use [\`d3.csv\`](https://github.com/d3/d3-fetch#csv) to load the dataset. We will pass it a function that gets called for every row and converts the fields to the right type. For example, we turn the date and time strings into one [Date](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date) object.`
)}

function _url(){return(
'https://gist.githubusercontent.com/DanielKerrigan/d01fc44e4cee0c5c2434f464497ba260/raw/982bcefac49be9fd29887cbaead524e033f6dad4/nyc-collisions-2019-reduced.csv'
)}

function _data(d3,url){return(
d3.csv(url, crash => ({
    // combine the date and time strings into one Date object
    dateTime: d3.timeParse('%m/%d/%Y %H:%M')(crash.date + ' ' + crash.time),
    borough: crash.borough,
    zip: crash.zip,
    injured: +crash.injured, // + converts the string to an int
    killed: +crash.killed,
    cause: crash.cause
}))
)}

function _8(md){return(
md`## Q1: How did the situation change over time?

Translate the domain question into a data question. To do that, ask yourself the following: What do you mean by situation? What do you mean by change?`
)}

function _9(md){return(
md`Answer:    
How many collisions occur on each day in NYC?   
- 'situation' means the number of collisions in one day.
- 'change' means collisions in different days.`
)}

function _10(d3,data){return(
d3.rollup(
  data,
  g => g.length,
  d => d3.timeFormat('%Y-%m-%d')(d.dateTime)
)
)}

function _11(md){return(
md`## Q2: Where are the most dangerous spots in NYC?`
)}

function _12(md){return(
md`Translate the domain question into a data question. To do that, ask yourself the following: What do you mean by dangerous? What do you mean by spots?`
)}

function _13(md){return(
md`Answer:    
What are the top-5 zip codes in NYC with the highest sum of injuries and deaths?
- 'dangerous' means the sum of injuries and deaths.
- 'spots' means zip codes.`
)}

function _14(d3,data){return(
d3.rollups(
  data.filter(d => d.zip !== ""),
  g => d3.sum(g, collision => collision.injured+collision.killed),
  d => d.zip
).map(([zip, injuredAndKilled]) => {
  return {zip, injuredAndKilled};
}).toSorted(
  (a, b) => d3.descending(a.injuredAndKilled, b.injuredAndKilled)
).slice(0, 5).map(d => d.zip)
)}

function _15(md){return(
md`## Q3: What are the main causes behind the collisions?

Translate the domain question into a data question. To do that ask yourself the following questions: What do you mean by main? What do you mean by causes?`
)}

function _16(md){return(
md`Answer:    
What are the top-5 causes of collisions in NYC?
- 'main' means top-5 causes.
- 'causes' means the attributes of data.`
)}

function _17(d3,data){return(
d3.rollups(
  data.filter(d => d.zip !== ""),
  g => g.length,
  d => d.cause
).map(([cause, collisions]) => {
  return {cause, collisions};
}).toSorted(
  (a, b) => d3.descending(a.collisions, b.collisions)
).slice(0, 5).map(d => d.cause)
)}

function _18(md){return(
md`---
## Appendix`
)}

function _d3(require){return(
require("d3@7")
)}

export default function define(runtime, observer) {
  const main = runtime.module();
  main.variable(observer()).define(["md"], _1);
  main.variable(observer()).define(["md"], _2);
  main.variable(observer()).define(["md"], _3);
  main.variable(observer()).define(["md"], _4);
  main.variable(observer()).define(["md"], _5);
  main.variable(observer("url")).define("url", _url);
  main.variable(observer("data")).define("data", ["d3","url"], _data);
  main.variable(observer()).define(["md"], _8);
  main.variable(observer()).define(["md"], _9);
  main.variable(observer()).define(["d3","data"], _10);
  main.variable(observer()).define(["md"], _11);
  main.variable(observer()).define(["md"], _12);
  main.variable(observer()).define(["md"], _13);
  main.variable(observer()).define(["d3","data"], _14);
  main.variable(observer()).define(["md"], _15);
  main.variable(observer()).define(["md"], _16);
  main.variable(observer()).define(["d3","data"], _17);
  main.variable(observer()).define(["md"], _18);
  main.variable(observer("d3")).define("d3", ["require"], _d3);
  return main;
}
