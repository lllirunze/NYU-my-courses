import define1 from "./a33468b95d0b15b0@817.js";

function _1(md){return(
md`# Graphical Encoding - Exercise

In this exercise, we have a dataset that contains the unemployment rate for each state for December 2019. Your task is to visualize this data in **4 different ways** using D3 (e.g., Bar Chart, Choropleth Map, Bubble Chart, Pie Chart). This exercise is about exploring possibilities, so it's okay if some of your visualizations aren't the most effective, as long as they are still appropriate. For example, while speedometer charts may not be the most effective way to represent unemployment rates, they can still be used in this context. However, a line chart would not be appropriate for this type of data since it typically represents trends over time.

Make sure to explore the largest possible set of marks and channels. Your solutions should include at least **3 different channels** and **3 different marks**.

To get started, create a fork of this notebook. When you are finished, **do not** publically publish your notebook. If you are using the "Classic" notebook interface, then go to the menu at the top with the three dots and click "Enable link sharing." If you are using the newer notebook interface, then click "Publish" and set the visibility to unlisted. You can then submit the link on Brightspace.`
)}

function _2(md){return(
md`## Data

The map data comes from [here](https://eric.clst.org/tech/usgeojson/) and is based on boundaries given by the U.S. Census Bureau.`
)}

function _usaGeo(FileAttachment){return(
FileAttachment('gz_2010_us_040_00_20m.json').json()
)}

function _4(md){return(
md`Also, you may find it handy to have a mapping from state name to abbreviation as well as the regions for your tasks. The states are categorized into regions according to the U.S. Census Bureau's Regions and Divisions, which can be found [here](https://www2.census.gov/geo/pdfs/maps-data/maps/reference/us_regdiv.pdf). 
`
)}

function _usRegionsAndDivisions(FileAttachment){return(
FileAttachment("us census bureau regions and divisions.csv").csv()
)}

function _6(md){return(
md`The unemployment data comes from the [U.S. Bureau of Labor Statistics](https://www.bls.gov/web/laus/laumstrk.htm). We'll put the unemployment data in two formats:
- An array of objects where each object has the name and unemployment rate of the state.
- A single object where the keys are the state names and the values are the unemployment rates.`
)}

async function _unemployment(d3,FileAttachment){return(
d3.csvParse(await FileAttachment('unemployment-dec-2019@2.csv').text(),
                           d3.autoType)
)}

function _stateToRate(unemployment){return(
Object.fromEntries(new Map(unemployment.map(d => [d.state, d.rate])))
)}

function _9(md){return(
md`We'll calculate the min and max unemployment rates:`
)}

function _extent(d3,unemployment){return(
d3.extent(unemployment, d => d.rate)
)}

function _11(md){return(
md`Next, we'll create a continuous color scale. Feel free to modify this or use other color scales too.`
)}

function _color(d3,extent){return(
d3.scaleSequential()
      .domain(extent)
      .interpolator(d3.interpolateBlues)
)}

function _stateToAbbr(){return(
{
  "Alabama": "AL",
  "Alaska": "AK",
  "American Samoa": "AS",
  "Arizona": "AZ",
  "Arkansas": "AR",
  "California": "CA",
  "Colorado": "CO",
  "Connecticut": "CT",
  "Delaware": "DE",
  "District of Columbia": "DC",
  "Federated States Of Micronesia": "FM",
  "Florida": "FL",
  "Georgia": "GA",
  "Guam": "GU",
  "Hawaii": "HI",
  "Idaho": "ID",
  "Illinois": "IL",
  "Indiana": "IN",
  "Iowa": "IA",
  "Kansas": "KS",
  "Kentucky": "KY",
  "Louisiana": "LA",
  "Maine": "ME",
  "Marshall Islands": "MH",
  "Maryland": "MD",
  "Massachusetts": "MA",
  "Michigan": "MI",
  "Minnesota": "MN",
  "Mississippi": "MS",
  "Missouri": "MO",
  "Montana": "MT",
  "Nebraska": "NE",
  "Nevada": "NV",
  "New Hampshire": "NH",
  "New Jersey": "NJ",
  "New Mexico": "NM",
  "New York": "NY",
  "North Carolina": "NC",
  "North Dakota": "ND",
  "Northern Mariana Islands": "MP",
  "Ohio": "OH",
  "Oklahoma": "OK",
  "Oregon": "OR",
  "Palau": "PW",
  "Pennsylvania": "PA",
  "Puerto Rico": "PR",
  "Rhode Island": "RI",
  "South Carolina": "SC",
  "South Dakota": "SD",
  "Tennessee": "TN",
  "Texas": "TX",
  "Utah": "UT",
  "Vermont": "VT",
  "Virgin Islands": "VI",
  "Virginia": "VA",
  "Washington": "WA",
  "West Virginia": "WV",
  "Wisconsin": "WI",
  "Wyoming": "WY"
}
)}

function _14(md){return(
md`#### Note:

1. **Labels and Legends:** Make sure to **add proper labels** (titles, axis labels, etc.) and **legends** to each of your charts. Clearly labeled visualizations improve readability and understanding.
   
2. **Adding a Legend with Swatches:**
   To create a color legend for your visualization, you can use the \`@d3/color-legend\` module in D3. Here’s a quick example:
`
)}

function _colorScale(d3){return(
d3.scaleOrdinal()
  .domain(["Northeast", "Midwest", "South", "West"])
  .range(["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728"])
)}

function _16(legend,colorScale){return(
legend({
  color: colorScale, 
  title: "Unemployment Rate, December 2019",
})
)}

function _17(md){return(
md`Or you can also use Swatches from @d3/color-legend`
)}

function _18(Swatches,d3){return(
Swatches(d3.scaleOrdinal(["Northeast", "Midwest", "South", "West"], d3.schemeCategory10))
)}

function _19(md){return(
md`For more details on adding legends using D3, refer to [this](https://observablehq.com/@d3/color-legend#legend) notebook.`
)}

function _20(md){return(
md`## Example 1: Grid Cartogram
ote that these small multiples afford some more advanced d3 skills (which you might want to explore and show), but it is also okay to stick with more fundamental/basic charts.
See the [Small Multiples](/@nyuinfovis/small-multiples?collection=@nyuinfovis/guides-and-examples) notebook for an explanation on how to create them.

`
)}

function _21(legend,color){return(
legend({
  color: color,
  title: 'Unemployment Rate, Decemeber 2019'
})
)}

function _image(FileAttachment){return(
FileAttachment("image.png").image()
)}

function _23(md){return(
md`## Example 2: Speedometer Charts

This visualization encodes the unemployment rate using the angle of a line. See the [Small Multiples](/@nyuinfovis/small-multiples?collection=@nyuinfovis/guides-and-examples) notebook for an explanation of how this code works.

We'll augment the data to make it easier to place into a grid.`
)}

function _numCols(){return(
8
)}

function _numRows(){return(
7
)}

function _gridPositions(d3,numRows,numCols){return(
d3.cross(d3.range(numRows), d3.range(numCols), (row, col) => ({row, col}))
)}

function _unemploymentWithGrid(d3,unemployment,gridPositions){return(
d3.zip(unemployment, gridPositions)
    .map(([data, position]) => ({...data, ...position}))
)}

function _speedometer(d3,numCols,numRows,extent,unemploymentWithGrid,lightgray)
{
  const margin = {top: 30, right: 20, bottom: 0, left: 30};
  const visWidth = 750 - margin.left - margin.right;
  const visHeight = 450 - margin.top - margin.bottom;

  const svg = d3.create('svg')
      .attr('width', visWidth + margin.left + margin.right)
      .attr('height', visHeight + margin.top + margin.bottom)
      .attr('font-family', 'sans-serif')
      .attr('text-anchor', 'middle');

  const g = svg.append('g')
      .attr('transform', `translate(${margin.left}, ${margin.top})`);
  
  // title
  g.append('text')
      .attr('font-size', '16px')
      .attr('dominant-baseline', 'hanging')
      .attr('x', visWidth / 2)
      .attr('y', -margin.top + 5)
      .text('Unemployment Rate, Dec. 2019');

  // set up scales
  
  const column = d3.scaleBand()
      .domain(d3.range(numCols))
      .range([0, visWidth])
      .paddingInner(0.05);
  
  const row = d3.scaleBand()
      .domain(d3.range(numRows))
      .range([0, visHeight])
      .paddingInner(0.05);
  
  const angle = d3.scaleLinear()
      .domain([0, Math.ceil(extent[1])])
      .range([0, Math.PI]);
  
  const radius = Math.min(column.bandwidth(), row.bandwidth()) / 2;
  
  // create a group for each cell in the grid
  const cell = g.selectAll('g')
    .data(unemploymentWithGrid)
    .join('g')
      .attr('transform', d => `translate(${column(d.col) + radius},${row(d.row) + radius})`);
  
  // use an arc generator to create a half-circle
  
  const arc = d3.arc()
      .innerRadius(radius - 1)
      .outerRadius(radius)
      .startAngle(-Math.PI / 2)
      .endAngle(Math.PI / 2);
  
  cell.append('path')
      .attr('d', arc())
      .attr('fill', lightgray);
  
  // add baseline
  const line = d3.line();
  
  cell.append('path')
      .attr('d', d => line([[-radius, 0], [radius, 0]]))
      .attr('fill', 'none')
      .attr('stroke', lightgray)
      .attr('stroke-width', 1)
  
  // add sloped line
  cell.append('path')
      .attr('d', d => {
        const start = [0, 0];
        const end = [-Math.cos(angle(d.rate)) * radius,
                     -Math.sin(angle(d.rate)) * radius];
        return line([start, end])
      })
      .attr('fill', 'none')
      .attr('stroke', 'steelblue')
      .attr('stroke-linecap', 'round')
      .attr('stroke-width', 2);
  
  // add labels
  
  cell.append('text')
      .attr('y', 20)
      .attr('font-size', '10px')
      .text(d => d.state);
  
  cell.append('text')
      .attr('font-size', '12px')
      .attr('fill', lightgray)
      .attr('x', -radius)
      .attr('y', 10)
      .text('0');
  
  cell.append('text')
      .attr('font-size', '12px')
      .attr('fill', lightgray)
      .attr('x', radius)
      .attr('y', 10)
      .text(Math.ceil(extent[1]));

  return svg.node();
}


function _29(width){return(
width
)}

function _30(md){return(
md`## Solution 1 (25P):`
)}

function _31(d3,extent,width,unemployment)
{
  const height = 1000;
  const margin = ({top: 20, bottom: 45, left: 120, right: 10});

  const xScale = d3.scaleLinear()
    .domain([0, extent[1]])
    .range([margin.left, width-margin.right]);
  const yScale = d3.scaleBand()
    .domain(unemployment.map(d => d.state))
    .range([margin.top, height-margin.bottom])
    .padding(0.1);

  const xAxis = d3.axisBottom(xScale);
  const yAxis = d3.axisLeft(yScale);
  
  const svg = d3.create('svg')
    .attr('width', width)
    .attr('height', height);

  svg.append('g')
    .attr('transform', `translate(0, ${height - margin.bottom})`)
    .call(xAxis)
    .call(g => g.select('.domain').remove());

  svg.append('g')
    .attr('transform', `translate(${margin.left})`)
    .call(yAxis)
    .call(g => g.select('.domain').remove());

  svg.append('g')
    .selectAll('rect')
    .data(unemployment)
    .join('rect')
      .attr('x', xScale(0))
      .attr('y', d => yScale(d.state))
      .attr('width', d => xScale(d.rate) - xScale(0))
      .attr('height', yScale.bandwidth())
      .attr('fill', 'steelblue');

  return svg.node();
}


function _32(md){return(
md`## Solution 2 (25P):`
)}

function _33(legend,color){return(
legend({
  color: color,
  title: 'Unemployment Rate, Decemeber 2019'
})
)}

function _34(d3,width,usaGeo,color,stateToRate,stateToAbbr)
{
  const height = 500;

  const svg = d3.create('svg')
    .attr('width', width)
    .attr('height', height);

  const projection = d3.geoAlbersUsa()
    .translate([width/2, height/2])
    .scale(1000);

  const path = d3.geoPath().projection(projection);
  
  svg.selectAll('path')
    .data(usaGeo.features)
    .join('path')
      .attr('d', path)
      .attr('fill', d => color(stateToRate[d.properties.NAME]))
      .attr('stroke', '#000')
      .attr('stroke-width', 1);

  svg.selectAll("text")
    .data(usaGeo.features)
    .join("text")
      .attr("x", d => path.centroid(d)[0])
      .attr("y", d => path.centroid(d)[1])
      .attr("text-anchor", "middle")
      .attr("alignment-baseline", "central")
      .attr("font-size", "12px")
      .attr("fill", "black")
      .text(d => stateToAbbr[d.properties.NAME]);

  return svg.node();
}


function _35(md){return(
md`## Solution 3 (25P):`
)}

function _36(legend,colorScale){return(
legend({
  color: colorScale, 
  title: "Unemployment Rate, December 2019",
})
)}

function _37(width,d3,unemployment,usRegionsAndDivisions,colorScale)
{
  const height = width;

  const root = d3.hierarchy({children: unemployment})
    .sum(d => d.rate);

  const pack = d3.pack()
    .size([width, height])
    .padding(3);

  const regionByState = {};
  usRegionsAndDivisions.forEach(d => {
    regionByState[d.State] = d.Region;
  });

  const nodes = pack(root).leaves();

  const svg = d3.create("svg")
    .attr("width", width)
    .attr("height", height);

  svg.selectAll("circle")
    .data(nodes)
    .join("circle")
      .attr("cx", d => d.x)
      .attr("cy", d => d.y)
      .attr("r", d => d.r)
      .attr("fill", d => colorScale(regionByState[d.data.state]))
      .attr("stroke", "white");

  svg.selectAll("text")
    .data(nodes)
    .join("text")
      .attr("x", d => d.x)
      .attr("y", d => d.y)
      .attr("text-anchor", "middle")
      .attr("alignment-baseline", "middle")
      .attr("font-size", "12px")
      .attr("fill", "black")
      .each(function(d) {
        d3.select(this)
          .append("tspan")
          .text(d.data.state)
          .attr("x", d.x)
          .attr("dy", "-0.2em");
        d3.select(this)
          .append("tspan")
          .text(d.data.rate)
          .attr("x", d.x)
          .attr("dy", "1em");
        });

  return svg.node();
}


function _38(md){return(
md`## Solution 4 (25P):`
)}

function _39(legend,color){return(
legend({
  color: color,
  title: 'Unemployment Rate, Decemeber 2019'
})
)}

function _40(d3,width,unemployment,color,stateToAbbr)
{
  const height = 500;

  const svg = d3.create("svg")
    .attr("width", width)
    .attr("height", height)
    .attr("viewBox", [-width / 2, -height / 2, width, height]);

  const g = svg.append("g")
    .attr("transform", `translate(${width / 2}, ${height / 2})`);

  const pie = d3.pie()
    .value(d => d.rate)
    .sort(null);

  const arc = d3.arc()
    .innerRadius(Math.min(width, height) / 16)
    .outerRadius(Math.min(width, height) / 2 - 1);

  const arcs = pie(unemployment);

  svg.selectAll("path")
    .data(arcs)
    .join("path")
      .attr("d", arc)
      .attr("fill", d => color(d.data.rate))
      .attr("stroke", "#fff")
      .attr("stroke-width", 1);
  
  svg.selectAll("text")
    .data(arcs)
    .join("text")
      .attr("transform", d => `translate(${arc.centroid(d)})`)
      .attr("text-anchor", "middle")
      .attr("alignment-baseline", "middle")
      .style("font-size", "10px")
      .style("fill", "black")
      .text(d => stateToAbbr[d.data.state]);

  return svg.node();
}


function _41(md){return(
md`---
## Appendix`
)}

function _lightgray(){return(
'#dcdcdc'
)}

function _d3(require){return(
require('d3@7')
)}

export default function define(runtime, observer) {
  const main = runtime.module();
  function toString() { return this.url; }
  const fileAttachments = new Map([
    ["image.png", {url: new URL("./files/28de80e04748117ed88295181592b290afdc87eca12fb7e72cb73026a008ef92b97c78faf6ec9af117b9757e3e8484f09f0f81d5943b09a8ea02d2da9639c739.png", import.meta.url), mimeType: "image/png", toString}],
    ["unemployment-dec-2019@2.csv", {url: new URL("./files/6ff47364694fc89e81852ef1f47e221ae3b0dc3b06edf3248613be7840459f835ce51379b282d7a1e5460d03f88565e5883f64691061d81835a633a0edbd4a07.csv", import.meta.url), mimeType: "text/csv", toString}],
    ["us census bureau regions and divisions.csv", {url: new URL("./files/e57dfdce5d09ddf374ec5a2ce23399cbffe4ef565e4eb08ec026fae801a8dcf7a6fbfcbdaddd403e5942f4cdbb211ff7a397d5850847432c32f7396ad0fdaf80.csv", import.meta.url), mimeType: "text/csv", toString}],
    ["gz_2010_us_040_00_20m.json", {url: new URL("./files/5bffca711a2b45090494c77bab30bfa36859ecb5a0619c7d93e1da8f8089be61df96021c578b53cfbd2c3f6611e2567183fec5ed9a66876b50bb47123b2c56b9.json", import.meta.url), mimeType: "application/json", toString}]
  ]);
  main.builtin("FileAttachment", runtime.fileAttachments(name => fileAttachments.get(name)));
  main.variable(observer()).define(["md"], _1);
  main.variable(observer()).define(["md"], _2);
  main.variable(observer("usaGeo")).define("usaGeo", ["FileAttachment"], _usaGeo);
  main.variable(observer()).define(["md"], _4);
  main.variable(observer("usRegionsAndDivisions")).define("usRegionsAndDivisions", ["FileAttachment"], _usRegionsAndDivisions);
  main.variable(observer()).define(["md"], _6);
  main.variable(observer("unemployment")).define("unemployment", ["d3","FileAttachment"], _unemployment);
  main.variable(observer("stateToRate")).define("stateToRate", ["unemployment"], _stateToRate);
  main.variable(observer()).define(["md"], _9);
  main.variable(observer("extent")).define("extent", ["d3","unemployment"], _extent);
  main.variable(observer()).define(["md"], _11);
  main.variable(observer("color")).define("color", ["d3","extent"], _color);
  main.variable(observer("stateToAbbr")).define("stateToAbbr", _stateToAbbr);
  main.variable(observer()).define(["md"], _14);
  main.variable(observer("colorScale")).define("colorScale", ["d3"], _colorScale);
  main.variable(observer()).define(["legend","colorScale"], _16);
  main.variable(observer()).define(["md"], _17);
  main.variable(observer()).define(["Swatches","d3"], _18);
  main.variable(observer()).define(["md"], _19);
  main.variable(observer()).define(["md"], _20);
  main.variable(observer()).define(["legend","color"], _21);
  main.variable(observer("image")).define("image", ["FileAttachment"], _image);
  main.variable(observer()).define(["md"], _23);
  main.variable(observer("numCols")).define("numCols", _numCols);
  main.variable(observer("numRows")).define("numRows", _numRows);
  main.variable(observer("gridPositions")).define("gridPositions", ["d3","numRows","numCols"], _gridPositions);
  main.variable(observer("unemploymentWithGrid")).define("unemploymentWithGrid", ["d3","unemployment","gridPositions"], _unemploymentWithGrid);
  main.variable(observer("speedometer")).define("speedometer", ["d3","numCols","numRows","extent","unemploymentWithGrid","lightgray"], _speedometer);
  main.variable(observer()).define(["width"], _29);
  main.variable(observer()).define(["md"], _30);
  main.variable(observer()).define(["d3","extent","width","unemployment"], _31);
  main.variable(observer()).define(["md"], _32);
  main.variable(observer()).define(["legend","color"], _33);
  main.variable(observer()).define(["d3","width","usaGeo","color","stateToRate","stateToAbbr"], _34);
  main.variable(observer()).define(["md"], _35);
  main.variable(observer()).define(["legend","colorScale"], _36);
  main.variable(observer()).define(["width","d3","unemployment","usRegionsAndDivisions","colorScale"], _37);
  main.variable(observer()).define(["md"], _38);
  main.variable(observer()).define(["legend","color"], _39);
  main.variable(observer()).define(["d3","width","unemployment","color","stateToAbbr"], _40);
  main.variable(observer()).define(["md"], _41);
  main.variable(observer("lightgray")).define("lightgray", _lightgray);
  main.variable(observer("d3")).define("d3", ["require"], _d3);
  const child1 = runtime.module(define1);
  main.import("legend", child1);
  main.import("Swatches", child1);
  return main;
}
