import define1 from "./a33468b95d0b15b0@817.js";

function _1(md){return(
md`# Color - Exercise

In this exercise, we have created visualizations that do not have any color. Your task is to add appropriate color to them.

The [Color Legend](/@d3/color-legend) notebook imported below contains examples of how to make various color scales and their legends. I recommend looking at that notebook and the links it gives.`
)}

function _3(md,companies){return(
md`## Problem 1 (15P)

First, we have a line chart that shows the stock prices for ${companies.length} companies: ${companies.join(', ')}.`
)}

async function _companyToPrices(datasets,d3,minStockDate)
{
  const stocks = (await datasets['stocks.csv']())
    .map(d => ({
      'symbol': d.symbol,
      'price': d.price,
      'date': d3.timeParse('%b %e %Y')(d.date)
    }))
    .filter(d => d.date >= minStockDate)

  return d3.group(stocks, d => d.symbol);
}


function _companies(companyToPrices){return(
Array.from(companyToPrices.keys())
)}

function _minStockDate(d3){return(
d3.timeParse('%b %e %Y')('Jan 1 2005')
)}

function _maxStockDate(d3,companyToPrices){return(
d3.max(companyToPrices, ([company, prices]) => d3.max(prices, p => p.date))
)}

function _maxPrice(d3,companyToPrices){return(
d3.max(companyToPrices, ([company, prices]) => d3.max(prices, p => p.price))
)}

function _companyColor(d3,companyToPrices){return(
d3.scaleOrdinal()
  .domain(companyToPrices.keys())
  .range(d3.schemeCategory10)
)}

function _10(swatches,companyColor){return(
swatches({color: companyColor})
)}

function _11(width,d3,minStockDate,maxStockDate,maxPrice,companyToPrices,companyColor)
{
  const margin = {top: 10, right: 30, bottom: 20, left: 40};
  const visWidth = width - margin.left - margin.right;
  const visHeight = 500 - margin.top - margin.bottom;
  
  const svg = d3.create('svg')
      .attr('width', visWidth + margin.left + margin.right)
      .attr('height', visHeight + margin.top + margin.bottom);
  
  const g = svg.append('g')
      .attr('transform', `translate(${margin.left}, ${margin.top})`);
  
  const x = d3.scaleTime()
      .domain([minStockDate, maxStockDate])
      .range([0, visWidth]);
  
  const y = d3.scaleLinear()
      .domain([0, maxPrice]).nice()
      .range([visHeight, 0]);
  
  const xAxis = d3.axisBottom(x);
  
  const yAxis = d3.axisLeft(y);
  
  g.append('g')
      .attr('transform', `translate(0,${visHeight})`)
      .call(xAxis);
  
  g.append('g')
      .call(yAxis)
      .call(g => g.selectAll('.domain').remove())
    .append('text')
      .attr('text-anchor', 'start')
      .attr('dominant-baseline', 'middle')
      .attr('fill', 'black')
      .attr('x', 5)
      .text('Stock Price ($)');
  
  const line = d3.line()
      .x(d => x(d.date))
      .y(d => y(d.price));

  const series = g.selectAll('.series')
    .data(companyToPrices)
    .join('g')
      // .attr('stroke', ([company, prices]) => 'black') // this is where line color is set
      .attr('stroke', d => companyColor(d.keys()))
      .attr('class', 'series')
    .append('path')
      .datum(([company, prices]) => prices)
      .attr('fill', 'none')
      .attr('stroke-width', 1.5)
      .attr('d', line);
  
  return svg.node();
}


function _12(md){return(
md`## Problem 2 (15P)

Next, we have a heat map that should show the daily precipitation amounts in millimeters for Seattle, WA in 2015.`
)}

function _parseDate(d3){return(
d3.timeParse('%Y/%m/%d')
)}

function _minWeatherDate(d3){return(
d3.timeParse('%Y/%m/%d')("2015/01/01")
)}

function _maxWeatherDate(d3){return(
d3.timeParse('%Y/%m/%d')("2015/12/31")
)}

async function _weather(datasets,parseDate,d3,minWeatherDate,maxWeatherDate){return(
(await datasets['seattle-weather.csv']())
  .map(d => {
    const date = parseDate(d.date);
    return {
      'precipitation': d.precipitation,
      'date': date,
      'day': d3.timeFormat('%a')(date),
      'week': +d3.timeFormat('%U')(date)
    };
  })
  .filter(d => d.date >= minWeatherDate && d.date <= maxWeatherDate)
)}

function _maxPrecipitation(d3,weather){return(
d3.max(weather, d => d.precipitation)
)}

function _precipitationColor(d3,maxPrecipitation){return(
d3.scaleSequential([0, maxPrecipitation], d3.interpolateBlues)
)}

function _19(Legend,precipitationColor){return(
Legend(precipitationColor, {
  title: "Daily Precipitation Amounts"
})
)}

function _20(width,d3,DOM,weather,precipitationColor)
{
  const margin = {top: 20, right: 10, bottom: 10, left: 30};
  const visWidth = width - margin.left - margin.right;
  
  const x = d3.scaleBand()
      .domain(d3.range(53))
      .range([0, visWidth])
      .padding(0.05);
  
  const visHeight =  x.step() * 7;
  
  const svg = d3.select(DOM.svg(visWidth + margin.left + margin.right,
                                visHeight + margin.top + margin.bottom));
  
  const g = svg.append('g')
      .attr('transform', `translate(${margin.left}, ${margin.top})`);
  
  const y = d3.scaleBand()
      .domain(['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'])
      .range([0, visHeight])
      .padding(0.05)
  
  // day of week labels
  
  const yAxis = d3.axisLeft(y)
      .tickPadding(10)
      .tickSize(0);
  
  g.append('g')
      .call(yAxis)
      .call(g => g.selectAll('.domain').remove());
  
  // month labels
  
  const firstOfMonths = weather.filter(d => d.date.getDate() === 1);
  
  g.selectAll('.month')
    .data(firstOfMonths)
    .join('text')
      .attr('class', 'month')
      .attr('font-family', 'sans-serif')
      .attr('font-size', 10)
      .attr('x', d => x(d.week))
      .attr('y', -5)
      .text(d => d3.timeFormat('%b')(d.date))
  
  // squares

  g.selectAll('rect')
    .data(weather)
    .join('rect')
      .attr('x', d => x(d.week))
      .attr('y', d => y(d.day))
      .attr('width', x.bandwidth())
      .attr('height', y.bandwidth())
      // .attr('fill', d => 'black') // this is where square color is set
      .attr('fill', d => precipitationColor(d.precipitation))
  
  return svg.node();
}


function _21(md){return(
md`## Problem 3 (15P)

This dataset contains estimated percent changes in population for each state for 2018 to 2019. We want to show it in a choropleth map. The data is from the [U.S. Census Bureau, Population Division](https://www.census.gov/content/census/en/data/tables/time-series/demo/popest/2010s-state-total.html).

You can find it in the following table linked above: Annual Estimates of the Resident Population for the United States, Regions, States, and Puerto Rico: April 1, 2010 to July 1, 2019 (NST-EST2019-01)`
)}

async function _populations(d3,FileAttachment){return(
d3.csvParse(await FileAttachment('population-2018-2019.csv').text(), d3.autoType)
    .map(d => ({
      state: d.state,
      change: d['percent-change'],
      population: d.population
    }))
)}

function _stateToPopulation(populations)
{
  const map = new Map(populations.map(d => [
    d.state,
    { change: d.change, population: d.population }
  ]));
  
  return Object.fromEntries(map);
}


function _percentChangeExtent(d3,populations){return(
d3.extent(populations, d => d.change)
)}

function _25(md){return(
md`The map data comes from [here](https://eric.clst.org/tech/usgeojson/) and is based on boundaries given by the U.S. Census Bureau.`
)}

function _usaGeo(FileAttachment){return(
FileAttachment('gz_2010_us_040_00_20m.json').json()
)}

function _changeColor(d3){return(
d3.scaleDivergingSqrt([-2.5, 0, 2.5], d3.interpolateRdBu)
)}

function _28(Legend,changeColor){return(
Legend(changeColor, {
  title: "Changes in Population",
})
)}

function _29(d3,usaGeo,populations,changeColor)
{
  const margin = {top: 0, right: 0, bottom: 0, left: 0};
  const visWidth = 600 - margin.left - margin.right;
  const visHeight = 400 - margin.top - margin.bottom;

  const svg = d3.create('svg')
      .attr('width', visWidth + margin.left + margin.right)
      .attr('height', visHeight + margin.top + margin.bottom);

  const g = svg.append('g')
      .attr('transform', `translate(${margin.left}, ${margin.top})`);
  
  // draw map
  
  const projection =  d3.geoAlbersUsa()
      .fitSize([visWidth, visHeight], usaGeo);

  const path = d3.geoPath().projection(projection);

  g.selectAll('.border')
    .data(usaGeo.features.filter(d => d.properties.NAME !== 'Puerto Rico'))
    .join('path')
      .attr('class', 'border')
      .attr('d', path)
      // .attr('fill', d => 'black') // this is where the color of a state is set
      .attr('fill', d => {
        const data = populations.find(p => p.state === d.properties.NAME);
        return changeColor(data.change);
      })
      .attr('stroke', 'white')

  return svg.node();
}


function _30(md){return(
md`## Problem 4 (20P)

Next, we want to have a choropleth map that shows the estimated 2019 population for each state. In this choropleth, we want you to bin the data into 5 bins. Rather than a continuous color range, we only want the map to contain 5 colors. These colors can have the same hue.

We can use the same population data as the previous problem.`
)}

function _31(populations){return(
populations
)}

function _32(stateToPopulation){return(
stateToPopulation
)}

function _populationColor(d3,populations){return(
d3.scaleQuantize()
  .domain(d3.extent(populations, d => d.population))
  .range(d3.schemeBlues[5])
)}

function _34(Legend,populationColor){return(
Legend(populationColor, {
  title: "Population"
})
)}

function _35(d3,usaGeo,stateToPopulation,populationColor)
{
  const margin = {top: 0, right: 0, bottom: 0, left: 0};
  const visWidth = 600 - margin.left - margin.right;
  const visHeight = 400 - margin.top - margin.bottom;

  const svg = d3.create('svg')
      .attr('width', visWidth + margin.left + margin.right)
      .attr('height', visHeight + margin.top + margin.bottom);

  const g = svg.append('g')
      .attr('transform', `translate(${margin.left}, ${margin.top})`);
  
  // draw map
  
  const projection =  d3.geoAlbersUsa()
      .fitSize([visWidth, visHeight], usaGeo);

  const path = d3.geoPath().projection(projection);

  g.selectAll('.border')
    .data(usaGeo.features.filter(d => d.properties.NAME !== 'Puerto Rico'))
    .join('path')
      .attr('class', 'border')
      .attr('d', path)
      // .attr('fill', 'black') // this is where the color of a state is set
      .attr('fill', d => {
        const data = stateToPopulation[d.properties.NAME];
        return populationColor(data.population)
      })
      .attr('stroke', 'white')

  return svg.node();
}


function _36(md,countryToLifeExpectancies){return(
md`## Problem 5 (20P)

This dataset contains the life expectancy for ${countryToLifeExpectancies.size} different countries over a few decades. We have a line chart that shows every country, but we want to highlight a few specific countries, listed below.`
)}

function _highlightCountries(){return(
['Rwanda', 'Kenya', 'China', 'Japan']
)}

async function _countryToLifeExpectancies(d3,datasets){return(
d3.rollup((await datasets['countries.json']()),
                                g => g.map(d => ({year: d3.timeParse('%Y')(d.year),
                                           life_expect: d.life_expect})),
                                d => d.country)
)}

function _labelPoints(highlightCountries,countryToLifeExpectancies){return(
highlightCountries.map(c => {
  const years = countryToLifeExpectancies.get(c);
  return {
    country: c,
    year: years[years.length - 1].year,
    life_expect: years[years.length - 1].life_expect
  }
})
)}

function _minYear(d3,countryToLifeExpectancies){return(
d3.min(countryToLifeExpectancies, ([country, info]) => d3.min(info, d => d.year))
)}

function _maxYear(d3,countryToLifeExpectancies){return(
d3.max(countryToLifeExpectancies, ([country, info]) => d3.max(info, d => d.year))
)}

function _maxLifeExpect(d3,countryToLifeExpectancies){return(
d3.max(countryToLifeExpectancies, ([country, info]) => d3.max(info, d => d.life_expect))
)}

function _highlightColor(d3,highlightCountries){return(
d3.scaleOrdinal()
  .domain(highlightCountries)
  .range(d3.schemeCategory10)
)}

function _44(swatches,highlightColor){return(
swatches({color: highlightColor})
)}

function _45(width,d3,minYear,maxYear,maxLifeExpect,countryToLifeExpectancies,highlightCountries,highlightColor,labelPoints)
{
  const margin = {top: 10, right: 100, bottom: 20, left: 40};
  const visWidth = width - margin.left - margin.right;
  const visHeight = 500 - margin.top - margin.bottom;
  
  const svg = d3.create('svg')
      .attr('width', visWidth + margin.left + margin.right)
      .attr('height', visHeight + margin.top + margin.bottom);
  
  const g = svg.append('g')
      .attr('transform', `translate(${margin.left}, ${margin.top})`);
  
  const x = d3.scaleTime()
      .domain([minYear, maxYear])
      .range([0, visWidth]);
  
  const y = d3.scaleLinear()
      .domain([0, maxLifeExpect]).nice()
      .range([visHeight, 0]);
  
  const xAxis = d3.axisBottom(x);
  
  const yAxis = d3.axisLeft(y);
  
  g.append('g')
      .attr('transform', `translate(0,${visHeight})`)
      .call(xAxis);
  
  g.append('g')
      .call(yAxis)
      .call(g => g.selectAll('.domain').remove())
    .append('text')
      .attr('text-anchor', 'start')
      .attr('dominant-baseline', 'middle')
      .attr('fill', 'black')
      .attr('x', 5)
      .text('Life Expectancy');
  
  const line = d3.line()
      .x(d => x(d.year))
      .y(d => y(d.life_expect));

  const series = g.selectAll('.series')
    .data(countryToLifeExpectancies)
    .join('g')
      .attr('class', 'series')
      // .attr('stroke', ([country, info]) => 'black') // this is where line color is set
      .attr('stroke', ([country, info]) => highlightCountries.includes(country) ? highlightColor(country) : 'black')
      // .attr('stroke-opacity', ([country, info]) => 1) // this is where line opacity is set
      .attr('stroke-opacity', ([country, info]) => highlightCountries.includes(country) ? 1 : 0.1)
      .attr('stroke-width', 1)
    .append('path')
      .datum(([country, info]) => info)
      .attr('fill', 'none')
      .attr('d', line);
  
  g.selectAll('.country-label')
    .data(labelPoints)
    .join('text')
      .attr('class', 'country-label')
      .attr('x', d => x(d.year) + 2)
      .attr('y', d => y(d.life_expect))
      .attr('font-size', 10)
      .attr('font-family', 'sans-serif')
      .attr('dominant-baseline', 'middle')
      .text(d => d.country);
  
  return svg.node();
}


function _46(md,origins){return(
md`## Problem 6 (15P)

Finally, we have a scatter plot of cars that compares horsepower and weight. Each car has one of three origins: ${origins.join(', ')}. We want the plot to also show the origin of each car.`
)}

async function _cars(datasets){return(
(await datasets['cars.json']()).map(d => ({
  horsepower: d['Horsepower'],
  weight: d['Weight_in_lbs'],
  origin: d['Origin']
})).filter(d => d.horsepower !== null && d.weight !== null && d.origin !== null)
)}

function _origins(cars){return(
Array.from(new Set(cars.map(d => d.origin)))
)}

function _carColor(d3,origins){return(
d3.scaleOrdinal()
  .domain(origins)
  .range(d3.schemeCategory10)
)}

function _50(swatches,carColor){return(
swatches({color: carColor})
)}

function _51(d3,cars,lightgray,carColor)
{
  // margin convention
  const margin = {top: 10, right: 10, bottom: 50, left: 100};
  const visWidth = 510 - margin.left - margin.right;
  const visHeight = 460 - margin.top - margin.bottom;

  const svg = d3.create('svg')
      .attr('width', visWidth + margin.left + margin.right)
      .attr('height', visHeight + margin.top + margin.bottom);

  const g = svg.append('g')
      .attr('transform', `translate(${margin.left}, ${margin.top})`);
  
  // create scales
  
  const x = d3.scaleLinear()
      .domain(d3.extent(cars, d => d.horsepower)).nice()
      .range([0, visWidth]);
  
  const y = d3.scaleLinear()
      .domain(d3.extent(cars, d => d.weight)).nice()
      .range([visHeight, 0]);
  
  // create and add axes
  
  const xAxis = d3.axisBottom(x);
  
  g.append("g")
      .attr('transform', `translate(0, ${visHeight})`)
      .call(xAxis)
      .call(g => g.selectAll('.domain').remove())
    .append('text')
      .attr('x', visWidth / 2)
      .attr('y', 40)
      .attr('fill', 'black')
      .attr('text-anchor', 'middle')
      .text('horsepower');
  
  const yAxis = d3.axisLeft(y);
  
  g.append('g')
      .call(yAxis)
      .call(g => g.selectAll('.domain').remove())
    .append('text')
      .attr('x', -40)
      .attr('y', visHeight / 2)
      .attr('fill', 'black')
      .attr('dominant-baseline', 'middle')
      .text('weight (lbs)');
  
  // draw grid, based on https://observablehq.com/@d3/scatterplot
  
  const grid = g.append('g')
      .attr('class', 'grid');
  
  grid.append('g')
    .selectAll('line')
    .data(y.ticks())
    .join('line')
      .attr('stroke', lightgray)
      .attr('x1', 0)
      .attr('x2', visWidth)
      .attr('y1', d => 0.5 + y(d))
      .attr('y2', d => 0.5 + y(d));
  
  grid.append('g')
    .selectAll('line')
    .data(x.ticks())
    .join('line')
      .attr('stroke', lightgray)
      .attr('x1', d => 0.5 + x(d))
      .attr('x2', d => 0.5 + x(d))
      .attr('y1', d => 0)
      .attr('y2', d => visHeight);
  
  // draw points
  
  g.selectAll('circle')
    .data(cars)
    .join('circle')
      .attr('cx', d => x(d.horsepower))
      .attr('cy', d => y(d.weight))
      // .attr('fill', d => 'black') // this is where the dot color is set
      .attr('fill', d => carColor(d.origin))
      .attr('opacity', 1)
      .attr('r', 3);
  
  return svg.node();
}


function _52(md){return(
md`---
## Appendix`
)}

function _d3(require){return(
require('d3@7')
)}

function _datasets(require){return(
require('vega-datasets@1')
)}

function _lightgray(){return(
'#dcdcdc'
)}

export default function define(runtime, observer) {
  const main = runtime.module();
  function toString() { return this.url; }
  const fileAttachments = new Map([
    ["gz_2010_us_040_00_20m.json", {url: new URL("./files/5bffca711a2b45090494c77bab30bfa36859ecb5a0619c7d93e1da8f8089be61df96021c578b53cfbd2c3f6611e2567183fec5ed9a66876b50bb47123b2c56b9.json", import.meta.url), mimeType: "application/json", toString}],
    ["population-2018-2019.csv", {url: new URL("./files/18e58346b5d3a52c4e301e25fbe613316a9e21fd4c76d0c1eea3d5dc537322c3f8928fe0074754c3d6bff498f4bec3d2a32928aa1db8f138b18ce8a6c6034253.csv", import.meta.url), mimeType: "text/csv", toString}]
  ]);
  main.builtin("FileAttachment", runtime.fileAttachments(name => fileAttachments.get(name)));
  main.variable(observer()).define(["md"], _1);
  const child1 = runtime.module(define1);
  main.import("legend", child1);
  main.import("swatches", child1);
  main.import("Legend", child1);
  main.variable(observer()).define(["md","companies"], _3);
  main.variable(observer("companyToPrices")).define("companyToPrices", ["datasets","d3","minStockDate"], _companyToPrices);
  main.variable(observer("companies")).define("companies", ["companyToPrices"], _companies);
  main.variable(observer("minStockDate")).define("minStockDate", ["d3"], _minStockDate);
  main.variable(observer("maxStockDate")).define("maxStockDate", ["d3","companyToPrices"], _maxStockDate);
  main.variable(observer("maxPrice")).define("maxPrice", ["d3","companyToPrices"], _maxPrice);
  main.variable(observer("companyColor")).define("companyColor", ["d3","companyToPrices"], _companyColor);
  main.variable(observer()).define(["swatches","companyColor"], _10);
  main.variable(observer()).define(["width","d3","minStockDate","maxStockDate","maxPrice","companyToPrices","companyColor"], _11);
  main.variable(observer()).define(["md"], _12);
  main.variable(observer("parseDate")).define("parseDate", ["d3"], _parseDate);
  main.variable(observer("minWeatherDate")).define("minWeatherDate", ["d3"], _minWeatherDate);
  main.variable(observer("maxWeatherDate")).define("maxWeatherDate", ["d3"], _maxWeatherDate);
  main.variable(observer("weather")).define("weather", ["datasets","parseDate","d3","minWeatherDate","maxWeatherDate"], _weather);
  main.variable(observer("maxPrecipitation")).define("maxPrecipitation", ["d3","weather"], _maxPrecipitation);
  main.variable(observer("precipitationColor")).define("precipitationColor", ["d3","maxPrecipitation"], _precipitationColor);
  main.variable(observer()).define(["Legend","precipitationColor"], _19);
  main.variable(observer()).define(["width","d3","DOM","weather","precipitationColor"], _20);
  main.variable(observer()).define(["md"], _21);
  main.variable(observer("populations")).define("populations", ["d3","FileAttachment"], _populations);
  main.variable(observer("stateToPopulation")).define("stateToPopulation", ["populations"], _stateToPopulation);
  main.variable(observer("percentChangeExtent")).define("percentChangeExtent", ["d3","populations"], _percentChangeExtent);
  main.variable(observer()).define(["md"], _25);
  main.variable(observer("usaGeo")).define("usaGeo", ["FileAttachment"], _usaGeo);
  main.variable(observer("changeColor")).define("changeColor", ["d3"], _changeColor);
  main.variable(observer()).define(["Legend","changeColor"], _28);
  main.variable(observer()).define(["d3","usaGeo","populations","changeColor"], _29);
  main.variable(observer()).define(["md"], _30);
  main.variable(observer()).define(["populations"], _31);
  main.variable(observer()).define(["stateToPopulation"], _32);
  main.variable(observer("populationColor")).define("populationColor", ["d3","populations"], _populationColor);
  main.variable(observer()).define(["Legend","populationColor"], _34);
  main.variable(observer()).define(["d3","usaGeo","stateToPopulation","populationColor"], _35);
  main.variable(observer()).define(["md","countryToLifeExpectancies"], _36);
  main.variable(observer("highlightCountries")).define("highlightCountries", _highlightCountries);
  main.variable(observer("countryToLifeExpectancies")).define("countryToLifeExpectancies", ["d3","datasets"], _countryToLifeExpectancies);
  main.variable(observer("labelPoints")).define("labelPoints", ["highlightCountries","countryToLifeExpectancies"], _labelPoints);
  main.variable(observer("minYear")).define("minYear", ["d3","countryToLifeExpectancies"], _minYear);
  main.variable(observer("maxYear")).define("maxYear", ["d3","countryToLifeExpectancies"], _maxYear);
  main.variable(observer("maxLifeExpect")).define("maxLifeExpect", ["d3","countryToLifeExpectancies"], _maxLifeExpect);
  main.variable(observer("highlightColor")).define("highlightColor", ["d3","highlightCountries"], _highlightColor);
  main.variable(observer()).define(["swatches","highlightColor"], _44);
  main.variable(observer()).define(["width","d3","minYear","maxYear","maxLifeExpect","countryToLifeExpectancies","highlightCountries","highlightColor","labelPoints"], _45);
  main.variable(observer()).define(["md","origins"], _46);
  main.variable(observer("cars")).define("cars", ["datasets"], _cars);
  main.variable(observer("origins")).define("origins", ["cars"], _origins);
  main.variable(observer("carColor")).define("carColor", ["d3","origins"], _carColor);
  main.variable(observer()).define(["swatches","carColor"], _50);
  main.variable(observer()).define(["d3","cars","lightgray","carColor"], _51);
  main.variable(observer()).define(["md"], _52);
  main.variable(observer("d3")).define("d3", ["require"], _d3);
  main.variable(observer("datasets")).define("datasets", ["require"], _datasets);
  main.variable(observer("lightgray")).define("lightgray", _lightgray);
  return main;
}
