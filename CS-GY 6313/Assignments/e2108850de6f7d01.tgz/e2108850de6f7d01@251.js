async function _1(FileAttachment,md){return(
md`# Graph Design (Scatterplot)
![soccer.png](${await FileAttachment("soccer.png").url()})
In this homework you will work on you d3 charting skills. We want you to implement a scatterplot showing aspects of a Premier League dataset. We already transformed the data for you. This exercise focuses purely on creating the plot, including setting the size and margins, defining the scaling, setting axes, and rendering the data.
`
)}

async function _2(FileAttachment,md){return(
md`Your goal is to create a scatterplot similar to this example (note that the labels may overlap but that is fine for now). The x-axis encodes the goals_for variable meanwhile the y-axis encodes the goals_against variable. The size and color of the circles both encode the points variable
![image.png](${await FileAttachment("image.png").url()})`
)}

function _3(md){return(
md`## Loading the Data (5P)

- Download the [Premier League](https://drive.google.com/file/d/1wuiWK9gBjKk68RWc1r7sjMb5T1_yLC_0/view?usp=sharing) dataset and load the data into observable.`
)}

function _teams_stats21(FileAttachment){return(
FileAttachment("teams_stats2@1.csv").csv()
)}

function _5(md){return(
md`## Define the Size and Margins of your Scatterplot (10P)
First we need to define the size (width, height) of the plot as well as the margins surrounding it.`
)}

function _width(){return(
800
)}

function _height(){return(
600
)}

function _margin(){return(
{
  top: 40,
  right: 40,
  bottom: 50,
  left: 60
}
)}

function _9(md){return(
md`## Define Scales (15P)
We would like you to encode three different attributes from the dataset in your scatterplot: **goals_for**, **goals_against**, and **points**. Hence, you should create one scale for each attribute you want to encode.
Hint: you can use x and y position, size (radius) of the data item and color.
The lab [practice exercise](https://observablehq.com/d/3bab4a3504280f15?collection=@nyuinfovis/practice-exercises) and [[lab prereading](https://observablehq.com/d/5c53f10be6fdfb3a?collection=@nyuinfovis/guides-and-examples)](lab prereading) provide helpful information how to set up scales to map different data types to position and color. `
)}

function _xScale(d3,teams_stats21,width,margin){return(
d3.scaleLinear()
  .domain([0, d3.max(teams_stats21, d=>d.goals_for)]).nice()
  .range([0, width-margin.left-margin.right])
)}

function _yScale(d3,teams_stats21,height,margin){return(
d3.scaleLinear()
  .domain([0, d3.max(teams_stats21, d=>d.goals_against)]).nice()
  .range([height-margin.top-margin.bottom, 0])
)}

function _colorScale(d3,teams_stats21){return(
d3.scaleSequential(d3.interpolateYlGn)
  .domain([0, d3.max(teams_stats21, d=>d.points)])
)}

function _radiusScale(d3,teams_stats21){return(
d3.scaleLinear()
  .domain([d3.min(teams_stats21, d=>d.points), d3.max(teams_stats21, d=>d.points)])
  .range([5, 20])
)}

function _14(md){return(
md`## Creating SVG Container and Scatterplot Axes (30P)`
)}

function _15(md){return(
md`For this task you should create the necessary elements to your visualization and attach them to the **DOM**.

*Tip: You should create [groups](https://developer.mozilla.org/en-US/docs/Web/SVG/Element/g) for the [axes](https://github.com/d3/d3-axis) of your visualization and transform the data making use of the defined margins.*
`
)}

function _16(d3,width,height,render_data,teams_stats21,margin,xScale,yScale)
{ 

  // Create SVG
  const svg = d3.create('svg')
    .attr('width', width)
    .attr('height', height)

  // render your visualization by calling render_data
  render_data(svg, teams_stats21);
  
  // Create axes groups and append axes
  svg.append("g")
    .attr('transform', `translate(${margin.left}, ${height - margin.bottom})`)
    .call(d3.axisBottom(xScale))
  svg.append("g")
    .attr('transform', `translate(${margin.left}, ${margin.top})`)
    .call(d3.axisLeft(yScale))

  // render your visualization by calling render_data
  // render_data(svg, teams_stats21);
    
  return svg.node();
}


function _17(md){return(
md`## Write the Function to Render the Chart (40P)`
)}

function _18(md){return(
md`Here, the *render_data* function should render the elements using the D3 [Data Join](https://observablehq.com/@d3/selection-join).`
)}

function _render_data(xScale,margin,yScale,colorScale,radiusScale){return(
(group, data) => {

  // render elements. Remember to use the Data Join
  group.selectAll('circle')
    .data(data, d=>d.team)
    .join('circle')
    .attr('cx', d=>xScale(d.goals_for)+margin.left)
    .attr('cy', d=>yScale(d.goals_against)+margin.top)
    .attr('fill', d=>colorScale(d.points))
    .attr('r', d=>radiusScale(d.points))
    .attr('stroke', 'gray')
    .attr('stroke-width', 2);

  group.selectAll('text')
    .data(data, d=>d.team)
    .join('text')
    .attr('x', d=>xScale(d.goals_for)+margin.left)
    .attr('y', d=>yScale(d.goals_against)+margin.top-radiusScale(d.points)-5)
    .attr('text-anchor', 'middle')
    .attr('font-size', 18)
    .attr('fill', 'gray')
    .text(d=>d.team);
}
)}

export default function define(runtime, observer) {
  const main = runtime.module();
  function toString() { return this.url; }
  const fileAttachments = new Map([
    ["teams_stats2@1.csv", {url: new URL("./files/deb628c892e41cda0313c69c51c5e9089ea0f75ba621acd611aa930eb5017440e793f6df8772139d04037283487f777f07ae9c5c1e57d96c4eb9a957ecc8627f.csv", import.meta.url), mimeType: "text/csv", toString}],
    ["image.png", {url: new URL("./files/41a3433e0d326cffe75172d66671a8e6603f30aa83c3863c6374ae239f03e482a79039f6abf47cd677d450b05591ecc86d6a03bec8e2611bd7c76083a8fb07f3.png", import.meta.url), mimeType: "image/png", toString}],
    ["soccer.png", {url: new URL("./files/aff48780fbf64ec65f71fb623bf24d0dcbc2eeb8b74dd9e915a4de0c03a27bea286bd9499beba87d0de58ce7794e7af28efe93be2a398bd795c3cd1399cd5c20.png", import.meta.url), mimeType: "image/png", toString}]
  ]);
  main.builtin("FileAttachment", runtime.fileAttachments(name => fileAttachments.get(name)));
  main.variable(observer()).define(["FileAttachment","md"], _1);
  main.variable(observer()).define(["FileAttachment","md"], _2);
  main.variable(observer()).define(["md"], _3);
  main.variable(observer("teams_stats21")).define("teams_stats21", ["FileAttachment"], _teams_stats21);
  main.variable(observer()).define(["md"], _5);
  main.variable(observer("width")).define("width", _width);
  main.variable(observer("height")).define("height", _height);
  main.variable(observer("margin")).define("margin", _margin);
  main.variable(observer()).define(["md"], _9);
  main.variable(observer("xScale")).define("xScale", ["d3","teams_stats21","width","margin"], _xScale);
  main.variable(observer("yScale")).define("yScale", ["d3","teams_stats21","height","margin"], _yScale);
  main.variable(observer("colorScale")).define("colorScale", ["d3","teams_stats21"], _colorScale);
  main.variable(observer("radiusScale")).define("radiusScale", ["d3","teams_stats21"], _radiusScale);
  main.variable(observer()).define(["md"], _14);
  main.variable(observer()).define(["md"], _15);
  main.variable(observer()).define(["d3","width","height","render_data","teams_stats21","margin","xScale","yScale"], _16);
  main.variable(observer()).define(["md"], _17);
  main.variable(observer()).define(["md"], _18);
  main.variable(observer("render_data")).define("render_data", ["xScale","margin","yScale","colorScale","radiusScale"], _render_data);
  return main;
}
