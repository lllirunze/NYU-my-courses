function _1(md){return(
md`# Group Project: Data Analysis and Sketches`
)}

function _2(md){return(
md`As a second step for your project you have to perform an initial data analysis and design sketches for the visualizations that are going to answer the questions you created in your proposal.

1. For each question produce the data you need and display it in a table
2. For each question produce an initial sketch for your visualization

How do you create the sketches?

You can create the sketches in many different ways:
- Hand drawing: with pen and paper or on a tablet
- Drawing software
- Data visualization tools (e.g., Tableau, Matplotlib, etc.)

Note: we personally prefer a more manual approach using hand drawing or drawing software but if you feel more comfortable using an existing data visualization software feel free to use it, just keep in mind that you will eventually have to produce your visualizations in D3).

IMPORTANT: do not copy existing graphs from google images or similar repositories to "give a sense" of which graph you want to use for a given question. Your sketches should refer explicitly to the data you intend to visualize with them. When designing your data visualizations make sure to consider potential limitations in terms of scalability. For instance, if your output includes a 100 time series will you be able to visualize all of them with a line chart?

Follow the template below to produce the document you have to submit for this milestone.`
)}

function _3(md){return(
md`# Analyzing Air Quality Trends in New York City: Identifying Patterns and Impacts`
)}

function _4(md){return(
md`- mz3601 Meiyu Zhang
- kz2575 Ke Zhang
- rl5083 Runze Li`
)}

function _5(md){return(
md`## Data Analysis and Sketches`
)}

function _6(md){return(
md`Data sets used for the project:`
)}

function _7(htl){return(
htl.html`https://data.cityofnewyork.us/Environment/Air-Quality/c3uy-2p5r/about_data`
)}

function _air_quality_20250404(__query,FileAttachment,invalidation){return(
__query(FileAttachment("Air_Quality_20250404.csv"),{from:{table:"Air_Quality_20250404"},sort:[],slice:{to:null,from:null},filter:[],select:{columns:null}},invalidation)
)}

function _data(FileAttachment){return(
FileAttachment("Air_Quality_20250404.csv").csv()
)}

function _11(Inputs,data){return(
Inputs.table(data)
)}

function _12(md){return(
md`# Analysis`
)}

function _13(md){return(
md`New York City’s air contains particles, drops of liquid, gasses, and other pollution that can affect health. Bad air quality can be particularly dangerous for older adults, children, and people with heart or lung conditions.

Air quality varies from neighborhood to neighborhood, based on local levels of emissions and many other factors. We monitor air quality using the New York City Community Air Survey (NYCCAS), NYC’s comprehensive air quality monitoring and modeling network. NYCCAS allows us to understand neighborhood differences in air quality - and what contributes to those differences.`
)}

function _14(md){return(
md`Question 1: **What are the overall trends in NYC’s air quality over the past few years?**`
)}

function _15(md){return(
md`**In this question, we focus on five indicators in the data that represent air quality, which we will use in subsequent questions. Based on these 5 indicators, we filtered the raw data and aggregated them by Name and Start_Date in order to get data1, which shows the value of each indicator at different times.**`
)}

function _names_filter(){return(
[
  "Fine particles (PM 2.5)",
  "Nitrogen dioxide (NO2)",
  "Outdoor Air Toxics - Benzene",
  "Outdoor Air Toxics - Formaldehyde",
  "Ozone (O3)"
]
)}

function _data1(data,names_filter,d3)
{
  const filteredData = data.filter(d => names_filter.includes(d.Name));

  filteredData.forEach(d => {
    d.Start_Date = new Date(d.Start_Date);
    d["Data Value"] = +d["Data Value"];
  });
  const formatDate = d3.timeFormat("%Y-%m-%d");
  const processedData = names_filter.map(name => {
    const pollutantData = filteredData.filter(d => d.Name === name);
    const grouped = d3.group(pollutantData, d => formatDate(d.Start_Date));
    const aggregated = Array.from(grouped, ([date, values]) => {
      return {
        Start_Date: new Date(date),
        average: d3.mean(values, d => d["Data Value"])
      };
    });
    aggregated.sort((a, b) => a.Start_Date - b.Start_Date);
    return { name, data: aggregated };
  });
  return processedData;
}


function _18(Inputs,data1){return(
Inputs.table(data1.flatMap(({ name, data }) =>
  data.map(({ Start_Date, average }) => ({
    Name: name,
    Start_Date,
    Average: average
  }))
))
)}

function _19(FileAttachment){return(
FileAttachment("pollutants_plot_3x2.png").image({ width: 800 })
)}

function _20(md){return(
md`Question 2: **Which areas in NYC experience the highest levels of pollution?**`
)}

function _21(md){return(
md`To identify the most polluted areas in New York City, we focused on the average concentration of Nitrogen Dioxide (NO₂), a common air pollutant associated with vehicle emissions and urban density. Using the dataset provided by NYC Open Data, we followed these steps:`
)}

function _no2_data(data){return(
data.filter(d => d.Name === "Nitrogen dioxide (NO2)")
)}

function _no2_by_place(d3,no2_data){return(
Array.from(
  d3.rollup(
    no2_data,
    v => d3.mean(v, d => +d["Data Value"]),
    d => d["Geo Place Name"]
  ),
  ([place, avg]) => ({ place, avg_no2: avg.toFixed(2) })
)
)}

function _no2_by_place_sorted(no2_by_place){return(
no2_by_place.sort((a, b) => b.avg_no2 - a.avg_no2)
)}

function _25(md){return(
md`Top 10 NYC Areas by Average NO₂ Levels`
)}

function _26(md){return(
md`
`
)}

function _27(Inputs,no2_by_place_sorted){return(
Inputs.table(no2_by_place_sorted.slice(0, 10))
)}

function _28(md){return(
md`This analysis gives us a clear view of which neighborhoods consistently experience the highest NO₂ pollution levels.`
)}

function _29(FileAttachment){return(
FileAttachment("top20_no2.png").image({ width: 800 })
)}

function _31(md){return(
md`Question 3: **How does Nitrogen Dioxide (NO₂) pollution vary between summer and winter seasons over time?**`
)}

function _32(md){return(
md`**This analysis focuses on the seasonal variation of Nitrogen Dioxide (NO₂) levels in New York City.
Using available data categorized by summer and winter periods over multiple years, we calculate the average NO₂ concentration for each season.
By comparing these seasonal averages, we uncover patterns showing how NO₂ pollution fluctuates between warmer and colder months, offering insights into seasonal pollution dynamics and informing season-specific air quality management strategies.**`
)}

function _data3(data,d3)
{
  const filtered_data = data.filter(d => d.Name === "Nitrogen dioxide (NO2)");
  const winter_summer_data = filtered_data.filter(d => /Winter|Summer/i.test(d["Time Period"]));

  const groups = d3.group(winter_summer_data, d => d["Time Period"]);
  const grouped = Array.from(groups, ([timePeriod, values]) => {
    const avgValue = d3.mean(values, d => +d["Data Value"]);
    return { "Time Period": timePeriod, "Data Value": avgValue };
  });

  function sortKey(tp) {
    if (tp.startsWith("Summer")) {
      let parts = tp.split(" ");
      let year = +parts[1];
      return [year, 1];
    } else if (tp.startsWith("Winter")) {
      let parts = tp.split(" ");
      let range = parts[1];
      let [start_year_str, end_year_str] = range.split("-");
      if (end_year_str.length === 2) {
        let year = +(start_year_str.slice(0, 2) + end_year_str);
        return [year, 0];
      } else {
        let year = +end_year_str;
        return [year, 0];
      }
    } else {
      return [9999, 2];
    }
  }
  
  grouped.sort((a, b) => {
    const [yearA, orderA] = sortKey(a["Time Period"]);
    const [yearB, orderB] = sortKey(b["Time Period"]);
    return (yearA - yearB) || (orderA - orderB);
  });
  
  return grouped;
}


function _34(Inputs,data3){return(
Inputs.table(data3)
)}

function _35(FileAttachment){return(
FileAttachment("NO2_by_Season.png").image({ width: 800 })
)}

function _36(md){return(
md`Question 4: **What correlations exist between traffic density and air pollution levels?**`
)}

function _37(md){return(
md`**This analysis examines the relationships between traffic density and various air pollution levels in New York City by calculating pairwise correlations.
A correlation matrix is generated to quantify the strength and direction of association between traffic activity and pollutant concentrations, as well as related health impacts.
Visualizing these correlations helps identify which pollutants are most strongly associated with traffic patterns, providing evidence for targeted interventions to mitigate traffic-related air pollution and its health effects.**`
)}

function _pivotMap(data,d3)
{
  data.forEach(d => {
    d["Data Value"] = +d["Data Value"];
    d["Start_Date"] = new Date(d["Start_Date"]);
  });
  const pivotMap = d3.rollup(
    data,
    v => d3.mean(v, d => d["Data Value"]),
    d => d["Geo Place Name"],
    d => d["Name"]
  );
  return pivotMap;
}


function _corrMatrix(pivotMap)
{
  const geoPlaces = Array.from(pivotMap.keys());
  const pollutantsSet = new Set();
  for (let [, pollutantMap] of pivotMap) {
    for (let pollutant of pollutantMap.keys()) {
      pollutantsSet.add(pollutant);
    }
  }
  const pollutants = Array.from(pollutantsSet);

  const pivot = geoPlaces.map(geo => {
    const pollutantMap = pivotMap.get(geo);
    let row = { "Geo Place Name": geo };
    pollutants.forEach(pollutant => {
      row[pollutant] = pollutantMap.has(pollutant) ? pollutantMap.get(pollutant) : NaN;
    });
    return row;
  });

  function mean(arr) {
    return arr.reduce((s, x) => s + x, 0) / arr.length;
  }
  function std(arr, meanVal) {
    return Math.sqrt(arr.reduce((s, x) => s + Math.pow(x - meanVal, 2), 0) / (arr.length - 1));
  }
  function pearson(x, y) {
    const n = x.length;
    if (n < 2) return NaN;
    const meanX = mean(x);
    const meanY = mean(y);
    const cov = x.reduce((s, xi, i) => s + (xi - meanX) * (y[i] - meanY), 0) / (n - 1);
    const stdX = std(x, meanX);
    const stdY = std(y, meanY);
    return cov / (stdX * stdY);
  }
  const corrMatrix = {};
  pollutants.forEach(p1 => {
    corrMatrix[p1] = {};
    pollutants.forEach(p2 => {
      const pairs = pivot.reduce((acc, row) => {
        const v1 = row[p1];
        const v2 = row[p2];
        if (!isNaN(v1) && !isNaN(v2)) {
          acc.push([v1, v2]);
        }
        return acc;
      }, []);
      const x = pairs.map(d => d[0]);
      const y = pairs.map(d => d[1]);
      corrMatrix[p1][p2] = x.length > 1 ? pearson(x, y) : NaN;
    });
  })

  return corrMatrix;
}


function _flatCorr(corrMatrix)
{
  const flatCorr = [];
  Object.entries(corrMatrix).forEach(([p1, inner]) => {
    Object.entries(inner).forEach(([p2, corr]) => {
      flatCorr.push({
        "Source": p1,
        "Target": p2,
        "Correlation": corr
      });
    });
  });
  return flatCorr;
}


function _41(Inputs,flatCorr){return(
Inputs.table(flatCorr)
)}

function _42(FileAttachment){return(
FileAttachment("correlation_matrix.png").image({ width: 800 })
)}

function _43(md){return(
md`Question 5: **What are the trends of different air quality indicators over the years?**`
)}

function _44(md){return(
md`**This analysis examines the annual trends of key air quality indicators in New York City over time.
By aggregating data by pollutant and year, we visualize how the pollution levels for each pollutant have changed.
This allows us to identify whether specific pollutants show consistent improvement, worsening, or fluctuating patterns across different years.
The comparison provides insights into the effectiveness of air quality management efforts and highlights areas that may require further attention.**`
)}

function _data_with_year(data){return(
data.map(d => ({
  ...d,
  year: new Date(d["Start_Date"]).getFullYear()
}))
)}

function _selected_pollutants(){return(
[
  "Fine particles (PM 2.5)",
  "Nitrogen dioxide (NO2)",
  "Outdoor Air Toxics - Benzene",
  "Outdoor Air Toxics - Formaldehyde",
  "Ozone (O3)"
]
)}

function _filtered_data(data_with_year,selectedPollutant){return(
data_with_year.filter(d => d.Name === selectedPollutant)
)}

function _pollution_sum_by_year(d3,filtered_data){return(
d3.rollup(
  filtered_data,
  v => d3.sum(v, d => +d["Data Value"]),
  d => d.year
)
)}

function _pollution_sum_array(pollution_sum_by_year){return(
Array.from(pollution_sum_by_year, ([year, value]) => ({year, value}))
)}

function _selectedPollutant(Inputs,selected_pollutants){return(
Inputs.select(
  selected_pollutants,
  { label: "Select a pollutant:" }
)
)}

function _51(Plot,pollution_sum_array){return(
Plot.plot({
  width: 800,
  height: 500,
  marks: [
    Plot.barY(pollution_sum_array, {
      x: "year",
      y: "value",
      fill: "steelblue",
      tip: true,
      title: d => `Year ${d.year}: ${d.value.toFixed(2)}`
    })
  ],
  x: { label: "Year" },
  y: { label: "Total Pollution Level" }
})
)}

function _52(md){return(
md`Question 6: **Are there significant disparities in air pollution levels between different boroughs?**`
)}

function _53(md){return(
md`**This analysis explores whether significant differences in air pollution levels exist among the five boroughs of New York City.
By plotting the average pollution levels for each pollutant over time across different boroughs, we compare the air quality trends spatially.
This allows us to identify boroughs with consistently higher or lower pollution levels and examine whether the disparities are narrowing or widening over time, providing insights into localized environmental challenges and the effectiveness of air quality policies.**`
)}

function _data6(data,names_filter,d3)
{
  const filteredData = data.filter(d =>
    names_filter.includes(d.Name) && d["Geo Type Name"] === "Borough"
  );
  
  filteredData.forEach(d => {
    d.Start_Date = new Date(d.Start_Date);
    d["Data Value"] = +d["Data Value"];
  });
  
  const processedData = names_filter.map(pollutant => {
    const pollutantData = filteredData.filter(d => d.Name === pollutant);
    const groupedByBorough = d3.group(pollutantData, d => d["Geo Place Name"]);
    const boroughData = Array.from(groupedByBorough, ([borough, records]) => {
      const groupedByDate = d3.rollup(
        records,
        v => d3.mean(v, d => d["Data Value"]),
        d => d3.timeFormat("%Y-%m-%d")(d.Start_Date)
      );
      const dateData = Array.from(groupedByDate, ([dateStr, avg]) => ({
        Start_Date: new Date(dateStr),
        average: avg
      }));
      dateData.sort((a, b) => a.Start_Date - b.Start_Date);
      return { borough, data: dateData };
    });
    
    return { pollutant, boroughData };
  });
  return processedData;
}


function _55(Inputs,data6){return(
Inputs.table(data6.flatMap(item =>
  item.boroughData.flatMap(b =>
    b.data.map(d => ({
      pollutant: item.pollutant,
      borough: b.borough,
      Start_Date: d.Start_Date,
      average: d.average
    }))
  )
))
)}

function _56(FileAttachment){return(
FileAttachment("pollutants_by_borough.png").image({ width: 800 })
)}

function _57(md){return(
md`Question 7: **Which cds have shown the greatest improvement in air quality over the years?**`
)}

function _58(md){return(
md`**This analysis investigates the changes in air pollution levels over time across different Community Districts (CDs) in New York City.
By calculating the difference in pollution levels between the earliest and latest available years for each CD, we identify which districts have achieved the greatest improvements in air quality.
This highlights spatial disparities in environmental progress and can inform targeted policy interventions for future urban planning and public health efforts.**`
)}

function _data_with_cd(data_with_year){return(
data_with_year.map(d => ({
  ...d,
  community_district: d["Geo Place Name"].match(/\(CD\d+\)/)?.[0] ?? null
})).filter(d => d.community_district !== null)
)}

function _pollution_by_cd_and_year(d3,data_with_cd){return(
d3.rollup(
  data_with_cd,
  v => d3.mean(v, d => +d["Data Value"]),
  d => d.community_district,
  d => d.year
)
)}

function _area_changes(pollution_by_cd_and_year)
{
  let changes = []
  for (let [cd, yearMap] of pollution_by_cd_and_year) {
    let years = Array.from(yearMap.keys()).sort()
    if (years.length >= 2) {
      let firstYear = years[0]
      let lastYear = years[years.length - 1]
      let change = yearMap.get(lastYear) - yearMap.get(firstYear)
      changes.push({
        area: cd,
        firstYear,
        lastYear,
        startValue: yearMap.get(firstYear),
        endValue: yearMap.get(lastYear),
        change
      })
    }
  }
  return changes
}


function _sorted_area_changes(area_changes){return(
area_changes.toSorted((a, b) => a.change - b.change)
)}

function _top_improvements(sorted_area_changes){return(
sorted_area_changes.slice(0, 10)
)}

function _64(Plot,top_improvements){return(
Plot.plot({
  marks: [
    Plot.barX(top_improvements, {
      x: "change",
      y: "area",
      fill: "steelblue",
      tip: true,
      sort: { y: "x" }
    })
  ],
  x: {label: "Pollution Change (Negative = Improvement)"},
  y: {label: "Community District"},
  width: 1200,
  height: 600,
  marginLeft: 100
})
)}

function _66(md){return(
md`Question 8: **What actions or policies could improve air quality in NYC based on the data trends?**`
)}

function _67(md){return(
md`Methods will be added after the analysis. `
)}

export default function define(runtime, observer) {
  const main = runtime.module();
  function toString() { return this.url; }
  const fileAttachments = new Map([
    ["Air_Quality_20250404.csv", {url: new URL("./files/0a9fffe01f039b2a78ad31d3a73b2d30009fbe755cf96468c853e9662d3cf5547d4533ed907f25e4052caa343b1ab8f111e9aff8a7af90cbd63cc6add88d84c1.csv", import.meta.url), mimeType: "text/csv", toString}],
    ["top20_no2.png", {url: new URL("./files/8d603d688c9c4a07b9d3d4c84290f06f8623d8f9fae4797bb07ede1829182a6abbda6b2fc2dfd40cde60f74b3edcfc5405cb03d7a6886cb0ec96bed2880caf14.png", import.meta.url), mimeType: "image/png", toString}],
    ["correlation_matrix.png", {url: new URL("./files/62ef81af1a908cbb001cdc18c26677b4bf093b17e9ce46bae91bfe89fb6135ead2193bd6d6e61b3938c224db2ef50126b42a5f9a413e4b175984cda0140c07a2.png", import.meta.url), mimeType: "image/png", toString}],
    ["pollutants_by_borough.png", {url: new URL("./files/217fa0511a817a4307a9373ca04a6e4e94857da792edf42b232678d22dd7a3c16f0824c1420dd253b57d0bbc4836908a4fe852a5ba781086ff5ebc90e127dfb9.png", import.meta.url), mimeType: "image/png", toString}],
    ["pollutants_plot_3x2.png", {url: new URL("./files/e327f1a2898d86a20128b33ba86e9b0374e08cd2819bdb9d21c66005d677b7e08553baf3b2b59ff5cc0f5abf3faad8deb3d5c79745b170f841aa920a53e6d4fe.png", import.meta.url), mimeType: "image/png", toString}],
    ["NO2_by_Season.png", {url: new URL("./files/79d74519d1ce54627df91c9107a69f394a260bbc02022b41fcb6a48b3102b06f2daeea1c344beb738db25089ce35261868b0064cd23dea80f60d03dd0f55cc57.png", import.meta.url), mimeType: "image/png", toString}]
  ]);
  main.builtin("FileAttachment", runtime.fileAttachments(name => fileAttachments.get(name)));
  main.variable(observer()).define(["md"], _1);
  main.variable(observer()).define(["md"], _2);
  main.variable(observer()).define(["md"], _3);
  main.variable(observer()).define(["md"], _4);
  main.variable(observer()).define(["md"], _5);
  main.variable(observer()).define(["md"], _6);
  main.variable(observer()).define(["htl"], _7);
  main.variable(observer("air_quality_20250404")).define("air_quality_20250404", ["__query","FileAttachment","invalidation"], _air_quality_20250404);
  main.variable(observer("data")).define("data", ["FileAttachment"], _data);
  main.variable(observer()).define(["Inputs","data"], _11);
  main.variable(observer()).define(["md"], _12);
  main.variable(observer()).define(["md"], _13);
  main.variable(observer()).define(["md"], _14);
  main.variable(observer()).define(["md"], _15);
  main.variable(observer("names_filter")).define("names_filter", _names_filter);
  main.variable(observer("data1")).define("data1", ["data","names_filter","d3"], _data1);
  main.variable(observer()).define(["Inputs","data1"], _18);
  main.variable(observer()).define(["FileAttachment"], _19);
  main.variable(observer()).define(["md"], _20);
  main.variable(observer()).define(["md"], _21);
  main.variable(observer("no2_data")).define("no2_data", ["data"], _no2_data);
  main.variable(observer("no2_by_place")).define("no2_by_place", ["d3","no2_data"], _no2_by_place);
  main.variable(observer("no2_by_place_sorted")).define("no2_by_place_sorted", ["no2_by_place"], _no2_by_place_sorted);
  main.variable(observer()).define(["md"], _25);
  main.variable(observer()).define(["md"], _26);
  main.variable(observer()).define(["Inputs","no2_by_place_sorted"], _27);
  main.variable(observer()).define(["md"], _28);
  main.variable(observer()).define(["FileAttachment"], _29);
  main.variable(observer()).define(["md"], _31);
  main.variable(observer()).define(["md"], _32);
  main.variable(observer("data3")).define("data3", ["data","d3"], _data3);
  main.variable(observer()).define(["Inputs","data3"], _34);
  main.variable(observer()).define(["FileAttachment"], _35);
  main.variable(observer()).define(["md"], _36);
  main.variable(observer()).define(["md"], _37);
  main.variable(observer("pivotMap")).define("pivotMap", ["data","d3"], _pivotMap);
  main.variable(observer("corrMatrix")).define("corrMatrix", ["pivotMap"], _corrMatrix);
  main.variable(observer("flatCorr")).define("flatCorr", ["corrMatrix"], _flatCorr);
  main.variable(observer()).define(["Inputs","flatCorr"], _41);
  main.variable(observer()).define(["FileAttachment"], _42);
  main.variable(observer()).define(["md"], _43);
  main.variable(observer()).define(["md"], _44);
  main.variable(observer("data_with_year")).define("data_with_year", ["data"], _data_with_year);
  main.variable(observer("selected_pollutants")).define("selected_pollutants", _selected_pollutants);
  main.variable(observer("filtered_data")).define("filtered_data", ["data_with_year","selectedPollutant"], _filtered_data);
  main.variable(observer("pollution_sum_by_year")).define("pollution_sum_by_year", ["d3","filtered_data"], _pollution_sum_by_year);
  main.variable(observer("pollution_sum_array")).define("pollution_sum_array", ["pollution_sum_by_year"], _pollution_sum_array);
  main.variable(observer("viewof selectedPollutant")).define("viewof selectedPollutant", ["Inputs","selected_pollutants"], _selectedPollutant);
  main.variable(observer("selectedPollutant")).define("selectedPollutant", ["Generators", "viewof selectedPollutant"], (G, _) => G.input(_));
  main.variable(observer()).define(["Plot","pollution_sum_array"], _51);
  main.variable(observer()).define(["md"], _52);
  main.variable(observer()).define(["md"], _53);
  main.variable(observer("data6")).define("data6", ["data","names_filter","d3"], _data6);
  main.variable(observer()).define(["Inputs","data6"], _55);
  main.variable(observer()).define(["FileAttachment"], _56);
  main.variable(observer()).define(["md"], _57);
  main.variable(observer()).define(["md"], _58);
  main.variable(observer("data_with_cd")).define("data_with_cd", ["data_with_year"], _data_with_cd);
  main.variable(observer("pollution_by_cd_and_year")).define("pollution_by_cd_and_year", ["d3","data_with_cd"], _pollution_by_cd_and_year);
  main.variable(observer("area_changes")).define("area_changes", ["pollution_by_cd_and_year"], _area_changes);
  main.variable(observer("sorted_area_changes")).define("sorted_area_changes", ["area_changes"], _sorted_area_changes);
  main.variable(observer("top_improvements")).define("top_improvements", ["sorted_area_changes"], _top_improvements);
  main.variable(observer()).define(["Plot","top_improvements"], _64);
  main.variable(observer()).define(["md"], _66);
  main.variable(observer()).define(["md"], _67);
  return main;
}
