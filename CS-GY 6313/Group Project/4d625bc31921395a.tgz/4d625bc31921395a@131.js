function _1(md){return(
md`# Group Project: Proposal
`
)}

function _2(md){return(
md` # Analyzing Air Quality Trends in New York City: Identifying Patterns and Impacts`
)}

function _3(md){return(
md`rl5083 Runze Li\\mz3601 Meiyu Zhang\\kz2575 Ke Zhang`
)}

function _4(md){return(
md`## Introduction`
)}

function _5(md){return(
md`Air pollution is a major environmental concern that significantly affects public health and urban sustainability. In New York City (NYC), various pollutants impact air quality, leading to health issues such as respiratory diseases and cardiovascular problems. Understanding air quality trends can help policymakers, environmentalists, and residents take proactive measures to reduce pollution and improve overall air health.

This project aims to analyze NYC’s air quality data to uncover patterns and correlations between pollutants, meteorological conditions, and socioeconomic factors. By leveraging interactive visualizations, we seek to answer critical questions about air pollution trends, identify the most affected areas, and explore the impact of external variables like traffic density and seasonal changes.
`
)}

function _6(md){return(
md`## Dataset`
)}

function _7(md){return(
md`**Dataset:** We will use the publicly available **NYC Open Data Air Quality dataset** from the City of New York. The dataset contains information about air pollutants, including **PM2.5, NO2, SO2, CO, and O3**, collected from multiple monitoring stations across the city. The dataset also includes timestamps and location details, enabling spatial and temporal analysis.

**Dataset Source:** [NYC Open Data - Air Quality](https://data.cityofnewyork.us/Environment/Air-Quality/c3uy-2p5r/about_data)

**Sample Data Table Preview:**

| Date & Time      | Station Location | PM2.5 (µg/m³) | NO2 (ppb) | SO2 (ppb) | CO (ppm) | O3 (ppb) |
| ---------------- | ---------------- | ------------- | --------- | --------- | -------- | -------- |
| 2023-03-01 08:00 | Manhattan        | 12.5          | 22.3      | 1.4       | 0.5      | 35.2     |
| 2023-03-01 08:00 | Brooklyn         | 15.2          | 18.9      | 1.1       | 0.6      | 33.8     |
| 2023-03-01 08:00 | Queens           | 10.8          | 20.5      | 0.9       | 0.4      | 36.5     |
`
)}

function _8(md){return(
md`## Questions`
)}

function _9(md){return(
md`1. **What are the overall trends in NYC’s air quality over the past few years?**
2. **Which areas in NYC experience the highest levels of pollution?**
3. **How do air quality levels vary by season and weather conditions?**
4. **What correlations exist between traffic density and air pollution levels?**
5. **Which pollutants exceed recommended safety limits most frequently?**
6. **Are there significant disparities in air pollution levels between different boroughs?**
7. **How do weekends and weekdays differ in air pollution levels?**
8. **What actions or policies could improve air quality in NYC based on the data trends?**`
)}

export default function define(runtime, observer) {
  const main = runtime.module();
  main.variable(observer()).define(["md"], _1);
  main.variable(observer()).define(["md"], _2);
  main.variable(observer()).define(["md"], _3);
  main.variable(observer()).define(["md"], _4);
  main.variable(observer()).define(["md"], _5);
  main.variable(observer()).define(["md"], _6);
  main.variable(observer()).define(["md"], _7);
  main.variable(observer()).define(["md"], _8);
  main.variable(observer()).define(["md"], _9);
  return main;
}
