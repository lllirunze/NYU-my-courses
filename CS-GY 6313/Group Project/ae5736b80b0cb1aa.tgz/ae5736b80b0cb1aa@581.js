import define1 from "./a33468b95d0b15b0@817.js";

function _1(md){return(
md`# Final Submission
`
)}

function _2(md){return(
md`---`
)}

function _3(md){return(
md`# Analyzing Air Quality Trends in New York City: Identifying Patterns and Impacts

- mz3601 Meiyu Zhang
- kz2575 Ke Zhang
- rl5083 Runze Li`
)}

function _4(md){return(
md`## Abstract`
)}

function _5(md){return(
md`Air pollution poses a serious threat to public health, particularly in densely populated urban environments like New York City (NYC). This study investigates spatial and temporal trends of air pollutants across NYC’s neighborhoods using data from the NYC Open Data platform. Through interactive visualization and statistical analysis, we explore seasonal fluctuations, borough-level disparities, and correlations between traffic density and pollution indicators such as PM2.5 and NO₂. We also examine the relationship between socioeconomic factors and pollutant concentrations. Our findings aim to inform future urban planning and environmental policy interventions.`
)}

function _6(md){return(
md`---`
)}

function _7(md){return(
md`## 1 Introduction`
)}

function _8(md){return(
md`Air pollution is a significant environmental and public health issue in major cities worldwide. Fine particulate matter (PM2.5), nitrogen dioxide (NO₂), sulfur dioxide (SO₂), ozone (O₃), and carbon monoxide (CO) are among the most hazardous air pollutants that contribute to acute and chronic respiratory illnesses, cardiovascular disease, and increased mortality [1–5]. According to the World Health Organization (WHO), exposure to elevated levels of PM2.5 alone results in over four million premature deaths annually [6]. In urban environments, pollutant concentrations are often shaped by traffic emissions, industrial activities, meteorological patterns, and spatial inequalities in infrastructure and public services [7,8]. As a global megacity, New York City (NYC) faces distinct challenges due to its high population density, complex transit systems, and neighborhood-level disparities in environmental burden.

Efforts by municipal and state governments have led to improved regulations on emissions, yet localized pollution events persist. Previous studies have explored air quality in NYC’s transit systems [9], street-level emissions [10], and environmental justice dimensions [11]. However, a comprehensive, city-wide exploration of pollution patterns over time—and across neighborhoods, boroughs, and seasons—remains limited. Furthermore, while initiatives such as PlaNYC and OneNYC have prioritized sustainability and climate resilience, understanding **where** and **when** pollutant concentrations are highest can improve targeting of interventions. Neighborhoods with high traffic congestion, poor ventilation, or proximity to industrial zones may suffer disproportionate exposures. Likewise, seasonal variations such as winter heating or summer ozone accumulation can lead to time-specific spikes in pollutant levels.

In this study, we utilize high-resolution, publicly available air quality data from the NYC Open Data portal to conduct a longitudinal and spatial analysis of five key pollutants—PM2.5, NO₂, SO₂, CO, and O₃. We aggregate and visualize data across temporal (seasonal and annual) and spatial (borough and community district) dimensions, identify pollution hotspots, and evaluate correlations with external factors such as traffic density. Through this approach, we aim to answer critical questions: How have air pollutant levels changed in NYC over the past decade? Which neighborhoods consistently experience higher concentrations? How does pollution vary by season? What role does urban mobility play in shaping air quality patterns? The goal is to provide actionable insights that support data-driven policymaking, promote environmental equity, and inform future public health and planning strategies in New York City.
`
)}

function _9(md){return(
md`### Study Region`
)}

function _10(md){return(
md`New York City (NYC) is composed of five boroughs: Manhattan, Brooklyn, Queens, the Bronx, and Staten Island. Each borough contains multiple neighborhoods, which are further organized into administrative zones known as Community Districts (CDs). These districts represent the primary geographic unit for this study.

Our analysis includes all five boroughs of NYC and utilizes air quality data aggregated at the CD level. The dataset records pollution measurements—specifically PM2.5, NO₂, SO₂, CO, and O₃—across over 50 unique CDs, identified by their names (e.g., "Flushing and Whitestone (CD7)", "Upper West Side (CD7)") and associated geographic coordinates. These measurements are recorded during both summer and winter periods across multiple years, allowing for seasonal and longitudinal comparisons.

By using CDs as the unit of analysis, we enable both borough-level and neighborhood-level assessments of air pollution. This spatial granularity allows us to identify not only city-wide trends but also localized pollution hotspots and disparities. Figure 1 illustrates the spatial distribution of monitored Community Districts across NYC.
`
)}

function _11(md){return(
md`---`
)}

function _12(md){return(
md`## 2 Dataset`
)}

function _13(md){return(
md`We will use the publicly available **NYC Open Data Air Quality dataset** from the City of New York. The dataset contains information about air pollutants, including **PM2.5, NO2, SO2, CO, and O3**, collected from multiple monitoring stations across the city. The dataset also includes timestamps and location details, enabling spatial and temporal analysis.

**Dataset Source:** [NYC Open Data - Air Quality](https://data.cityofnewyork.us/Environment/Air-Quality/c3uy-2p5r/about_data)`
)}

function _14(Inputs,data){return(
Inputs.table(data)
)}

function _15(md){return(
md`---`
)}

function _16(md){return(
md`## 3 Questions`
)}

function _17(md){return(
md`### 3.1 Temporal Trends in Air Quality Indicators`
)}

function _18(md){return(
md`**Question 1: What are the overall trends in NYC’s air quality over the past few years?**

To investigate long-term air quality trends in New York City, we focused on five key pollutants measured consistently across multiple seasons and years: **Fine particles (PM2.5)**, **Nitrogen dioxide (NO₂)**, **Ozone (O₃)**, **Outdoor Air Toxics – Benzene**, and **Outdoor Air Toxics – Formaldehyde**. These indicators were selected based on their known public health relevance and consistent availability in the dataset.¹⁻³

We first filtered the raw dataset to retain only records corresponding to these five pollutants. The resulting subset was then aggregated by \`Name\` and \`Start_Date\`, enabling a time series representation of each pollutant’s concentration over time. The analysis period spans from Winter 2009–10 through Summer 2022, with seasonal granularity (i.e., separate measurements for summer and winter periods each year).`
)}

function _selectedPollutant1(Inputs,names_filter){return(
Inputs.select(
  names_filter,
  { label: "Select a pollutant:" }
)
)}

function _20(Plot,dataset1){return(
Plot.plot({
  width: 800,
  height: 500,
  x: {
    label: "Date",
    type: "time",
    tickFormat: "%Y-%m-%d",
    grid: true
  },
  y: {
    label: `Average Data Value (${dataset1[0]?.unit})`,
    grid: true
  },
  marks: [
    Plot.line(dataset1, { x: "date", y: "average", stroke: "steelblue" }),
    Plot.dot(dataset1, {
      x: "date",
      y: "average",
      fill: "steelblue",
      title: d => `${d.date.toLocaleDateString()}: ${d.average.toFixed(2)}`
    })
  ]
})
)}

function _21(md){return(
md`This figure shows the seasonal trends of each pollutant over the analyzed time frame. Overall, a **gradual improvement** in air quality can be observed for most pollutants. Specifically, **PM2.5** and **NO₂** levels have decreased steadily, reflecting the impact of regulatory measures such as traffic emission controls and cleaner fuel standards. **Ozone (O₃)** exhibits more seasonal fluctuation, with higher concentrations typically observed in summer months due to photochemical reactions triggered by sunlight. Toxics such as **Benzene** and **Formaldehyde** also show slight downward trends, though with higher variability compared to primary pollutants.

These findings suggest that NYC's air quality has improved incrementally over the past decade, especially in terms of particulate matter and traffic-related pollutants. However, continued monitoring is essential to track the persistence of seasonal peaks and identify areas for further policy intervention.
`
)}

function _22(md){return(
md`### 3.2 Spatial Disparities in Air Pollution`
)}

function _23(md){return(
md`**Question2: Which areas in NYC experience the highest levels of pollution?**

To identify which areas of New York City experience the highest levels of air pollution, we analyzed the spatial distribution of **Nitrogen Dioxide (NO₂)** concentrations across Community Districts (CDs). NO₂ is a widely monitored traffic-related pollutant known for its adverse effects on respiratory health and strong association with urban vehicular emissions.¹⁻³

From the dataset, we extracted over 6,000 NO₂ records covering multiple seasonal measurements across 114 distinct locations. These records were aggregated by \`Geo Place Name\` to compute the average NO₂ concentration for each Community District over the available time range. Figure 3 presents the top 20 districts ranked by their average NO₂ levels, while Table 1 summarizes the top 10.

`
)}

function _24(Legend,d3,dataFlat){return(
Legend(d3.scaleSequential(d3.extent(dataFlat, d => d.value), d3.interpolateBlues), {
  title: "Average NO₂ Level (ppb)",
})
)}

function _chart(d3,dataFlat)
{
  const width  = 928;
  const height = width;
  const margin = 30;

  const name   = d => d.id;
  const format = d3.format(".2f");

  const color = d3.scaleSequential(d3.interpolateBlues)
    .domain(d3.extent(dataFlat, d => d.value));

  const pack = d3.pack()
    .size([width - margin * 2, height - margin * 2])
    .padding(5);

  const root = pack(
    d3.hierarchy({children: dataFlat})
      .sum(d => d.value ** 2)
  );

  const svg = d3.create("svg")
    .attr("width",  width)
    .attr("height", height)
    .attr("viewBox", [-margin, -margin, width, height])
    .attr("style", "max-width:100%; height:auto; font:10px sans-serif;")
    .attr("text-anchor", "middle");

  svg.append("text")
    .attr("x",        width / 2 - margin)
    .attr("y",        10)
    .attr("font-size","20px")
    .attr("font-family","sans-serif")
    .attr("fill","black")
    .text("Average NO₂ Level by Place");

  const node = svg.append("g")
    .selectAll("g")
    .data(root.leaves())
    .join("g")
      .attr("transform", d => `translate(${d.x},${d.y})`);

  node.append("title")
    .text(d => `${name(d.data)}\nNO₂: ${format(d.data.value)} ppb`);

  node.append("circle")
      .attr("r",   d => d.r)
      .attr("fill",d => color(d.data.value))
      .attr("fill-opacity",0.8)
      .attr("stroke","#333")
      .style("cursor","pointer")
      .on("mouseover", function(event,d){
        d3.select(this)
          .transition().duration(200)
          .attr("r", d.r * 1.2);
      })
      .on("mouseout", function(event,d){
        const circle = d3.select(this);
        circle.transition().duration(200)
          .attr("r", circle.classed("active") ? d.r * 1.3 : d.r);
      })
      .on("click", function(event,d){
        const circle = d3.select(this);
        const isActive = circle.classed("active");

        d3.selectAll("circle").classed("active",false)
          .transition().duration(300)
          .attr("r", d => d.r);

        if(!isActive){
          circle.classed("active",true)
            .transition().duration(300)
            .attr("r", d.r * 1.3);
        }
      });

  const label = node.append("text")
    .attr("pointer-events","none")         
    .attr("clip-path", d => `circle(${d.r})`);

  label.selectAll("tspan")
      .data(d => name(d.data).split(/\s+/))
      .join("tspan")
        .attr("x",0)
        .attr("y",(d,i,nodes)=>`${i - nodes.length/2 + .35}em`)
        .text(d => d);

  label.append("tspan")
      .attr("x",0)
      .attr("y",d => `${name(d.data).split(/\s+/).length/2 + .35}em`)
      .attr("fill-opacity",0.7)
      .text(d => `${format(d.data.value)} ppb`);

  return svg.node();      
}


function _26(md){return(
md`Our findings reveal a clear spatial disparity: the most polluted areas are concentrated in **central and lower Manhattan**, where urban density and traffic volume are highest. The **Midtown area (CD5)** exhibits the highest average NO₂ concentration at **33.95 ppb**, followed by **Gramercy Park – Murray Hill** (31.66 ppb), and **Chelsea – Clinton** (29.98 ppb). These neighborhoods are characterized by high-rise commercial activity, dense public transportation routes, and significant street-level congestion, all of which contribute to elevated NO₂ levels. Other heavily impacted areas include the Financial District (CD1), Lower Manhattan, and Union Square, all of which rank within the top 20.

Notably, these spatial trends align with prior studies indicating that urban cores tend to exhibit higher concentrations of traffic-related pollutants.⁴ Such disparities may exacerbate health inequities, especially for residents living in high-density housing near major roadways. These insights underscore the need for targeted air quality interventions—such as green infrastructure, traffic regulation, and localized monitoring—in NYC’s most impacted districts.`
)}

function _27(md){return(
md`### 3.3 Seasonal Variation of Nitrogen Dioxide (NO₂) Concentrations`
)}

function _28(md){return(
md`**Question 3: How does Nitrogen Dioxide (NO₂) pollution vary between summer and winter seasons over time?**

Seasonal dynamics play a significant role in shaping air pollution levels in urban environments, particularly for nitrogen dioxide (NO₂), which is primarily emitted from vehicular combustion and industrial processes. To assess how NO₂ concentrations differ between warmer and colder months in New York City, we examined seasonal averages for each biannual time period from Winter 2008–09 to Summer 2023. The data was categorized into “Winter” and “Summer” groups and analyzed chronologically over a 15-year span.

The following figure presents a horizontal bar chart of average NO₂ values per season, color-coded by season. A consistent seasonal disparity is evident: **winter NO₂ concentrations are notably higher than those in summer across nearly all years**. For instance, in Winter 2008–09, the NO₂ level peaked at **30.83 ppb**, while the following summer (Summer 2009) dropped to **22.08 ppb**. This trend persists throughout the dataset, with winter values exceeding summer counterparts by **5 to 10 ppb on average**.

The observed seasonal pattern is attributable to multiple environmental and anthropogenic factors. Colder temperatures in winter months lead to increased combustion for heating, which contributes to higher NO₂ emissions. Furthermore, atmospheric conditions such as temperature inversions are more prevalent in winter, limiting vertical mixing and causing pollutants to accumulate near ground level. In contrast, summer conditions generally facilitate greater dispersion and photochemical breakdown of NO₂, resulting in lower observed concentrations.

Although a general decline in NO₂ levels is visible over the 15-year period—likely reflecting policy efforts to reduce traffic emissions—the seasonal gap remains persistent. This underscores the importance of **season-specific mitigation strategies**, such as promoting cleaner heating fuels during winter months and enhancing public transportation use year-round.

`
)}

function _29(Swatches,d3){return(
Swatches(d3.scaleOrdinal(["Winter", "Summer"], ["steelblue", "lightcoral"]))
)}

function _30(d3,dataset3)
{
  const width = 800;
  const height = width/1.5;
  const margin = { top: 60, right: 20, bottom: 40, left: 120 };

  const y = d3.scaleBand()
    .domain(dataset3.map(d => d.period))
    .range([margin.top, height - margin.bottom])
    .padding(0.1);

  const x = d3.scaleLinear()
    .domain([0, d3.max(dataset3, d => d.value)])
    .nice()
    .range([margin.left, width - margin.right]);

  const svg = d3.create("svg")
    .attr("width", width)
    .attr("height", height);

  svg.append("g")
    .selectAll("rect")
    .data(dataset3)
    .join("rect")
      .attr("x", x(0))
      .attr("y", d => y(d.period))
      .attr("width", d => x(d.value) - x(0))
      .attr("height", y.bandwidth())
      .attr("fill", d => d.period.startsWith("Summer") ? "lightcoral" : "steelblue");

  svg.append("g")
    .attr("transform", `translate(0,${margin.top})`)
    .call(d3.axisTop(x).ticks(5).tickFormat(d => `${d} ppb`))
    .call(g => g.select(".domain").remove());

  svg.append("g")
    .attr("transform", `translate(${margin.left},0)`)
    .call(d3.axisLeft(y))
    .call(g => g.select(".domain").remove());

  svg.append("text")
    .attr("x", width / 2)
    .attr("y", margin.top / 2)
    .attr("text-anchor", "middle")
    .attr("font-size", "16px")
    .text("Average NO₂ Level by Time Period");

  svg.append("text")
    .attr("transform", "rotate(-90)")
    .attr("x", -height / 2)
    .attr("y", 15)
    .attr("text-anchor", "middle")
    .text("Time Period");

  return svg.node();
}


function _31(md){return(
md`### 3.4 Correlation Between Traffic Density and Air Pollution Levels`
)}

function _32(md){return(
md`**Question 4: What correlations exist between traffic density and air pollution levels?**

To explore the influence of vehicular activity on urban air pollution, we conducted a correlation analysis between traffic density indicators and pollutant concentrations across New York City's Community Districts. Specifically, we examined three traffic-related variables—**Annual vehicle miles traveled (VMT)**, including subsets for **cars** and **trucks**—and their relationship with key air pollutants and health outcomes. Pairwise Pearson correlation coefficients were computed and visualized in a heatmap (Figure 5), while summary values are reported in Table 2.

Among pollutants, **Nitrogen Dioxide (NO₂)** exhibited the strongest and most consistent positive correlation with vehicle activity. NO₂ was highly correlated with total VMT (**r = 0.819**), truck-related mileage (**r = 0.771**), and car-related mileage (**r = 0.799**). This is consistent with NO₂’s well-established role as a primary emission from internal combustion engines, particularly diesel-powered vehicles.⁴ Similarly, **Fine Particulate Matter (PM2.5)** showed a strong correlation with NO₂ (**r = 0.953**) and moderate correlation with vehicle activity (**r ≈ 0.75–0.80**), indicating overlapping emission sources.

Interestingly, the analysis also revealed meaningful associations between traffic activity and **health indicators**, including **asthma emergency department visits** and **respiratory hospitalizations due to PM2.5**, although the correlations were weaker (r = 0.16 and r = –0.19, respectively). This may reflect the complex interplay between environmental exposure, individual susceptibility, and access to healthcare.

Notably, **Ozone (O₃)** exhibited a negative correlation with vehicle-related variables (**r = –0.89 with NO₂**), likely due to its secondary pollutant nature—formed through photochemical reactions involving NOₓ and VOCs under sunlight. This inverse relationship suggests that while NO₂ concentrations rise in high-traffic zones, O₃ levels may decline due to NO titration effects near roadways.⁵

These findings reinforce the strong link between traffic emissions and ambient NO₂ and PM2.5 levels in NYC, highlighting the need for targeted policies such as emission zoning, electrification of vehicle fleets, and investment in public transit infrastructure to mitigate traffic-related air pollution and its associated health burdens.
`
)}

function _33(Legend,d3){return(
Legend(d3.scaleDiverging([1, 0, -1], d3.interpolateRdBu), {
  title: "Correlation",
})
)}

function _34(d3,flatCorr)
{
  const width = 800;
  const height = 800;
  const margin = { top: 60, right: 60, bottom: 240, left: 240 };
  const innerWidth = width - margin.left - margin.right;
  const innerHeight = height - margin.top - margin.bottom;

  const svg = d3.create('svg')
    .attr('width', width)
    .attr('height', height);

  const g = svg.append('g')
    .attr('transform', `translate(${margin.left},${margin.top})`);

  const sources = Array.from(new Set(flatCorr.map(d => d.Source))).sort();
  const targets = Array.from(new Set(flatCorr.map(d => d.Target))).sort();

  const xScale = d3.scaleBand()
    .domain(sources)
    .range([0, innerWidth])
    .padding(0.05);
  
  const yScale = d3.scaleBand()
    .domain(targets)
    .range([0, innerHeight])
    .padding(0.05);

  const colorScale = d3.scaleDiverging()
    .domain([1, 0, -1])
    .interpolator(d3.interpolateRdBu);

  g.selectAll('rect')
    .data(flatCorr)
    .join('rect')
      .attr('x', d => xScale(d.Source))
      .attr('y', d => yScale(d.Target))
      .attr('width', xScale.bandwidth())
      .attr('height', yScale.bandwidth())
      .attr('fill', d => colorScale(d.Correlation))
    .append('title')
      .text(d => `${d.Source} vs ${d.Target}: ${d.Correlation.toFixed(2)}`);

  g.selectAll('text.value')
    .data(flatCorr)
    .join('text')
      .attr('class', 'value')
      .attr('x', d => xScale(d.Source) + xScale.bandwidth() / 2)
      .attr('y', d => yScale(d.Target) + yScale.bandwidth() / 2)
      .text(d => d.Correlation.toFixed(2))
      .attr('text-anchor', 'middle')
      .attr('alignment-baseline', 'middle')
      .attr('font-size', '10px')
      .attr('fill', d => Math.abs(d.Correlation) > 0.5 ? 'white' : 'black');

  g.append('g')
    .attr('transform', `translate(0, ${740 - margin.bottom})`)
    .call(d3.axisBottom(xScale))
    .call(g => g.select('.domain').remove())
    .selectAll('text')
      .attr('transform', 'rotate(-45)')
      .attr('text-anchor', 'end');
  
  g.append('g')
    .call(d3.axisLeft(yScale))
    .call(g => g.select('.domain').remove());

  g.append("text")
      .attr("fill", "black")
      .attr("font-family", "sans-serif")
      .attr("font-size", "16px")
      .attr("x", 200)
      .attr("y", -10)
      .attr("text-anchor", "middle")
      .text("Correlation Matrix");

  return svg.node();
}


function _35(md){return(
md`### 3.5 Trends of Different Air Quality Indicators`
)}

function _36(md){return(
md`**Question 5: What are the trends of different air quality indicators over the years?**

To assess the overall change in air quality over time, we aggregated annual total pollution levels for five major air pollutants measured across New York City:

- **Fine Particles (PM2.5)**  
- **Nitrogen Dioxide (NO₂)**  
- **Outdoor Air Toxics – Benzene**  
- **Outdoor Air Toxics – Formaldehyde**  
- **Ozone (O₃)**

Each pollutant shows distinct trends based on long-term data aggregation:`
)}

function _selectedPollutant(Inputs,selected_pollutants){return(
Inputs.select(
  selected_pollutants,
  { label: "Select a pollutant:" }
)
)}

function _38(Plot,pollution_sum_array){return(
Plot.plot({
  width: 800,
  height: 500,
  marks: [
    Plot.barY(pollution_sum_array, {
      x: "year",
      y: "value",
      fill: "steelblue",
      tip: true,
      title: d => `Year ${d.year}: ${d.value.toFixed(2)}`
    })
  ],
  x: { label: "Year" },
  y: { label: "Total Pollution Level" }
})
)}

function _39(md){return(
md`#### Fine Particles (PM2.5)
PM2.5 levels peaked around **2010** and again in **2015**, but showed a consistent decline after that, with total pollution levels falling from nearly **5000** units in earlier years to **below 3000** by **2023**. This trend suggests effective pollution control measures, especially on particulate matter from traffic and combustion sources.

#### Nitrogen Dioxide (NO₂)
NO₂ followed a similar trajectory, with notable spikes in **2010** and **2015** exceeding **10,000 units**, followed by a sharp decline in recent years. By **2023**, NO₂ levels dropped to around **4,000 units**, reflecting improved emissions regulation and traffic management in NYC.

#### Outdoor Air Toxics – Benzene
Benzene data, available for 2005, 2011, and 2014, show a sharp decrease from **~175 units in 2011** to under **50 units** in **2014**, indicating significant reduction of industrial and vehicular benzene emissions during this period.

#### Outdoor Air Toxics – Formaldehyde
Formaldehyde followed a similar pattern as benzene, with a drop from **~230 units in 2011** to below **80 units** in 2014. Though data is sparse, this drop supports the conclusion that toxic air emissions have been effectively curbed in recent years.

#### Ozone (O₃)
Unlike other pollutants, ozone levels show **no clear declining trend**. In fact, total O₃ values have remained relatively stable and even slightly increased between **2017 and 2023**, with values consistently around **4000–4700 units**. This may be attributed to complex photochemical reactions that are not as directly affected by local emission reductions.
`
)}

function _40(md){return(
md`### 3.6 Disparities in Air Pollution Levels among Different Boroughs`
)}

function _41(md){return(
md`**Question 6: Are there significant disparities in air pollution levels between different boroughs?**

To assess inter-borough disparities in air quality, we compared pollutant levels across the five boroughs of New York City—The Bronx, Brooklyn, Manhattan, Queens, and Staten Island—for five major pollutants: PM2.5, NO₂, Benzene, Formaldehyde, and O₃. Our findings are summarized below:`
)}

function _selectedPollutant6(Inputs,names_filter){return(
Inputs.select(
  names_filter, 
  { label: "Select a pollutant:", value: names_filter[0] }
)
)}

function _43(Plot,dataset6){return(
Plot.plot({
  width: 800,
  height: 400,
  margin: 50,
  x: {
    label: "Date",
    type: "time",
    grid: true
  },
  y: {
    label: `Average Data Value (${dataset6[0]?.unit})`,
    grid: true
  },
  color: { legend: true },
  marks: [
    Plot.line(dataset6, {
      x: "date",
      y: "average",
      stroke: "borough"
    }),
    Plot.dot(dataset6, {
      x: "date",
      y: "average",
      fill: "borough",
      title: d => `${d.borough} — ${d.date.toLocaleDateString()}: ${d.average.toFixed(2)}`
    })
  ]
})
)}

function _44(md){return(
md`**PM2.5 (Fine Particles)**
Manhattan consistently exhibits the highest PM2.5 levels over time, followed by The Bronx and Brooklyn. Queens and Staten Island tend to have lower concentrations. Despite a general downward trend from 2009 to 2022 across all boroughs, the gap between Manhattan and other boroughs persists, indicating spatial inequality in particulate matter exposure.

**NO₂ (Nitrogen Dioxide)**
The disparity in NO₂ levels is more pronounced. Manhattan shows significantly higher NO₂ concentrations than the other boroughs throughout the entire period (2009–2023), peaking above 35 ppb in earlier years. This trend is closely linked to Manhattan’s higher traffic density and urban congestion. The Bronx and Brooklyn follow, while Queens and Staten Island consistently show the lowest NO₂ levels.

**Benzene (Outdoor Air Toxics)**
Between 2005 and 2013, Benzene concentrations declined across all boroughs. However, Manhattan started with a much higher level (above 4.5 μg/m³ in 2005), compared to under 2.0 μg/m³ in Queens and Staten Island. Although disparities narrowed over time, the earlier years reveal a significant exposure gap, likely due to proximity to industrial zones and vehicular sources.

**Formaldehyde (Outdoor Air Toxics)**
Similar to Benzene, Manhattan recorded the highest formaldehyde levels in earlier years, with The Bronx and Brooklyn following. All boroughs show a steady decrease between 2005 and 2013. Despite overall improvements, the initial differences again reflect spatial inequality in toxic air pollutant exposure.

**O₃ (Ozone)**
Unlike other pollutants, Ozone levels are lower in Manhattan and higher in Staten Island and Queens. This is likely due to the complex chemical reactions between sunlight and NOₓ emissions, which can reduce ozone in high-traffic areas like Manhattan (a phenomenon known as NO titration). Over time, O₃ levels increased slightly across all boroughs, with suburban areas experiencing consistently higher concentrations.

These visualizations and trend lines confirm significant disparities in air pollution exposure between boroughs. Manhattan consistently ranks highest for traffic-related pollutants (PM2.5 and NO₂), while outer boroughs such as Queens and Staten Island show relatively better air quality. Such disparities reflect differences in urban density, land use, industrial activity, and transit infrastructure. These findings underscore the need for targeted, place-based environmental interventions to address localized pollution burdens in New York City.`
)}

function _45(md){return(
md`### 3.7 Improvement in Air Quality`
)}

function _46(md){return(
md`**Question 7: Which cds have shown the greatest improvement in air quality over the years?**

To identify which areas have experienced the most substantial improvements in air quality, we calculated the change in average pollutant levels across time for each Community District (CD). Using the compiled dataset, we compared pollution levels from the earliest to the most recent available years, focusing on long-term trends.

The bar chart below displays the top 10 CDs with the largest **declines** in pollution concentrations (i.e., the most improvement). Negative values on the x-axis indicate reductions in pollution levels.`
)}

function _47(Plot,top_improvements){return(
Plot.plot({
  marks: [
    Plot.barX(top_improvements, {
      x: "change",
      y: "area",
      fill: "steelblue",
      tip: true,
      sort: { y: "x" }
    })
  ],
  x: {label: "Pollution Change (Negative = Improvement)"},
  y: {label: "Community District"},
  width: 1200,
  height: 600,
  marginLeft: 100
})
)}

function _48(md){return(
md`**Top 10 CDs with Greatest Improvement:**

1. **CD6**  
2. **CD17**  
3. **CD16**  
4. **CD5**  
5. **CD4**  
6. **CD8**  
7. **CD2**  
8. **CD7**  
9. **CD9**  
10. **CD3**

These areas have seen pollution reductions ranging from approximately **-25 to -50 units**, indicating a strong downward trend in air pollutant concentrations. This suggests that targeted interventions—such as emission controls, infrastructure upgrades, and transit system improvements—may have had a significant positive impact in these districts.

Overall, the data demonstrate that while disparities still exist, many NYC neighborhoods have experienced **measurable environmental progress**, contributing to healthier living conditions and providing a roadmap for further citywide improvements.
`
)}

function _49(md){return(
md`### 3.8 Policies to improve Air Quality in NYC`
)}

function _50(md){return(
md`**Question 8: What actions or policies could improve air quality in NYC based on the data trends?**

Based on the air quality data trends analyzed in previous sections, several policy directions are recommended to further improve air quality in New York City:

#### 1. Strengthen Traffic Emission Regulations
- **Rationale:** NO₂ and PM2.5 levels are highest in districts with high traffic density, such as Midtown and Lower Manhattan.
- **Recommendation:** Expand low-emission zones (LEZs), increase the adoption of electric vehicles, and implement stricter emissions standards for commercial vehicles and public transportation fleets.

#### 2. Target High-Risk Districts for Localized Intervention
- **Rationale:** Community districts such as CD5, CD6, and CD17 exhibit both historically high pollution and recent improvements, indicating successful interventions.
- **Recommendation:** Replicate effective policies from these areas in districts still facing high pollution levels, using localized monitoring and policy customization.

#### 3. Expand Urban Green Infrastructure
- **Rationale:** Vegetation can reduce particulate matter and improve local microclimates.
- **Recommendation:** Increase investment in urban greening projects, such as green roofs, tree planting programs, and vegetated buffers near major roads and industrial zones.

#### 4. Improve Public Transit and Reduce Private Vehicle Dependence
- **Rationale:** Transportation remains a key source of air pollutants, especially NO₂ and O₃ precursors.
- **Recommendation:** Enhance accessibility and reliability of public transit systems, promote active commuting (e.g., cycling and walking), and implement congestion pricing in high-traffic zones.

#### 5. Strengthen Industrial Emission Controls
- **Rationale:** Historical data shows elevated levels of benzene and formaldehyde in some boroughs, likely tied to industrial activity.
- **Recommendation:** Enforce updated air quality standards for industrial emissions, promote cleaner production technologies, and restrict zoning for high-emission facilities near residential areas.

#### 6. Promote Transparency and Public Participation
- **Rationale:** Granular air quality data has been critical for identifying spatial disparities.
- **Recommendation:** Expand real-time public access to air quality monitoring data, support community-based air monitoring initiatives, and integrate public input into environmental planning processes.
`
)}

function _51(md){return(
md`---`
)}

function _52(md){return(
md`## 4 Conclusion`
)}

function _53(md){return(
md`This report provides an in-depth analysis of air quality trends in New York City from 2005 to 2023, synthesizing insights across seven key thematic areas (Sections 3.1–3.7). Drawing on a comprehensive dataset and multiple pollutant indicators, the findings reveal both encouraging progress and persistent environmental disparities.

1. **Long-Term Trends (Section 3.1 & 3.5):**  
   Analysis of five major pollutants—**PM2.5**, **NO₂**, **O₃**, **Benzene**, and **Formaldehyde**—shows a general **downward trend in pollution levels**, especially for PM2.5 and NO₂, reflecting the impact of regulatory efforts such as cleaner fuel standards and emissions controls. Notably, benzene and formaldehyde concentrations dropped sharply between 2005 and 2014, indicating successful mitigation of industrial toxins. However, **ozone (O₃)** levels remained relatively **stable or increased** slightly, suggesting the need for additional strategies to address secondary pollutants.

2. **Spatial Disparities by Community Districts (Section 3.2):**  
   Air quality is not evenly distributed across NYC. Districts with **higher urban density and traffic congestion**, such as Midtown (CD5), Gramercy Park–Murray Hill (CD6), and Chelsea–Clinton (CD4), recorded the **highest average NO₂ concentrations**, exceeding 30 ppb in some cases. In contrast, outer boroughs like Staten Island and parts of Queens had consistently lower pollutant levels, underscoring inequities tied to land use, infrastructure, and socioeconomic patterns.

3. **Seasonal Variation (Section 3.3):**  
   A clear **seasonal pattern** was observed, especially for NO₂: **winter levels were consistently 5–10 ppb higher than summer values** due to increased heating demands and atmospheric inversions. Although overall NO₂ levels declined over time, the seasonal gap remained persistent, highlighting the importance of **season-specific interventions**, such as promoting cleaner winter heating technologies.

4. **Traffic Influence (Section 3.4):**  
   Correlation analysis confirmed strong associations between **traffic activity** (vehicle miles traveled) and pollutant levels. NO₂ and PM2.5 were **highly correlated** with car and truck traffic (r > 0.77), while also linked to negative health outcomes such as asthma and hospitalizations. In contrast, ozone showed **negative correlations** with traffic-related metrics, likely due to NO titration in high-emission areas. These findings reinforce the **critical role of transportation emissions** in shaping NYC’s air quality.

5. **Borough-Level Inequities (Section 3.6):**  
   Across the five boroughs, **Manhattan exhibited the highest PM2.5 and NO₂ levels** throughout the period, while **Queens and Staten Island consistently showed the lowest**. Though all boroughs experienced improvement over time, **the inter-borough pollution gap remains**—pointing to unequal environmental burdens and the need for borough-specific mitigation efforts.

6. **Districts with Greatest Improvement (Section 3.7):**  
   Districts such as **CD6, CD17, and CD16** saw the most substantial reductions in air pollution, with declines of **25 to 50 units**. These improvements suggest that **targeted policies**, such as emission controls and infrastructure upgrades, may have played a major role in driving air quality gains in these areas.

---

### Summary

In summary, the data reveals a **citywide improvement in air quality**, particularly for traffic-related and industrial pollutants, yet underscores **persistent spatial and seasonal disparities**. Pollution remains disproportionately concentrated in central Manhattan and during winter months, with strong links to traffic activity and built environment characteristics.

To address these challenges, future policies must prioritize:

- Equitable interventions in high-risk districts
- Seasonal heating-related emissions management
- Continued reduction of traffic and industrial sources
- Public transparency and engagement through open data

By building on the gains of the past two decades and addressing identified gaps, New York City can move toward a more sustainable and health-equitable urban environment.
`
)}

function _54(md){return(
md`---`
)}

function _55(md){return(
md`## References


1. Brook RD, Rajagopalan S, Pope CA 3rd, Brook JR, Bhatnagar A, Diez-Roux AV, et al. Particulate matter air pollution and cardiovascular disease: An update to the scientific statement from the American Heart Association. *Circulation*. 2010;121(21):2331–78.

2. World Health Organization. Ambient (outdoor) air pollution. 2021. Available from: https://www.who.int/news-room/fact-sheets/detail/ambient-(outdoor)-air-quality-and-health

3. U.S. Environmental Protection Agency. Integrated Science Assessment for Particulate Matter. EPA/600/R-23/001. 2023. Available from: https://www.epa.gov/isa/integrated-science-assessments-isa

4. Schraufnagel DE, Balmes JR, Cowl CT, De Matteis S, Jung SH, Mortimer K, et al. Air pollution and noncommunicable diseases: A review by the Forum of International Respiratory Societies’ Environmental Committee. *Chest*. 2019;155(2):409–416.

5. Cohen AJ, Brauer M, Burnett R, Anderson HR, Frostad J, Estep K, et al. Estimates and 25-year trends of the global burden of disease attributable to ambient air pollution: An analysis of data from the Global Burden of Disease Study 2015. *The Lancet*. 2017;389(10082):1907–1918.

6. World Health Organization. Air pollution. 2022. Available from: https://www.who.int/health-topics/air-pollution#tab=tab_1

7. Jerrett M, Burnett RT, Pope CA 3rd, Ito K, Thurston G, Krewski D, et al. Long-term ozone exposure and mortality. *N Engl J Med*. 2009;360(11):1085–1095.

8. Marshall JD, Nethery E, Brauer M. Within-urban variability in ambient air pollution: Comparison of estimation methods. *Atmos Environ*. 2008;42(6):1359–1369.

9. Azad S, Ferrer-Cid P, Ghandehari M. Exposure to fine particulate matter in the New York City subway system during home-work commute. *PLOS ONE*. 2024;19(8):e0307096. https://doi.org/10.1371/journal.pone.0307096

10. Vilcassim MJR, Thurston GD, Peltier RE, Gordon T. Black carbon and particulate matter (PM2.5) concentrations in New York City’s subway stations. *Environ Sci Technol*. 2014;48(24):14738–14745.

11. Bell ML, Ebisu K, Belanger K. Ambient air pollution and low birth weight in Connecticut and Massachusetts. *Environ Health Perspect*. 2007;115(7):1118–1124.`
)}

function _56(md){return(
md`---
## Appendix`
)}

function _data(FileAttachment){return(
FileAttachment("Air_Quality_20250406.csv").csv()
)}

function _59(md){return(
md`---`
)}

function _names_filter(){return(
[
  "Fine particles (PM 2.5)",
  "Nitrogen dioxide (NO2)",
  "Outdoor Air Toxics - Benzene",
  "Outdoor Air Toxics - Formaldehyde",
  "Ozone (O3)"
]
)}

function _data1(data,names_filter,d3)
{
  const filteredData = data.filter(d => names_filter.includes(d.Name));

  filteredData.forEach(d => {
    d.Start_Date = new Date(d.Start_Date);
    d["Data Value"] = +d["Data Value"];
  });
  const formatDate = d3.timeFormat("%Y-%m-%d");
  const processedData = names_filter.map(name => {
    const pollutantData = filteredData.filter(d => d.Name === name);
    const unit = pollutantData[0]["Measure Info"];
    const grouped = d3.group(pollutantData, d => formatDate(d.Start_Date));
    const aggregated = Array.from(grouped, ([date, values]) => {
      return {
        Start_Date: new Date(date),
        average: d3.mean(values, d => d["Data Value"])
      };
    });
    aggregated.sort((a, b) => a.Start_Date - b.Start_Date);
    return { name, unit, data: aggregated };
  });
  return processedData;
}


function _dataset1(data1,selectedPollutant1)
{
  const pollutant = data1.find(d => d.name === selectedPollutant1);
  return pollutant.data.map(d => ({
    date: new Date(d.Start_Date),
    unit: pollutant.unit,
    average: d.average
  }));
}


function _63(md){return(
md`---`
)}

function _no2_data(data){return(
data.filter(d => d.Name === "Nitrogen dioxide (NO2)")
)}

function _no2_by_place(d3,no2_data){return(
Array.from(
  d3.rollup(
    no2_data,
    v => d3.mean(v, d => +d["Data Value"]),
    d => d["Geo Place Name"]
  ),
  ([place, avg]) => ({ place, avg_no2: avg.toFixed(2) })
)
)}

function _no2_by_place_sorted(no2_by_place){return(
no2_by_place.sort((a, b) => b.avg_no2 - a.avg_no2)
)}

function _dataset2(no2_by_place_sorted){return(
no2_by_place_sorted
    .map(d => ({ place: d.place, avg_no2: +d.avg_no2 }))
)}

function _dataFlat(dataset2){return(
dataset2.map(d => ({ id: d.place, value: d.avg_no2 }))
)}

function _69(md){return(
md`---`
)}

function _data3(data,d3)
{
  const filtered_data = data.filter(d => d.Name === "Nitrogen dioxide (NO2)");
  const winter_summer_data = filtered_data.filter(d => /Winter|Summer/i.test(d["Time Period"]));

  const groups = d3.group(winter_summer_data, d => d["Time Period"]);
  const grouped = Array.from(groups, ([timePeriod, values]) => {
    const avgValue = d3.mean(values, d => +d["Data Value"]);
    return { "Time Period": timePeriod, "Data Value": avgValue };
  });

  function sortKey(tp) {
    if (tp.startsWith("Summer")) {
      let parts = tp.split(" ");
      let year = +parts[1];
      return [year, 1];
    } else if (tp.startsWith("Winter")) {
      let parts = tp.split(" ");
      let range = parts[1];
      let [start_year_str, end_year_str] = range.split("-");
      if (end_year_str.length === 2) {
        let year = +(start_year_str.slice(0, 2) + end_year_str);
        return [year, 0];
      } else {
        let year = +end_year_str;
        return [year, 0];
      }
    } else {
      return [9999, 2];
    }
  }
  
  grouped.sort((a, b) => {
    const [yearA, orderA] = sortKey(a["Time Period"]);
    const [yearB, orderB] = sortKey(b["Time Period"]);
    return (yearA - yearB) || (orderA - orderB);
  });
  
  return grouped;
}


function _dataset3(data3){return(
data3.map(d => ({
  period: d["Time Period"],
  value: +d["Data Value"]
}))
)}

function _72(md){return(
md`---`
)}

function _pivotMap(data,d3)
{
  data.forEach(d => {
    d["Data Value"] = +d["Data Value"];
    d["Start_Date"] = new Date(d["Start_Date"]);
  });
  const pivotMap = d3.rollup(
    data,
    v => d3.mean(v, d => d["Data Value"]),
    d => d["Geo Place Name"],
    d => d["Name"]
  );
  return pivotMap;
}


function _corrMatrix(pivotMap)
{
  const geoPlaces = Array.from(pivotMap.keys());
  const pollutantsSet = new Set();
  for (let [, pollutantMap] of pivotMap) {
    for (let pollutant of pollutantMap.keys()) {
      pollutantsSet.add(pollutant);
    }
  }
  const pollutants = Array.from(pollutantsSet);

  const pivot = geoPlaces.map(geo => {
    const pollutantMap = pivotMap.get(geo);
    let row = { "Geo Place Name": geo };
    pollutants.forEach(pollutant => {
      row[pollutant] = pollutantMap.has(pollutant) ? pollutantMap.get(pollutant) : NaN;
    });
    return row;
  });

  function mean(arr) {
    return arr.reduce((s, x) => s + x, 0) / arr.length;
  }
  function std(arr, meanVal) {
    return Math.sqrt(arr.reduce((s, x) => s + Math.pow(x - meanVal, 2), 0) / (arr.length - 1));
  }
  function pearson(x, y) {
    const n = x.length;
    if (n < 2) return NaN;
    const meanX = mean(x);
    const meanY = mean(y);
    const cov = x.reduce((s, xi, i) => s + (xi - meanX) * (y[i] - meanY), 0) / (n - 1);
    const stdX = std(x, meanX);
    const stdY = std(y, meanY);
    return cov / (stdX * stdY);
  }
  const corrMatrix = {};
  pollutants.forEach(p1 => {
    corrMatrix[p1] = {};
    pollutants.forEach(p2 => {
      const pairs = pivot.reduce((acc, row) => {
        const v1 = row[p1];
        const v2 = row[p2];
        if (!isNaN(v1) && !isNaN(v2)) {
          acc.push([v1, v2]);
        }
        return acc;
      }, []);
      const x = pairs.map(d => d[0]);
      const y = pairs.map(d => d[1]);
      corrMatrix[p1][p2] = x.length > 1 ? pearson(x, y) : NaN;
    });
  })

  return corrMatrix;
}


function _flatCorr(corrMatrix)
{
  const flatCorr = [];
  Object.entries(corrMatrix).forEach(([p1, inner]) => {
    Object.entries(inner).forEach(([p2, corr]) => {
      flatCorr.push({
        "Source": p1,
        "Target": p2,
        "Correlation": corr
      });
    });
  });
  return flatCorr;
}


function _76(md){return(
md`---`
)}

function _data_with_year(data){return(
data.map(d => ({
  ...d,
  year: new Date(d["Start_Date"]).getFullYear()
}))
)}

function _selected_pollutants(){return(
[
  "Fine particles (PM 2.5)",
  "Nitrogen dioxide (NO2)",
  "Outdoor Air Toxics - Benzene",
  "Outdoor Air Toxics - Formaldehyde",
  "Ozone (O3)"
]
)}

function _filtered_data(data_with_year,selectedPollutant){return(
data_with_year.filter(d => d.Name === selectedPollutant)
)}

function _pollution_sum_array(pollution_sum_by_year){return(
Array.from(pollution_sum_by_year, ([year, value]) => ({year, value}))
)}

function _pollution_sum_by_year(d3,filtered_data){return(
d3.rollup(
  filtered_data,
  v => d3.sum(v, d => +d["Data Value"]),
  d => d.year
)
)}

function _82(md){return(
md`---`
)}

function _data6(data,names_filter,d3)
{
  const filteredData = data.filter(d =>
    names_filter.includes(d.Name) && d["Geo Type Name"] === "Borough"
  );
  
  filteredData.forEach(d => {
    d.Start_Date = new Date(d.Start_Date);
    d["Data Value"] = +d["Data Value"];
  });
  
  const processedData = names_filter.map(pollutant => {
    const pollutantData = filteredData.filter(d => d.Name === pollutant);
    const unit = pollutantData[0]["Measure Info"];
    const groupedByBorough = d3.group(pollutantData, d => d["Geo Place Name"]);
    const boroughData = Array.from(groupedByBorough, ([borough, records]) => {
      const groupedByDate = d3.rollup(
        records,
        v => d3.mean(v, d => d["Data Value"]),
        d => d3.timeFormat("%Y-%m-%d")(d.Start_Date)
      );
      const dateData = Array.from(groupedByDate, ([dateStr, avg]) => ({
        Start_Date: new Date(dateStr),
        average: avg
      }));
      dateData.sort((a, b) => a.Start_Date - b.Start_Date);
      return { borough, unit, data: dateData };
    });
    
    return { pollutant, boroughData };
  });
  return processedData;
}


function _dataset6(data6,selectedPollutant6)
{
  const rec = data6.find(d => d.pollutant === selectedPollutant6).boroughData;
  return rec.flatMap(b =>
    b.data.map(pt => ({
      borough: b.borough,
      unit: rec[0].unit,
      date: pt.Start_Date,
      average: pt.average
    }))
  );
}


function _85(md){return(
md`---`
)}

function _data_with_cd(data_with_year){return(
data_with_year.map(d => ({
  ...d,
  community_district: d["Geo Place Name"].match(/\(CD\d+\)/)?.[0] ?? null
})).filter(d => d.community_district !== null)
)}

function _pollution_by_cd_and_year(d3,data_with_cd){return(
d3.rollup(
  data_with_cd,
  v => d3.mean(v, d => +d["Data Value"]),
  d => d.community_district,
  d => d.year
)
)}

function _area_changes(pollution_by_cd_and_year)
{
  let changes = []
  for (let [cd, yearMap] of pollution_by_cd_and_year) {
    let years = Array.from(yearMap.keys()).sort()
    if (years.length >= 2) {
      let firstYear = years[0]
      let lastYear = years[years.length - 1]
      let change = yearMap.get(lastYear) - yearMap.get(firstYear)
      changes.push({
        area: cd,
        firstYear,
        lastYear,
        startValue: yearMap.get(firstYear),
        endValue: yearMap.get(lastYear),
        change
      })
    }
  }
  return changes
}


function _sorted_area_changes(area_changes){return(
area_changes.toSorted((a, b) => a.change - b.change)
)}

function _top_improvements(sorted_area_changes){return(
sorted_area_changes.slice(0, 10)
)}

export default function define(runtime, observer) {
  const main = runtime.module();
  function toString() { return this.url; }
  const fileAttachments = new Map([
    ["Air_Quality_20250406.csv", {url: new URL("./files/0a9fffe01f039b2a78ad31d3a73b2d30009fbe755cf96468c853e9662d3cf5547d4533ed907f25e4052caa343b1ab8f111e9aff8a7af90cbd63cc6add88d84c1.csv", import.meta.url), mimeType: "text/csv", toString}]
  ]);
  main.builtin("FileAttachment", runtime.fileAttachments(name => fileAttachments.get(name)));
  main.variable(observer()).define(["md"], _1);
  main.variable(observer()).define(["md"], _2);
  main.variable(observer()).define(["md"], _3);
  main.variable(observer()).define(["md"], _4);
  main.variable(observer()).define(["md"], _5);
  main.variable(observer()).define(["md"], _6);
  main.variable(observer()).define(["md"], _7);
  main.variable(observer()).define(["md"], _8);
  main.variable(observer()).define(["md"], _9);
  main.variable(observer()).define(["md"], _10);
  main.variable(observer()).define(["md"], _11);
  main.variable(observer()).define(["md"], _12);
  main.variable(observer()).define(["md"], _13);
  main.variable(observer()).define(["Inputs","data"], _14);
  main.variable(observer()).define(["md"], _15);
  main.variable(observer()).define(["md"], _16);
  main.variable(observer()).define(["md"], _17);
  main.variable(observer()).define(["md"], _18);
  main.variable(observer("viewof selectedPollutant1")).define("viewof selectedPollutant1", ["Inputs","names_filter"], _selectedPollutant1);
  main.variable(observer("selectedPollutant1")).define("selectedPollutant1", ["Generators", "viewof selectedPollutant1"], (G, _) => G.input(_));
  main.variable(observer()).define(["Plot","dataset1"], _20);
  main.variable(observer()).define(["md"], _21);
  main.variable(observer()).define(["md"], _22);
  main.variable(observer()).define(["md"], _23);
  main.variable(observer()).define(["Legend","d3","dataFlat"], _24);
  main.variable(observer("chart")).define("chart", ["d3","dataFlat"], _chart);
  main.variable(observer()).define(["md"], _26);
  main.variable(observer()).define(["md"], _27);
  main.variable(observer()).define(["md"], _28);
  main.variable(observer()).define(["Swatches","d3"], _29);
  main.variable(observer()).define(["d3","dataset3"], _30);
  main.variable(observer()).define(["md"], _31);
  main.variable(observer()).define(["md"], _32);
  main.variable(observer()).define(["Legend","d3"], _33);
  main.variable(observer()).define(["d3","flatCorr"], _34);
  main.variable(observer()).define(["md"], _35);
  main.variable(observer()).define(["md"], _36);
  main.variable(observer("viewof selectedPollutant")).define("viewof selectedPollutant", ["Inputs","selected_pollutants"], _selectedPollutant);
  main.variable(observer("selectedPollutant")).define("selectedPollutant", ["Generators", "viewof selectedPollutant"], (G, _) => G.input(_));
  main.variable(observer()).define(["Plot","pollution_sum_array"], _38);
  main.variable(observer()).define(["md"], _39);
  main.variable(observer()).define(["md"], _40);
  main.variable(observer()).define(["md"], _41);
  main.variable(observer("viewof selectedPollutant6")).define("viewof selectedPollutant6", ["Inputs","names_filter"], _selectedPollutant6);
  main.variable(observer("selectedPollutant6")).define("selectedPollutant6", ["Generators", "viewof selectedPollutant6"], (G, _) => G.input(_));
  main.variable(observer()).define(["Plot","dataset6"], _43);
  main.variable(observer()).define(["md"], _44);
  main.variable(observer()).define(["md"], _45);
  main.variable(observer()).define(["md"], _46);
  main.variable(observer()).define(["Plot","top_improvements"], _47);
  main.variable(observer()).define(["md"], _48);
  main.variable(observer()).define(["md"], _49);
  main.variable(observer()).define(["md"], _50);
  main.variable(observer()).define(["md"], _51);
  main.variable(observer()).define(["md"], _52);
  main.variable(observer()).define(["md"], _53);
  main.variable(observer()).define(["md"], _54);
  main.variable(observer()).define(["md"], _55);
  main.variable(observer()).define(["md"], _56);
  const child1 = runtime.module(define1);
  main.import("Legend", child1);
  main.import("Swatches", child1);
  main.variable(observer("data")).define("data", ["FileAttachment"], _data);
  main.variable(observer()).define(["md"], _59);
  main.variable(observer("names_filter")).define("names_filter", _names_filter);
  main.variable(observer("data1")).define("data1", ["data","names_filter","d3"], _data1);
  main.variable(observer("dataset1")).define("dataset1", ["data1","selectedPollutant1"], _dataset1);
  main.variable(observer()).define(["md"], _63);
  main.variable(observer("no2_data")).define("no2_data", ["data"], _no2_data);
  main.variable(observer("no2_by_place")).define("no2_by_place", ["d3","no2_data"], _no2_by_place);
  main.variable(observer("no2_by_place_sorted")).define("no2_by_place_sorted", ["no2_by_place"], _no2_by_place_sorted);
  main.variable(observer("dataset2")).define("dataset2", ["no2_by_place_sorted"], _dataset2);
  main.variable(observer("dataFlat")).define("dataFlat", ["dataset2"], _dataFlat);
  main.variable(observer()).define(["md"], _69);
  main.variable(observer("data3")).define("data3", ["data","d3"], _data3);
  main.variable(observer("dataset3")).define("dataset3", ["data3"], _dataset3);
  main.variable(observer()).define(["md"], _72);
  main.variable(observer("pivotMap")).define("pivotMap", ["data","d3"], _pivotMap);
  main.variable(observer("corrMatrix")).define("corrMatrix", ["pivotMap"], _corrMatrix);
  main.variable(observer("flatCorr")).define("flatCorr", ["corrMatrix"], _flatCorr);
  main.variable(observer()).define(["md"], _76);
  main.variable(observer("data_with_year")).define("data_with_year", ["data"], _data_with_year);
  main.variable(observer("selected_pollutants")).define("selected_pollutants", _selected_pollutants);
  main.variable(observer("filtered_data")).define("filtered_data", ["data_with_year","selectedPollutant"], _filtered_data);
  main.variable(observer("pollution_sum_array")).define("pollution_sum_array", ["pollution_sum_by_year"], _pollution_sum_array);
  main.variable(observer("pollution_sum_by_year")).define("pollution_sum_by_year", ["d3","filtered_data"], _pollution_sum_by_year);
  main.variable(observer()).define(["md"], _82);
  main.variable(observer("data6")).define("data6", ["data","names_filter","d3"], _data6);
  main.variable(observer("dataset6")).define("dataset6", ["data6","selectedPollutant6"], _dataset6);
  main.variable(observer()).define(["md"], _85);
  main.variable(observer("data_with_cd")).define("data_with_cd", ["data_with_year"], _data_with_cd);
  main.variable(observer("pollution_by_cd_and_year")).define("pollution_by_cd_and_year", ["d3","data_with_cd"], _pollution_by_cd_and_year);
  main.variable(observer("area_changes")).define("area_changes", ["pollution_by_cd_and_year"], _area_changes);
  main.variable(observer("sorted_area_changes")).define("sorted_area_changes", ["area_changes"], _sorted_area_changes);
  main.variable(observer("top_improvements")).define("top_improvements", ["sorted_area_changes"], _top_improvements);
  return main;
}
