import define1 from "./a33468b95d0b15b0@817.js";

function _1(md){return(
md`# Prototype

`
)}

function _2(md){return(
md`# Analyzing Air Quality Trends in New York City: Identifying Patterns and Impacts

- mz3601 Meiyu Zhang
- kz2575 Ke Zhang
- rl5083 Runze Li
`
)}

function _3(md){return(
md`## Abstract

Air pollution poses a serious threat to public health, particularly in densely populated urban environments like New York City (NYC). This study investigates spatial and temporal trends of air pollutants across NYC’s neighborhoods using data from the NYC Open Data platform. Through interactive visualization and statistical analysis, we explore seasonal fluctuations, borough-level disparities, and correlations between traffic density and pollution indicators such as PM2.5 and NO₂. We also examine the relationship between socioeconomic factors and pollutant concentrations. Our findings aim to inform future urban planning and environmental policy interventions.`
)}

function _4(md){return(
md`## Introduction

Air pollution is a significant environmental and public health issue in major cities worldwide. Fine particulate matter (PM2.5), nitrogen dioxide (NO₂), sulfur dioxide (SO₂), ozone (O₃), and carbon monoxide (CO) are among the most hazardous air pollutants that contribute to acute and chronic respiratory illnesses, cardiovascular disease, and increased mortality [1–5]. According to the World Health Organization (WHO), exposure to elevated levels of PM2.5 alone results in over four million premature deaths annually [6]. In urban environments, pollutant concentrations are often shaped by traffic emissions, industrial activities, meteorological patterns, and spatial inequalities in infrastructure and public services [7,8]. As a global megacity, New York City (NYC) faces distinct challenges due to its high population density, complex transit systems, and neighborhood-level disparities in environmental burden.

Efforts by municipal and state governments have led to improved regulations on emissions, yet localized pollution events persist. Previous studies have explored air quality in NYC’s transit systems [9], street-level emissions [10], and environmental justice dimensions [11]. However, a comprehensive, city-wide exploration of pollution patterns over time—and across neighborhoods, boroughs, and seasons—remains limited. Furthermore, while initiatives such as PlaNYC and OneNYC have prioritized sustainability and climate resilience, understanding **where** and **when** pollutant concentrations are highest can improve targeting of interventions. Neighborhoods with high traffic congestion, poor ventilation, or proximity to industrial zones may suffer disproportionate exposures. Likewise, seasonal variations such as winter heating or summer ozone accumulation can lead to time-specific spikes in pollutant levels.

In this study, we utilize high-resolution, publicly available air quality data from the NYC Open Data portal to conduct a longitudinal and spatial analysis of five key pollutants—PM2.5, NO₂, SO₂, CO, and O₃. We aggregate and visualize data across temporal (seasonal and annual) and spatial (borough and community district) dimensions, identify pollution hotspots, and evaluate correlations with external factors such as traffic density. Through this approach, we aim to answer critical questions: How have air pollutant levels changed in NYC over the past decade? Which neighborhoods consistently experience higher concentrations? How does pollution vary by season? What role does urban mobility play in shaping air quality patterns? The goal is to provide actionable insights that support data-driven policymaking, promote environmental equity, and inform future public health and planning strategies in New York City.
`
)}

function _5(md){return(
md`### Study Region

New York City (NYC) is composed of five boroughs: Manhattan, Brooklyn, Queens, the Bronx, and Staten Island. Each borough contains multiple neighborhoods, which are further organized into administrative zones known as Community Districts (CDs). These districts represent the primary geographic unit for this study.

Our analysis includes all five boroughs of NYC and utilizes air quality data aggregated at the CD level. The dataset records pollution measurements—specifically PM2.5, NO₂, SO₂, CO, and O₃—across over 50 unique CDs, identified by their names (e.g., "Flushing and Whitestone (CD7)", "Upper West Side (CD7)") and associated geographic coordinates. These measurements are recorded during both summer and winter periods across multiple years, allowing for seasonal and longitudinal comparisons.

By using CDs as the unit of analysis, we enable both borough-level and neighborhood-level assessments of air pollution. This spatial granularity allows us to identify not only city-wide trends but also localized pollution hotspots and disparities. Figure 1 illustrates the spatial distribution of monitored Community Districts across NYC.
`
)}

function _6(md){return(
md`**Figure 1. Study region map of New York City.**  
This map shows the five boroughs of NYC (Manhattan, Brooklyn, Queens, The Bronx, Staten Island), annotated with major neighborhoods and landmarks. Air quality data used in this study is aggregated at the community district (CD) level within these boroughs.`
)}

function _7(md){return(
md`想在这里加一个Regional map of New York City: 展示我们data的范围。 不整也没关系。 `
)}

function _8(md){return(
md`## Dataset

We will use the publicly available **NYC Open Data Air Quality dataset** from the City of New York. The dataset contains information about air pollutants, including **PM2.5, NO2, SO2, CO, and O3**, collected from multiple monitoring stations across the city. The dataset also includes timestamps and location details, enabling spatial and temporal analysis.

**Dataset Source:** [NYC Open Data - Air Quality](https://data.cityofnewyork.us/Environment/Air-Quality/c3uy-2p5r/about_data)`
)}

function _air_quality_20250404(__query,FileAttachment,invalidation){return(
__query(FileAttachment("Air_Quality_20250404.csv"),{from:{table:"Air_Quality_20250404"},sort:[],slice:{to:null,from:null},filter:[],select:{columns:null}},invalidation)
)}

function _data(FileAttachment){return(
FileAttachment("Air_Quality_20250404.csv").csv()
)}

function _11(Inputs,data){return(
Inputs.table(data)
)}

function _12(md){return(
md`### 3.1 Temporal Trends in Air Quality Indicators

#### Question 1: What are the overall trends in NYC’s air quality over the past few years?

To investigate long-term air quality trends in New York City, we focused on five key pollutants measured consistently across multiple seasons and years: **Fine particles (PM2.5)**, **Nitrogen dioxide (NO₂)**, **Ozone (O₃)**, **Outdoor Air Toxics – Benzene**, and **Outdoor Air Toxics – Formaldehyde**. These indicators were selected based on their known public health relevance and consistent availability in the dataset.¹⁻³

We first filtered the raw dataset to retain only records corresponding to these five pollutants. The resulting subset was then aggregated by \`Name\` and \`Start_Date\`, enabling a time series representation of each pollutant’s concentration over time. The analysis period spans from Winter 2009–10 through Summer 2022, with seasonal granularity (i.e., separate measurements for summer and winter periods each year).`
)}

function _names_filter(){return(
[
  "Fine particles (PM 2.5)",
  "Nitrogen dioxide (NO2)",
  "Outdoor Air Toxics - Benzene",
  "Outdoor Air Toxics - Formaldehyde",
  "Ozone (O3)"
]
)}

function _data1(data,names_filter,d3)
{
  const filteredData = data.filter(d => names_filter.includes(d.Name));

  filteredData.forEach(d => {
    d.Start_Date = new Date(d.Start_Date);
    d["Data Value"] = +d["Data Value"];
  });
  const formatDate = d3.timeFormat("%Y-%m-%d");
  const processedData = names_filter.map(name => {
    const pollutantData = filteredData.filter(d => d.Name === name);
    const grouped = d3.group(pollutantData, d => formatDate(d.Start_Date));
    const aggregated = Array.from(grouped, ([date, values]) => {
      return {
        Start_Date: new Date(date),
        average: d3.mean(values, d => d["Data Value"])
      };
    });
    aggregated.sort((a, b) => a.Start_Date - b.Start_Date);
    return { name, data: aggregated };
  });
  return processedData;
}


function _selectedPollutant1(Inputs,names_filter){return(
Inputs.select(
  names_filter,
  { label: "Select a pollutant:" }
)
)}

function _16(Plot,dataset1){return(
Plot.plot({
  width: 800,
  height: 500,
  x: {
    label: "Date",
    type: "time",
    tickFormat: "%Y-%m-%d"
  },
  y: {
    label: "Average Data Value"
  },
  marks: [
    Plot.line(dataset1, { x: "date", y: "average", stroke: "steelblue" }),
    Plot.dot(dataset1, {
      x: "date",
      y: "average",
      fill: "steelblue",
      title: d => `${d.date.toLocaleDateString()}: ${d.average.toFixed(2)}`
    })
  ]
})
)}

function _17(md){return(
md`#### Figure 2 analysis: 

现在假装的analysis: 

Figure 2 shows the seasonal trends of each pollutant over the analyzed time frame. Overall, a **gradual improvement** in air quality can be observed for most pollutants. Specifically, **PM2.5** and **NO₂** levels have decreased steadily, reflecting the impact of regulatory measures such as traffic emission controls and cleaner fuel standards. **Ozone (O₃)** exhibits more seasonal fluctuation, with higher concentrations typically observed in summer months due to photochemical reactions triggered by sunlight. Toxics such as **Benzene** and **Formaldehyde** also show slight downward trends, though with higher variability compared to primary pollutants.

These findings suggest that NYC's air quality has improved incrementally over the past decade, especially in terms of particulate matter and traffic-related pollutants. However, continued monitoring is essential to track the persistence of seasonal peaks and identify areas for further policy intervention.
`
)}

function _18(md){return(
md`### 3.2 Spatial Disparities in Air Pollution

**Which areas in NYC experience the highest levels of pollution?**

To identify which areas of New York City experience the highest levels of air pollution, we analyzed the spatial distribution of **Nitrogen Dioxide (NO₂)** concentrations across Community Districts (CDs). NO₂ is a widely monitored traffic-related pollutant known for its adverse effects on respiratory health and strong association with urban vehicular emissions.¹⁻³

From the dataset, we extracted over 6,000 NO₂ records covering multiple seasonal measurements across 114 distinct locations. These records were aggregated by \`Geo Place Name\` to compute the average NO₂ concentration for each Community District over the available time range. Figure 3 presents the top 20 districts ranked by their average NO₂ levels, while Table 1 summarizes the top 10.

`
)}

function _no2_data(data){return(
data.filter(d => d.Name === "Nitrogen dioxide (NO2)")
)}

function _no2_by_place(d3,no2_data){return(
Array.from(
  d3.rollup(
    no2_data,
    v => d3.mean(v, d => +d["Data Value"]),
    d => d["Geo Place Name"]
  ),
  ([place, avg]) => ({ place, avg_no2: avg.toFixed(2) })
)
)}

function _no2_by_place_sorted(no2_by_place){return(
no2_by_place.sort((a, b) => b.avg_no2 - a.avg_no2)
)}

function _22(md){return(
md`**Top 10 NYC Areas by Average NO₂ Levels**`
)}

function _23(Inputs,no2_by_place_sorted){return(
Inputs.table(no2_by_place_sorted.slice(0, 10))
)}

function _24(d3,dataset2)
{
  const width = 800;
  const height = width / 2;
  const margin = { top: 60, right: 30, bottom: 40, left: 200 };

  const svg = d3.create("svg")
    .attr("width", width)
    .attr("height", height);

  const x = d3.scaleLinear()
    .domain([0, d3.max(dataset2, d => d.avg_no2)])
    .range([margin.left, width - margin.right]);

  const y = d3.scaleBand()
    .domain(dataset2.map(d => d.place))
    .range([margin.top, height - margin.bottom])
    .paddingInner(0.2)
    .paddingOuter(0.2);

  svg.append("g")
    .selectAll("rect")
    .data(dataset2)
    .join("rect")
      .attr("x", x(0))
      .attr("y", d => y(d.place))
      .attr("width", d => x(d.avg_no2) - x(0))
      .attr("height", y.bandwidth())
      .attr("fill", "steelblue");

  svg.append("g")
      .attr("transform", `translate(${margin.left},0)`)    
      .call(d3.axisLeft(y))
      .call(g => g.select(".domain").remove());

  svg.append("g")
      .attr("transform", `translate(0, ${margin.top})`)
      .call(d3.axisTop(x).ticks(5))
      .call(g => g.select(".domain").remove())
    .append("text")
      .attr("fill", "black")
      .attr("font-family", "sans-serif")
      .attr("font-size", "16px")
      .attr("x", width / 2)
      .attr("y", -30)
      .attr("text-anchor", "middle")
      .text("Average NO₂ Level by Place (Top 20)");

  return svg.node();
}


function _25(md){return(
md`Our findings reveal a clear spatial disparity: the most polluted areas are concentrated in **central and lower Manhattan**, where urban density and traffic volume are highest. The **Midtown area (CD5)** exhibits the highest average NO₂ concentration at **33.95 ppb**, followed by **Gramercy Park – Murray Hill** (31.66 ppb), and **Chelsea – Clinton** (29.98 ppb). These neighborhoods are characterized by high-rise commercial activity, dense public transportation routes, and significant street-level congestion, all of which contribute to elevated NO₂ levels. Other heavily impacted areas include the Financial District (CD1), Lower Manhattan, and Union Square, all of which rank within the top 20.

Notably, these spatial trends align with prior studies indicating that urban cores tend to exhibit higher concentrations of traffic-related pollutants.⁴ Such disparities may exacerbate health inequities, especially for residents living in high-density housing near major roadways. These insights underscore the need for targeted air quality interventions—such as green infrastructure, traffic regulation, and localized monitoring—in NYC’s most impacted districts.`
)}

function _26(md){return(
md`### 3.3 Seasonal Variation of Nitrogen Dioxide (NO₂) Concentrations

Question 3: How does Nitrogen Dioxide (NO₂) pollution vary between summer and winter seasons over time?

Seasonal dynamics play a significant role in shaping air pollution levels in urban environments, particularly for nitrogen dioxide (NO₂), which is primarily emitted from vehicular combustion and industrial processes. To assess how NO₂ concentrations differ between warmer and colder months in New York City, we examined seasonal averages for each biannual time period from Winter 2008–09 to Summer 2023. The data was categorized into “Winter” and “Summer” groups and analyzed chronologically over a 15-year span.

Figure 4 presents a horizontal bar chart of average NO₂ values per season, color-coded by season. A consistent seasonal disparity is evident: **winter NO₂ concentrations are notably higher than those in summer across nearly all years**. For instance, in Winter 2008–09, the NO₂ level peaked at **30.83 ppb**, while the following summer (Summer 2009) dropped to **22.08 ppb**. This trend persists throughout the dataset, with winter values exceeding summer counterparts by **5 to 10 ppb on average**.

The observed seasonal pattern is attributable to multiple environmental and anthropogenic factors. Colder temperatures in winter months lead to increased combustion for heating, which contributes to higher NO₂ emissions. Furthermore, atmospheric conditions such as temperature inversions are more prevalent in winter, limiting vertical mixing and causing pollutants to accumulate near ground level. In contrast, summer conditions generally facilitate greater dispersion and photochemical breakdown of NO₂, resulting in lower observed concentrations.

Although a general decline in NO₂ levels is visible over the 15-year period—likely reflecting policy efforts to reduce traffic emissions—the seasonal gap remains persistent. This underscores the importance of **season-specific mitigation strategies**, such as promoting cleaner heating fuels during winter months and enhancing public transportation use year-round.

`
)}

function _data3(data,d3)
{
  const filtered_data = data.filter(d => d.Name === "Nitrogen dioxide (NO2)");
  const winter_summer_data = filtered_data.filter(d => /Winter|Summer/i.test(d["Time Period"]));

  const groups = d3.group(winter_summer_data, d => d["Time Period"]);
  const grouped = Array.from(groups, ([timePeriod, values]) => {
    const avgValue = d3.mean(values, d => +d["Data Value"]);
    return { "Time Period": timePeriod, "Data Value": avgValue };
  });

  function sortKey(tp) {
    if (tp.startsWith("Summer")) {
      let parts = tp.split(" ");
      let year = +parts[1];
      return [year, 1];
    } else if (tp.startsWith("Winter")) {
      let parts = tp.split(" ");
      let range = parts[1];
      let [start_year_str, end_year_str] = range.split("-");
      if (end_year_str.length === 2) {
        let year = +(start_year_str.slice(0, 2) + end_year_str);
        return [year, 0];
      } else {
        let year = +end_year_str;
        return [year, 0];
      }
    } else {
      return [9999, 2];
    }
  }
  
  grouped.sort((a, b) => {
    const [yearA, orderA] = sortKey(a["Time Period"]);
    const [yearB, orderB] = sortKey(b["Time Period"]);
    return (yearA - yearB) || (orderA - orderB);
  });
  
  return grouped;
}


function _28(Inputs,data3){return(
Inputs.table(data3)
)}

function _29(Swatches,d3){return(
Swatches(d3.scaleOrdinal(["Winter", "Summer"], ["steelblue", "lightcoral"]))
)}

function _30(d3,dataset3)
{
  const width = 800;
  const height = width/1.5;
  const margin = { top: 60, right: 20, bottom: 40, left: 120 };

  const y = d3.scaleBand()
    .domain(dataset3.map(d => d.period))
    .range([margin.top, height - margin.bottom])
    .padding(0.1);

  const x = d3.scaleLinear()
    .domain([0, d3.max(dataset3, d => d.value)])
    .nice()
    .range([margin.left, width - margin.right]);

  const svg = d3.create("svg")
    .attr("width", width)
    .attr("height", height);

  svg.append("g")
    .selectAll("rect")
    .data(dataset3)
    .join("rect")
      .attr("x", x(0))
      .attr("y", d => y(d.period))
      .attr("width", d => x(d.value) - x(0))
      .attr("height", y.bandwidth())
      .attr("fill", d => d.period.startsWith("Summer") ? "lightcoral" : "steelblue");

  svg.append("g")
    .attr("transform", `translate(0,${margin.top})`)
    .call(d3.axisTop(x).ticks(5))
    .call(g => g.select(".domain").remove());

  svg.append("g")
    .attr("transform", `translate(${margin.left},0)`)
    .call(d3.axisLeft(y))
    .call(g => g.select(".domain").remove());

  svg.append("text")
    .attr("x", width / 2)
    .attr("y", margin.top / 2)
    .attr("text-anchor", "middle")
    .attr("font-size", "16px")
    .text("Air Quality");

  svg.append("text")
    .attr("transform", "rotate(-90)")
    .attr("x", -height / 2)
    .attr("y", 15)
    .attr("text-anchor", "middle")
    .text("Time Period");

  return svg.node();
}


function _31(md){return(
md`### 3.4 Correlation Between Traffic Density and Air Pollution Levels

Question 4: What correlations exist between traffic density and air pollution levels?

To explore the influence of vehicular activity on urban air pollution, we conducted a correlation analysis between traffic density indicators and pollutant concentrations across New York City's Community Districts. Specifically, we examined three traffic-related variables—**Annual vehicle miles traveled (VMT)**, including subsets for **cars** and **trucks**—and their relationship with key air pollutants and health outcomes. Pairwise Pearson correlation coefficients were computed and visualized in a heatmap (Figure 5), while summary values are reported in Table 2.

Among pollutants, **Nitrogen Dioxide (NO₂)** exhibited the strongest and most consistent positive correlation with vehicle activity. NO₂ was highly correlated with total VMT (**r = 0.819**), truck-related mileage (**r = 0.771**), and car-related mileage (**r = 0.799**). This is consistent with NO₂’s well-established role as a primary emission from internal combustion engines, particularly diesel-powered vehicles.⁴ Similarly, **Fine Particulate Matter (PM2.5)** showed a strong correlation with NO₂ (**r = 0.953**) and moderate correlation with vehicle activity (**r ≈ 0.75–0.80**), indicating overlapping emission sources.

Interestingly, the analysis also revealed meaningful associations between traffic activity and **health indicators**, including **asthma emergency department visits** and **respiratory hospitalizations due to PM2.5**, although the correlations were weaker (r = 0.16 and r = –0.19, respectively). This may reflect the complex interplay between environmental exposure, individual susceptibility, and access to healthcare.

Notably, **Ozone (O₃)** exhibited a negative correlation with vehicle-related variables (**r = –0.89 with NO₂**), likely due to its secondary pollutant nature—formed through photochemical reactions involving NOₓ and VOCs under sunlight. This inverse relationship suggests that while NO₂ concentrations rise in high-traffic zones, O₃ levels may decline due to NO titration effects near roadways.⁵

These findings reinforce the strong link between traffic emissions and ambient NO₂ and PM2.5 levels in NYC, highlighting the need for targeted policies such as emission zoning, electrification of vehicle fleets, and investment in public transit infrastructure to mitigate traffic-related air pollution and its associated health burdens.
`
)}

function _pivotMap(data,d3)
{
  data.forEach(d => {
    d["Data Value"] = +d["Data Value"];
    d["Start_Date"] = new Date(d["Start_Date"]);
  });
  const pivotMap = d3.rollup(
    data,
    v => d3.mean(v, d => d["Data Value"]),
    d => d["Geo Place Name"],
    d => d["Name"]
  );
  return pivotMap;
}


function _corrMatrix(pivotMap)
{
  const geoPlaces = Array.from(pivotMap.keys());
  const pollutantsSet = new Set();
  for (let [, pollutantMap] of pivotMap) {
    for (let pollutant of pollutantMap.keys()) {
      pollutantsSet.add(pollutant);
    }
  }
  const pollutants = Array.from(pollutantsSet);

  const pivot = geoPlaces.map(geo => {
    const pollutantMap = pivotMap.get(geo);
    let row = { "Geo Place Name": geo };
    pollutants.forEach(pollutant => {
      row[pollutant] = pollutantMap.has(pollutant) ? pollutantMap.get(pollutant) : NaN;
    });
    return row;
  });

  function mean(arr) {
    return arr.reduce((s, x) => s + x, 0) / arr.length;
  }
  function std(arr, meanVal) {
    return Math.sqrt(arr.reduce((s, x) => s + Math.pow(x - meanVal, 2), 0) / (arr.length - 1));
  }
  function pearson(x, y) {
    const n = x.length;
    if (n < 2) return NaN;
    const meanX = mean(x);
    const meanY = mean(y);
    const cov = x.reduce((s, xi, i) => s + (xi - meanX) * (y[i] - meanY), 0) / (n - 1);
    const stdX = std(x, meanX);
    const stdY = std(y, meanY);
    return cov / (stdX * stdY);
  }
  const corrMatrix = {};
  pollutants.forEach(p1 => {
    corrMatrix[p1] = {};
    pollutants.forEach(p2 => {
      const pairs = pivot.reduce((acc, row) => {
        const v1 = row[p1];
        const v2 = row[p2];
        if (!isNaN(v1) && !isNaN(v2)) {
          acc.push([v1, v2]);
        }
        return acc;
      }, []);
      const x = pairs.map(d => d[0]);
      const y = pairs.map(d => d[1]);
      corrMatrix[p1][p2] = x.length > 1 ? pearson(x, y) : NaN;
    });
  })

  return corrMatrix;
}


function _flatCorr(corrMatrix)
{
  const flatCorr = [];
  Object.entries(corrMatrix).forEach(([p1, inner]) => {
    Object.entries(inner).forEach(([p2, corr]) => {
      flatCorr.push({
        "Source": p1,
        "Target": p2,
        "Correlation": corr
      });
    });
  });
  return flatCorr;
}


function _35(Inputs,flatCorr){return(
Inputs.table(flatCorr)
)}

function _36(Legend,d3){return(
Legend(d3.scaleDiverging([1, 0, -1], d3.interpolateRdBu), {
  title: "Correlation",
})
)}

function _37(d3,flatCorr)
{
  const width = 800;
  const height = 800;
  const margin = { top: 60, right: 60, bottom: 240, left: 240 };
  const innerWidth = width - margin.left - margin.right;
  const innerHeight = height - margin.top - margin.bottom;

  const svg = d3.create('svg')
    .attr('width', width)
    .attr('height', height);

  const g = svg.append('g')
    .attr('transform', `translate(${margin.left},${margin.top})`);

  const sources = Array.from(new Set(flatCorr.map(d => d.Source))).sort();
  const targets = Array.from(new Set(flatCorr.map(d => d.Target))).sort();

  const xScale = d3.scaleBand()
    .domain(sources)
    .range([0, innerWidth])
    .padding(0.05);
  
  const yScale = d3.scaleBand()
    .domain(targets)
    .range([0, innerHeight])
    .padding(0.05);

  const colorScale = d3.scaleDiverging()
    .domain([1, 0, -1])
    .interpolator(d3.interpolateRdBu);

  g.selectAll('rect')
    .data(flatCorr)
    .join('rect')
      .attr('x', d => xScale(d.Source))
      .attr('y', d => yScale(d.Target))
      .attr('width', xScale.bandwidth())
      .attr('height', yScale.bandwidth())
      .attr('fill', d => colorScale(d.Correlation))
    .append('title')
      .text(d => `${d.Source} vs ${d.Target}: ${d.Correlation.toFixed(2)}`);

  g.selectAll('text.value')
    .data(flatCorr)
    .join('text')
      .attr('class', 'value')
      .attr('x', d => xScale(d.Source) + xScale.bandwidth() / 2)
      .attr('y', d => yScale(d.Target) + yScale.bandwidth() / 2)
      .text(d => d.Correlation.toFixed(2))
      .attr('text-anchor', 'middle')
      .attr('alignment-baseline', 'middle')
      .attr('font-size', '10px')
      .attr('fill', d => Math.abs(d.Correlation) > 0.5 ? 'white' : 'black');

  g.append('g')
    .attr('transform', `translate(0, ${740 - margin.bottom})`)
    .call(d3.axisBottom(xScale))
    .call(g => g.select('.domain').remove())
    .selectAll('text')
      .attr('transform', 'rotate(-45)')
      .attr('text-anchor', 'end');
  
  g.append('g')
    .call(d3.axisLeft(yScale))
    .call(g => g.select('.domain').remove());

  g.append("text")
      .attr("fill", "black")
      .attr("font-family", "sans-serif")
      .attr("font-size", "16px")
      .attr("x", 200)
      .attr("y", -10)
      .attr("text-anchor", "middle")
      .text("Correlation Matrix");

  return svg.node();
}


function _38(md){return(
md`## References


1. Brook RD, Rajagopalan S, Pope CA 3rd, Brook JR, Bhatnagar A, Diez-Roux AV, et al. Particulate matter air pollution and cardiovascular disease: An update to the scientific statement from the American Heart Association. *Circulation*. 2010;121(21):2331–78.

2. World Health Organization. Ambient (outdoor) air pollution. 2021. Available from: https://www.who.int/news-room/fact-sheets/detail/ambient-(outdoor)-air-quality-and-health

3. U.S. Environmental Protection Agency. Integrated Science Assessment for Particulate Matter. EPA/600/R-23/001. 2023. Available from: https://www.epa.gov/isa/integrated-science-assessments-isa

4. Schraufnagel DE, Balmes JR, Cowl CT, De Matteis S, Jung SH, Mortimer K, et al. Air pollution and noncommunicable diseases: A review by the Forum of International Respiratory Societies’ Environmental Committee. *Chest*. 2019;155(2):409–416.

5. Cohen AJ, Brauer M, Burnett R, Anderson HR, Frostad J, Estep K, et al. Estimates and 25-year trends of the global burden of disease attributable to ambient air pollution: An analysis of data from the Global Burden of Disease Study 2015. *The Lancet*. 2017;389(10082):1907–1918.

6. World Health Organization. Air pollution. 2022. Available from: https://www.who.int/health-topics/air-pollution#tab=tab_1

7. Jerrett M, Burnett RT, Pope CA 3rd, Ito K, Thurston G, Krewski D, et al. Long-term ozone exposure and mortality. *N Engl J Med*. 2009;360(11):1085–1095.

8. Marshall JD, Nethery E, Brauer M. Within-urban variability in ambient air pollution: Comparison of estimation methods. *Atmos Environ*. 2008;42(6):1359–1369.

9. Azad S, Ferrer-Cid P, Ghandehari M. Exposure to fine particulate matter in the New York City subway system during home-work commute. *PLOS ONE*. 2024;19(8):e0307096. https://doi.org/10.1371/journal.pone.0307096

10. Vilcassim MJR, Thurston GD, Peltier RE, Gordon T. Black carbon and particulate matter (PM2.5) concentrations in New York City’s subway stations. *Environ Sci Technol*. 2014;48(24):14738–14745.

11. Bell ML, Ebisu K, Belanger K. Ambient air pollution and low birth weight in Connecticut and Massachusetts. *Environ Health Perspect*. 2007;115(7):1118–1124.`
)}

function _39(md){return(
md`---
## Appendix`
)}

function _dataset1(data1,selectedPollutant1)
{
  const pollutant = data1.find(d => d.name === selectedPollutant1);
  return pollutant.data.map(d => ({
    date: new Date(d.Start_Date),
    average: d.average
  }));
}


function _dataset2(no2_by_place_sorted){return(
no2_by_place_sorted
    .map(d => ({ place: d.place, avg_no2: +d.avg_no2 }))
    .slice(0, 20)
)}

function _dataset3(data3){return(
data3.map(d => ({
  period: d["Time Period"],
  value: +d["Data Value"]
}))
)}

export default function define(runtime, observer) {
  const main = runtime.module();
  function toString() { return this.url; }
  const fileAttachments = new Map([
    ["Air_Quality_20250404.csv", {url: new URL("./files/0a9fffe01f039b2a78ad31d3a73b2d30009fbe755cf96468c853e9662d3cf5547d4533ed907f25e4052caa343b1ab8f111e9aff8a7af90cbd63cc6add88d84c1.csv", import.meta.url), mimeType: "text/csv", toString}]
  ]);
  main.builtin("FileAttachment", runtime.fileAttachments(name => fileAttachments.get(name)));
  main.variable(observer()).define(["md"], _1);
  main.variable(observer()).define(["md"], _2);
  main.variable(observer()).define(["md"], _3);
  main.variable(observer()).define(["md"], _4);
  main.variable(observer()).define(["md"], _5);
  main.variable(observer()).define(["md"], _6);
  main.variable(observer()).define(["md"], _7);
  main.variable(observer()).define(["md"], _8);
  main.variable(observer("air_quality_20250404")).define("air_quality_20250404", ["__query","FileAttachment","invalidation"], _air_quality_20250404);
  main.variable(observer("data")).define("data", ["FileAttachment"], _data);
  main.variable(observer()).define(["Inputs","data"], _11);
  main.variable(observer()).define(["md"], _12);
  main.variable(observer("names_filter")).define("names_filter", _names_filter);
  main.variable(observer("data1")).define("data1", ["data","names_filter","d3"], _data1);
  main.variable(observer("viewof selectedPollutant1")).define("viewof selectedPollutant1", ["Inputs","names_filter"], _selectedPollutant1);
  main.variable(observer("selectedPollutant1")).define("selectedPollutant1", ["Generators", "viewof selectedPollutant1"], (G, _) => G.input(_));
  main.variable(observer()).define(["Plot","dataset1"], _16);
  main.variable(observer()).define(["md"], _17);
  main.variable(observer()).define(["md"], _18);
  main.variable(observer("no2_data")).define("no2_data", ["data"], _no2_data);
  main.variable(observer("no2_by_place")).define("no2_by_place", ["d3","no2_data"], _no2_by_place);
  main.variable(observer("no2_by_place_sorted")).define("no2_by_place_sorted", ["no2_by_place"], _no2_by_place_sorted);
  main.variable(observer()).define(["md"], _22);
  main.variable(observer()).define(["Inputs","no2_by_place_sorted"], _23);
  main.variable(observer()).define(["d3","dataset2"], _24);
  main.variable(observer()).define(["md"], _25);
  main.variable(observer()).define(["md"], _26);
  main.variable(observer("data3")).define("data3", ["data","d3"], _data3);
  main.variable(observer()).define(["Inputs","data3"], _28);
  main.variable(observer()).define(["Swatches","d3"], _29);
  main.variable(observer()).define(["d3","dataset3"], _30);
  main.variable(observer()).define(["md"], _31);
  main.variable(observer("pivotMap")).define("pivotMap", ["data","d3"], _pivotMap);
  main.variable(observer("corrMatrix")).define("corrMatrix", ["pivotMap"], _corrMatrix);
  main.variable(observer("flatCorr")).define("flatCorr", ["corrMatrix"], _flatCorr);
  main.variable(observer()).define(["Inputs","flatCorr"], _35);
  main.variable(observer()).define(["Legend","d3"], _36);
  main.variable(observer()).define(["d3","flatCorr"], _37);
  main.variable(observer()).define(["md"], _38);
  main.variable(observer()).define(["md"], _39);
  const child1 = runtime.module(define1);
  main.import("Legend", child1);
  main.import("Swatches", child1);
  main.variable(observer("dataset1")).define("dataset1", ["data1","selectedPollutant1"], _dataset1);
  main.variable(observer("dataset2")).define("dataset2", ["no2_by_place_sorted"], _dataset2);
  main.variable(observer("dataset3")).define("dataset3", ["data3"], _dataset3);
  return main;
}
