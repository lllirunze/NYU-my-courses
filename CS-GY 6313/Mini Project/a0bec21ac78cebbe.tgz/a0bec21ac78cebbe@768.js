import define1 from "./a33468b95d0b15b0@817.js";

function _1(md){return(
md`# Mini-Project 3 (Networks)`
)}

function _2(md){return(
md`## Data

Here we load a [simplified and reduced version](https://docs.google.com/spreadsheets/d/1YiuHdfZv_JZ-igOemKJMRaU8dkucfmHxOP6Od3FraW8/) of the [AidData dataset](https://www.aiddata.org/data/aiddata-core-research-release-level-1-3-1). You are free to change this code as you wish. If you don't want to preprocess your data on Observable, then you can do the preprocessing using whatever languages or tools you'd like and then [upload](/@observablehq/file-attachments) your preprocessed data to Observable. If you take this approach, then you should delete the \`aiddata\` cell below so that you're not loading unnecessary data.

The dataset contains the following columns:
- **yearDate**: year of the commitment as a Date object
- **yearInt**: year of the commitment as an integer
- **donor**: country providing the financial resource
- **recipient**: country receiving the financial resource
- **amount**: the total amount of financial resources provided
- **purpose**: the purpose of the transaction`
)}

function _3(Inputs,aiddata){return(
Inputs.table(aiddata)
)}

async function _aiddata(d3,googleSheetCsvUrl)
{
  const data = await d3.csv(googleSheetCsvUrl, row => ({
    yearDate: d3.timeParse('%Y')(row.year),
    yearInt: +row.year,
    donor: row.donor,
    recipient: row.recipient,
    amount: +row.commitment_amount_usd_constant,
    purpose: row.coalesced_purpose_name,
  }));
  
  data.columns = Object.keys(data[0]);
  
  return data;
}


function _5(md){return(
md`Next we load GeoJSON data for countries. This file is derived from data from [Natural Earth](https://www.naturalearthdata.com).`
)}

function _geoJSON(FileAttachment){return(
FileAttachment("countries-50m.json").json()
)}

function _7(md){return(
md`## Questions

Your goal is to create 3 independent visualizations of the same data set, each one with the intent of answering the questions stated below. For each numbered visualization, you should be able to create a data visualization that answers **all of the questions** specified. These are the 3 visualizations you should create:

- **Visualization 1:** Create an overview of the relationships between countries so that it is possible to see who donates to whom and how much. The main questions one should be able to answer are (note that we only care about the top 10 recipients and the top 20 donors [over the whole time] for these questions): 

  Q1) Who are the major donors? To which countries do they donate the most, and how much? **(20 points)**

  Q2) Conversely, who are the major receivers? Which countries do they receive from the most, and how much? **(20 points)**

  Aesthetics and Clarity **(10 points)**

- **Visualization 2:** The same as the previous question, we only care about the top 10 recipients and the top 20 donors here. The main questions one should be able to answer using your visualization are: 

  Q1) Considering only the top 5 purposes of donation, how does the relationship between countries look like in terms of purposes? Are there countries that donate to a given country for multiple purposes? Or do counties always give for one single purpose when donating to another country? **(20 points)**

  Q2) What composition (distribution) of purposes do the donations between each pair of countries have? **(20 points)**
  
  Note: if the purpose is “UNSPECIFIED” it should be removed.

  Aesthetics and Clarity **(10 points)**

- **[OPTIONAL/EXTRA POINTS] Visualization 3:**  **(20 points)**

  Q1) For this last exercise you have to extend the analysis above to see how the patterns of donations change over time. Focusing again on the top 10 recipients and top 20 donors, how do the patterns of donations (who donates to whom and how much) change over time? Are there sudden changes?

  Q2) Are there countries that always donate to other countries? Are there major shifts (say a country used to donate to a specific set of countries and then it changes to other countries)?


**Notes**

For this exercise you may want to review the lecture on network visualizations in which we explain how you can visualize network data. 

For each visualization add a description of your thought process and why you think your solution is *appropriate* and *effective*.

Note it is okay to submit more than one solution for a given visualization problem if you think there are some competing solutions that work well. When you do that, make sure to compare the solutions by commenting on their advantages and disadvantages.
`
)}

function _8(md){return(
md`### Remember

The questions above are a very useful tool for you to verify whether you are producing a good solution or not. As you go about solving this exercise you can use the questions above as an evaluation tool in two main ways:
1. Verify that you can indeed answer the questions with your visualization. If you can’t fully answer the questions, it means your solution has some problems.
2. Compare multiple solutions to the same problem and ask yourself: “which one makes it easier for me to answer these questions?”, where easier may mean, more accurately, with less effort or faster.
`
)}

function _9(md){return(
md`## Instructions
- Your coded solutions must use D3. Other visualization libraries are not allowed.
- You should feel free to process and transform the data any way you deem relevant and use any tool you prefer for data processing. Data transformation does not necessarily have to be in JavaScript nor within Observable. It’s ok to pre-process the data and then load it in Observable if you prefer.
- You can use Mike Bostock's [Color Legend](/@d3/color-legend) notebook to create your legends.`
)}

function _11(md){return(
md`## Grading Criteria

The main parameters we will use for grading are the following:

- Does the information extracted answer the questions posed in the exercise?
- Does the visualization answer the questions posed in the exercise?
- Is the visual representation clear? Does it have good aesthetics?
  - Review this [notebook on clarity](/@nyuvis/contextual-elements-aesthetics-and-clarity) for reference.`
)}

function _12(md){return(
md`## Solutions`
)}

function _14(md){return(
md`## Visualization 1: 

Create an overview of the relationships between countries so that it is possible to see who donates to whom and how much. The main questions one should be able to answer are (note that we only care about the top 10 recipients and the top 20 donors [over the whole time] for these questions):`
)}

function _aiddataByCountries(aiddata,d3){return(
Array.from(new Set(aiddata.flatMap(d => [d.donor, d.recipient]))).map(country => ({
  country,
  donate: d3.sum(aiddata.filter(d => d.donor === country), d => d.amount),
  receive: d3.sum(aiddata.filter(d => d.recipient === country), d => d.amount)
}))
)}

function _topDonors(aiddataByCountries){return(
aiddataByCountries
  .sort((a, b) => b.donate - a.donate)
  .slice(0, 20)
  .map(d => d.country)
)}

function _topRecipients(aiddataByCountries){return(
aiddataByCountries
  .sort((a, b) => b.receive - a.receive)
  .slice(0, 10)
  .map(d => d.country)
)}

function _filteredAidData(aiddata,topDonors,topRecipients){return(
aiddata.filter(d => 
  topDonors.includes(d.donor) && topRecipients.includes(d.recipient)
)
)}

function _aggregatedAidData(d3,filteredAidData,topDonors,topRecipients)
{
  const aidDataArray = Array.from(d3.rollup(
      filteredAidData,
      v => d3.sum(v, d => d.amount),
      d => `${d.donor}|${d.recipient}`
    ), ([pair, amount]) => {
      const [donor, recipient] = pair.split('|');
      return { donor, recipient, amount };
    }
  )

  const data = d3.cross(topDonors, topRecipients, (source, target) => ({
    source,
    target,
    // if this link isn't in the linkToWeight map, then set the weight to null 
    weight: new Map(aidDataArray.map(edge => [`${edge.donor}-${edge.recipient}`, edge.amount])).get(`${source}-${target}`) ?? null,
  }));

  return data;
}


function _color(d3,aggregatedAidData){return(
d3.scaleSequentialSqrt()
  .domain([0, d3.max(aggregatedAidData, d => d.weight)])
  .interpolator(d3.interpolateReds)
  .unknown("#eeeeee")
)}

function _21(legend,color){return(
legend({ color, title: "Amount (USD)", tickFormat: "s" })
)}

function _22(d3,topRecipients,topDonors,aggregatedAidData,color)
{
  // set up
  const margin = {top: 30, right: 0, bottom: 100, left: 150};
  const width = 500 + margin.left + margin.right;
  const height = 550 + margin.top + margin.bottom;

  const svg = d3.create('svg')
      .attr('width', width)
      .attr('height', height);

  const x = d3.scaleBand()
    .domain(topRecipients)
    .range([margin.left, width - margin.right])
    .paddingInner(0.1);

  const y = d3.scaleBand()
    .domain(topDonors)
    .range([margin.left, width - margin.right])
    .paddingInner(0.1);
  
  // draw points
  svg.selectAll('rect')
    .data(aggregatedAidData)
    .join('rect')
      .attr('x', d => x(d.target))
      .attr('y', d => y(d.source))
      .attr('width', x.bandwidth())
      .attr('height', y.bandwidth())
      .attr('fill', d => color(d.weight))
    .append("title")
      .text(d => d.weight ? `${d.source} donated $${d.weight} to ${d.target}.` : `${d.source} donated $0 to ${d.target}.`);

  svg.append("g")
    .selectAll("text")
    .data(topRecipients)
    .join("text")
      .attr("transform", d => `translate(${x(d) + x.bandwidth() / 2}, 140) rotate(-90)`)
      .attr("text-anchor", "start")
      .text(d => d)
      .style("font-size", "10pt");

  svg.append("g")
    .selectAll("text")
    .data(topDonors)
    .join("text")
      .attr("x", margin.left-5)
      .attr("y", d => y(d) + y.bandwidth() / 2)
      .attr("dy", "0.35em")
      .attr("text-anchor", "end")
      .text(d => d)
      .style("font-size", "10pt");

  svg.append("text")
    .attr("x", 30)
    .attr("y", height/2 + margin.top)
    .attr("text-anchor", "middle")
    .text("Donor");

  svg.append("text")
    .attr("x", width/2 + 60)
    .attr("y", 60)
    .attr("text-anchor", "middle")
    .text("Recipient");

  svg.append("text")
    .attr("x", 60)
    .attr("y", 30)
    .attr("text-anchor", "start")
    .text("The total amount donated from donors to recipients (for Vis1)")
    .style("font-size", "14pt");
  
  return svg.node();
}


function _23(md){return(
md`### Q1 (20 points) 

Who are the major donors? To which countries do they donate the most, and how much? 

**Answer:** Major donors are **the United States, Japan, Germany**, etc. 

- For the United States, the main recipient countries for donations from the United States are India, Brazil, and Colombia.
- For Japan, the main recipient countries for donations from Japan are India, Thailand, and Korea.
- For Germany, the main recipient countries for donations from Germany are India and Poland.

In this problem I calculate the total amount of donations and receipts of each country and get the data _aiddataByCountries_. Then I sort _aiddataByCountries_ according to the amount of donations and receipts respectively so that I can get two arrays of _topDonors_ and _topRecipients_, indicating the top 10 recipients and the top 20 donors for these problems.

After getting the top 10 recipients and the top 20 donors, I can filter out the relationship data _aggregatedAidData_ related to them, representing the amount of money from one donor to one recipient.

I visualize **network data using an adjaceny matrix**, representing the amount of money from each donor to each recipient. The squares are colored in red, the redder the higher the amount. 

Based on this adjaceny matrix, I can visualize that the major donors are United States, Japan, Germany, etc., and they mainly donate to India, Thailand, and Brazil, etc.`
)}

function _24(md){return(
md`### Q2 (20 points) 

Conversely, who are the major receivers? Which countries do they receive from the most, and how much? 

**Answer:** Major recipients are **India, Thailand, Brazil**, etc.

- For India, the major donors are Japan, United States, Germany and United Kingdom.
- For Thailand, the main donors are Japan and United States.
- For Brazil, the main donors are United States, Japan and Germany.

In this question, I also use this **adjacency matrix** to answer the question. In the matrix, each row represents donors (i.e. source) and each column represents recipients (i.e. target). I can start with the column to see which countries are the main recipients and from that column I can see which row of countries are the main donors for that country.

According to this adjacency matrix, we can see that major recipients are India, Thailand, Brazil, etc. Their sources are mainly USA, Japan, Germany, etc.`
)}

function _25(md){return(
md`---`
)}

function _26(md){return(
md`## Visualization 2: 

The same as the previous question, we only care about the top 10 recipients and the top 20 donors here. The main questions one should be able to answer using your visualization are:

Note: if the purpose is “UNSPECIFIED” it should be removed.`
)}

function _topPurposes(d3,aiddata)
{
  
  const aiddataByPurposes = new Map(
    Array.from(
      d3.rollup(
        aiddata,
        v => d3.sum(v, d => d.amount),
        d => d.purpose,
        d => d.yearInt
      ),
      ([purpose, yearMap]) => [purpose, Array.from(yearMap, ([year, amount]) => ({ year, amount }))]
    )
  );
  
  const allPurposes = Array.from(aiddataByPurposes.keys());
  const yearRanges = d3.range(1973, 2014);

  const purposeData = allPurposes.map((purpose, i) => {
    const donateAmounts = aiddataByPurposes.get(purpose) || [];
    const completeDonate = yearRanges.map(year => {
      const record = donateAmounts.find(d => d.year === year);
      return record ? record : { year, amount: 0 };
    });
    const total = completeDonate.reduce((acc, cur) => acc + cur.amount, 0);
  
    return {
      purpose,
      total,
      donate: completeDonate
    };
  });

  return purposeData.filter(d => d.purpose !== 'Sectors not specified')
    .sort((a, b) => b.total - a.total)
    .slice(0, 5)
    .map(d => d.purpose);
}


function _filteredAidData2(aiddata,topDonors,topRecipients,topPurposes){return(
aiddata.filter(d => 
  topDonors.includes(d.donor) && topRecipients.includes(d.recipient) && topPurposes.includes(d.purpose)
)
)}

function _aggregatedAidData2(d3,filteredAidData2){return(
Array.from(d3.rollup(
    filteredAidData2,
    v => d3.sum(v, d => d.amount),
    d => `${d.donor}|${d.recipient}|${d.purpose}`
  ), ([pair, amount]) => {
    const [donor, recipient, purpose] = pair.split('|');
    return { donor, recipient, purpose, amount };
  }
)
)}

function _30(Swatches,d3,topPurposes){return(
Swatches(d3.scaleOrdinal(topPurposes, d3.schemeCategory10))
)}

function _31(topDonors,topRecipients,d3,topPurposes,aggregatedAidData2)
{
  const cellSize = 60;
  const margin = {top: 180, right: 0, bottom: 30, left: 200};
  
  const rows = topDonors.length;
  const cols = topRecipients.length;
  
  const width = margin.left + margin.right + cols * cellSize;
  const height = margin.top + margin.bottom + rows * cellSize;
  
  const colorScale = d3.scaleOrdinal()
    .domain(topPurposes)
    .range(d3.schemeCategory10);
  
  const groupedData = d3.group(aggregatedAidData2, d => d.donor, d => d.recipient);
  
  const pie = d3.pie()
    .sort(null)
    .value(d => d.amount);
  
  const arc = d3.arc()
    .innerRadius(0)
    .outerRadius(cellSize / 2 - 2);

  const svg = d3.create("svg")
    .attr("width", width)
    .attr("height", height);
  
  const matrix = svg.append("g")
    .attr("transform", `translate(${margin.left},${margin.top})`);
  
  topDonors.forEach((donor, i) => {
    topRecipients.forEach((recipient, j) => {
      const cx = j * cellSize + cellSize / 2;
      const cy = i * cellSize + cellSize / 2;

      let cellData = [];
      const donorGroup = groupedData.get(donor);
      if (donorGroup) {
        const recData = donorGroup.get(recipient);
        if (recData) {
          const purposeData = d3.rollup(
            recData,
            v => d3.sum(v, d => d.amount),
            d => d.purpose
          );
          cellData = Array.from(purposeData, ([purpose, amount]) => ({ purpose, amount }));
        }
      }
      
      const cell = matrix.append("g")
        .attr("transform", `translate(${cx}, ${cy})`);
      
      if (cellData.length > 0) {
        const totalAmount = cellData.reduce((sum, d) => sum + d.amount, 0);
        const pieData = pie(cellData);
        cell.selectAll("path")
          .data(pieData)
          .join("path")
            .attr("d", arc)
            .attr("fill", d => colorScale(d.data.purpose))
            // .attr("stroke", "#ffffff")
          .append("title")
            .text(d => `${donor} donated to ${recipient}:\n  Purpose: ${d.data.purpose}\n  Amount: ${d.data.amount}\n  Percentage: ${(d.data.amount / totalAmount * 100).toFixed(2)}%`);
      } else {
        cell.append("circle")
          .attr("r", cellSize / 2 - 2)
          .attr("fill", "#ccc")
        .append("title")
          .text(`${donor} donated to ${recipient}:\n  No data`);
      }
    });
  });
  
  svg.append("g")
    .selectAll("text")
    .data(topDonors)
    .join("text")
      .attr("x", margin.left - 5)
      .attr("y", (d, i) => margin.top + i * cellSize + cellSize / 2)
      .attr("dy", "0.35em")
      .attr("text-anchor", "end")
      .text(d => d)
      .style("font-size", "10pt");
  
  svg.append("g")
  .selectAll("text")
  .data(topRecipients)
  .join("text")
    .attr("transform", (d, i) => 
      `translate(${margin.left + i * cellSize + cellSize / 2}, ${margin.top - 10}) rotate(-90)`
    )
    .attr("text-anchor", "start")
    .text(d => d)
    .style("font-size", "10pt");

  svg.append("text")
    .attr("x", 60)
    .attr("y", height/2)
    .attr("text-anchor", "middle")
    .text("Donor");

  svg.append("text")
    .attr("x", width/2 + 60)
    .attr("y", 80)
    .attr("text-anchor", "middle")
    .text("Recipient");

  svg.append("text")
    .attr("x", 60)
    .attr("y", 30)
    .attr("text-anchor", "start")
    .text("The relationship between countries in terms of purposes (for Vis2)")
    .style("font-size", "14pt");
  
  return svg.node();
}


function _32(md){return(
md`### Q1 (20 points) 

Considering only the top 5 purposes of donation, how does the relationship between countries look like in terms of purposes? Are there countries that donate to a given country for multiple purposes? Or do counties always give for one single purpose when donating to another country? 

**Answer:** 

1. The relationship between countries in terms of purposes is shown **in the figure above (The relationship between countries in terms of purposes (for Vis2))**.
2. **There are some countries that donate to one country for multiple purposes.** For example, United States donates to India for _Air transport_, _Industrial development_ and _Power generation/non-renewable sources_.
3. **There are also some countries that always donate to one country for one single purpose.** For example, Italy donated only _Industrial development_ to India.

In this problem, I aggregate the _purpose_ attribute in _aiddata_ and got the total amount of donations for each purpose. Then I take out the top 5 purposes in terms of donation amount, called _topPurposes_. 

I still use the **adjacency matrix** for graphing. But unlike Question1, **I describe the amount of different purposes from each donor to each recipient** in _aggregatedAidData2_. In addition, for the countries in the relationship, **I plotted some small pie charts for each country pair**, specifying the percentage of purposes from one donor to one recipient (if the pie chart is marked grey, it indicates that there is no data between the country pair).

Thus, the chart above represents the relationship between countries in terms of purposes. The different pie charts show that there are both countries that donate to a country based on different purposes (such as United States - India) and countries that donate one single purpose to a country (such as Italy - India).`
)}

function _33(md){return(
md`### Q2 (20 points)

What composition (distribution) of purposes do the donations between each pair of countries have? 

**Answer:** Based on the network chart (The relationship between countries in terms of purposes (for Vis2)), **I write a table which describes the proportion of each donor and recipient pair giving in different purposes as shown below.**

| | Brazil                                         | Chile                                         | Colombia                                       | India                                          | Korea                                          | Kuwait                                        | Poland                                        | Saudi Arabia                                  | South Africa                                   | Thailand                                        |
|:---------------|:-----------------------------------------------|:----------------------------------------------|:-----------------------------------------------|:-----------------------------------------------|:-----------------------------------------------|:----------------------------------------------|:----------------------------------------------|:----------------------------------------------|:-----------------------------------------------|:------------------------------------------------|
| **Australia**      | no data                                        | no data                                       | no data                                        | Industrial development: 78.76%                 | no data                                        | no data                                       | no data                                       | no data                                       | Industrial development: 100.00%                | Air transport: 0.20%                            |
|                |                                                |                                               |                                                | Power generation/non-renewable sources: 12.63% |                                                |                                               |                                               |                                               |                                                | Industrial development: 0.07%                   |
|                |                                                |                                               |                                                | Rail transport: 8.61%                          |                                                |                                               |                                               |                                               |                                                | Power generation/non-renewable sources: 0.74%   |
|                |                                                |                                               |                                                |                                                |                                                |                                               |                                               |                                               |                                                | Rail transport: 98.99%                          |
| **Austria**        | Industrial development: 100.00%                | no data                                       | Rail transport: 100.00%                        | Industrial development: 47.13%                 | no data                                        | no data                                       | no data                                       | Industrial development: 100.00%               | no data                                        | Industrial development: 100.00%                 |
|                |                                                |                                               |                                                | Power generation/non-renewable sources: 52.87% |                                                |                                               |                                               |                                               |                                                |                                                 |
| **Belgium**       | Industrial development: 1.19%                  | Industrial development: 100.00%               | Industrial development: 48.11%                 | Industrial development: 20.65%                 | no data                                        | no data                                       | RESCHEDULING AND REFINANCING: 100.00%         | no data                                       | Industrial development: 100.00%                | Air transport: 2.90%                            |
|                | RESCHEDULING AND REFINANCING: 98.81%           |                                               | Power generation/non-renewable sources: 51.89% | Power generation/non-renewable sources: 79.35% |                                                |                                               |                                               |                                               |                                                | Industrial development: 87.13%                  |
|                |                                                |                                               |                                                |                                                |                                                |                                               |                                               |                                               |                                                | Rail transport: 9.97%                           |
| **Canada**         | Industrial development: 83.05%                 | Industrial development: 100.00%               | Industrial development: 100.00%                | Air transport: 16.09%                          | no data                                        | no data                                       | Air transport: 28.42%                         | no data                                       | Industrial development: 100.00%                | Air transport: 0.46%                            |
|                | Power generation/non-renewable sources: 16.90% |                                               |                                                | Industrial development: 61.84%                 |                                                |                                               | Industrial development: 70.50%                |                                               |                                                | Industrial development: 72.27%                  |
|                | Rail transport: 0.05%                          |                                               |                                                | Power generation/non-renewable sources: 21.89% |                                                |                                               | Power generation/non-renewable sources: 1.08% |                                               |                                                | Power generation/non-renewable sources: 27.27%  |
|                |                                                |                                               |                                                | Rail transport: 0.18%                          |                                                |                                               |                                               |                                               |                                                |                                                 |
| **Denmark**        | no data                                        | no data                                       | Industrial development: 100.00%                | Industrial development: 100.00%                | no data                                        | no data                                       | no data                                       | no data                                       | Industrial development: 100.00%                | Industrial development: 56.69%                  |
|                |                                                |                                               |                                                |                                                |                                                |                                               |                                               |                                               |                                                | Power generation/non-renewable sources: 4.59%   |
|                |                                                |                                               |                                                |                                                |                                                |                                               |                                               |                                               |                                                | Rail transport: 38.73%                          |
| **Finland**        | no data                                        | no data                                       | no data                                        | Industrial development: 100.00%                | no data                                        | no data                                       | Industrial development: 100.00%               | no data                                       | Industrial development: 100.00%                | Industrial development: 100.00%                 |
| **France**         | Rail transport: 100.00%                        | Air transport: 0.61%                          | Air transport: 8.93%                           | Air transport: 7.54%                           | Industrial development: 99.92%                 | no data                                       | Industrial development: 63.26%                | no data                                       | Air transport: 69.27%                          | Air transport: 0.44%                            |
|                |                                                | Industrial development: 0.38%                 | Industrial development: 5.46%                  | Industrial development: 59.69%                 | Rail transport: 0.08%                          |                                               | Rail transport: 36.74%                        |                                               | Rail transport: 30.73%                         | Industrial development: 16.70%                  |
|                |                                                | Rail transport: 99.01%                        | Rail transport: 85.61%                         | Power generation/non-renewable sources: 19.33% |                                                |                                               |                                               |                                               |                                                | Power generation/non-renewable sources: 6.80%   |
|                |                                                |                                               |                                                | Rail transport: 13.44%                         |                                                |                                               |                                               |                                               |                                                | Rail transport: 76.05%                          |
| **Germany**        | Industrial development: 67.45%                 | Industrial development: 100.00%               | Air transport: 5.39%                           | Industrial development: 48.89%                 | Industrial development: 72.12%                 | no data                                       | RESCHEDULING AND REFINANCING: 100.00%         | no data                                       | Industrial development: 100.00%                | Industrial development: 43.43%                  |
|                | Rail transport: 32.55%                         |                                               | Industrial development: 18.06%                 | Power generation/non-renewable sources: 43.23% | Rail transport: 27.88%                         |                                               |                                               |                                               |                                                | Power generation/non-renewable sources: 14.18%  |
|                |                                                |                                               | Power generation/non-renewable sources: 11.30% | Rail transport: 7.88%                          |                                                |                                               |                                               |                                               |                                                | Rail transport: 42.39%                          |
|                |                                                |                                               | Rail transport: 65.25%                         |                                                |                                                |                                               |                                               |                                               |                                                |                                                 |
| **Italy**          | Industrial development: 98.03%                 | Industrial development: 100.00%               | Air transport: 24.00%                          | Industrial development: 100.00%                | no data                                        | no data                                       | Industrial development: 81.50%                | no data                                       | no data                                        | Rail transport: 100.00%                         |
|                | Power generation/non-renewable sources: 1.97%  |                                               | Industrial development: 17.30%                 |                                                |                                                |                                               | Rail transport: 18.50%                        |                                               |                                                |                                                 |
|                |                                                |                                               | Power generation/non-renewable sources: 58.71% |                                                |                                                |                                               |                                               |                                               |                                                |                                                 |
| **Japan**          | Air transport: 0.03%                           | Industrial development: 7.41%                 | Air transport: 0.01%                           | Industrial development: 14.00%                 | Industrial development: 36.00%                 | no data                                       | no data                                       | Industrial development: 100.00%               | Industrial development: 0.28%                  | Air transport: 28.58%                           |
|                | Industrial development: 99.56%                 | Rail transport: 92.59%                        | Industrial development: 85.95%                 | Power generation/non-renewable sources: 22.52% | Rail transport: 64.00%                         |                                               |                                               |                                               | Rail transport: 99.72%                         | Industrial development: 14.55%                  |
|                | Rail transport: 0.41%                          |                                               | Rail transport: 14.04%                         | Rail transport: 63.48%                         |                                                |                                               |                                               |                                               |                                                | Power generation/non-renewable sources: 0.24%   |
|                |                                                |                                               |                                                |                                                |                                                |                                               |                                               |                                               |                                                | Rail transport: 56.64%                          |
| **Korea**          | Industrial development: 100.00%                | Air transport: 100.00%                        | Industrial development: 85.40%                 | no data                                        | no data                                        | no data                                       | no data                                       | no data                                       | no data                                        | Air transport: 3.82%                            |
|                |                                                |                                               | Rail transport: 14.60%                         |                                                |                                                |                                               |                                               |                                               |                                                | Industrial development: 80.02%                  |
|                |                                                |                                               |                                                |                                                |                                                |                                               |                                               |                                               |                                                | Power generation/non-renewable sources: 7.99%   |
|                |                                                |                                               |                                                |                                                |                                                |                                               |                                               |                                               |                                                | Rail transport: 8.17%                           |
| **Kuwait**         | no data                                        | no data                                       | no data                                        | Industrial development: 46.77%                 | no data                                        | no data                                       | no data                                       | no data                                       | no data                                        | Power generation/non-renewable sources: 100.00% |
|                |                                                |                                               |                                                | Power generation/non-renewable sources: 53.23% |                                                |                                               |                                               |                                               |                                                |                                                 |
| **Netherlands**    | no data                                        | no data                                       | Industrial development: 100.00%                | Air transport: 0.75%                           | no data                                        | no data                                       | no data                                       | no data                                       | Industrial development: 100.00%                | Industrial development: 100.00%                 |
|                |                                                |                                               |                                                | Industrial development: 53.86%                 |                                                |                                               |                                               |                                               |                                                |                                                 |
|                |                                                |                                               |                                                | Power generation/non-renewable sources: 0.77%  |                                                |                                               |                                               |                                               |                                                |                                                 |
|                |                                                |                                               |                                                | Rail transport: 44.63%                         |                                                |                                               |                                               |                                               |                                                |                                                 |
| **Norway**         | Industrial development: 100.00%                | Industrial development: 100.00%               | no data                                        | Air transport: 1.42%                           | no data                                        | no data                                       | no data                                       | no data                                       | Air transport: 0.09%                           | Air transport: 0.95%                            |
|                |                                                |                                               |                                                | Industrial development: 98.58%                 |                                                |                                               |                                               |                                               | Industrial development: 99.67%                 | Industrial development: 99.05%                  |
|                |                                                |                                               |                                                | Power generation/non-renewable sources: 0.00%  |                                                |                                               |                                               |                                               | Power generation/non-renewable sources: 0.09%  |                                                 |
|                |                                                |                                               |                                                |                                                |                                                |                                               |                                               |                                               | Rail transport: 0.16%                          |                                                 |
| **Saudi Arabia**   | no data                                        | no data                                       | no data                                        | Rail transport: 100.00%                        | no data                                        | no data                                       | no data                                       | no data                                       | no data                                        | Power generation/non-renewable sources: 100.00% |
| **Spain**          | Air transport: 10.11%                          | Air transport: 0.82%                          | Air transport: 12.39%                          | Air transport: 82.86%                          | no data                                        | no data                                       | no data                                       | no data                                       | no data                                        | Industrial development: 100.00%                 |
|                | Industrial development: 79.80%                 | Industrial development: 99.18%                | Industrial development: 87.61%                 | Industrial development: 16.90%                 |                                                |                                               |                                               |                                               |                                                |                                                 |
|                | Rail transport: 10.09%                         |                                               |                                                | Rail transport: 0.24%                          |                                                |                                               |                                               |                                               |                                                |                                                 |
| **Sweden**         | no data                                        | Industrial development: 100.00%               | no data                                        | Industrial development: 29.28%                 | no data                                        | no data                                       | Air transport: 29.79%                         | no data                                       | Industrial development: 94.90%                 | Industrial development: 100.00%                 |
|                |                                                |                                               |                                                | Power generation/non-renewable sources: 60.69% |                                                |                                               | Industrial development: 70.16%                |                                               | Power generation/non-renewable sources: 5.10%  |                                                 |
|                |                                                |                                               |                                                | Rail transport: 10.03%                         |                                                |                                               | Rail transport: 0.05%                         |                                               |                                                |                                                 |
| **Switzerland**    | Industrial development: 100.00%                | Industrial development: 100.00%               | Industrial development: 100.00%                | Industrial development: 100.00%                | no data                                        | no data                                       | no data                                       | no data                                       | Industrial development: 100.00%                | Power generation/non-renewable sources: 100.00% |
| **United Kingdom** | Industrial development: 28.39%                 | no data                                       | Industrial development: 10.73%                 | Air transport: 18.77%                          | no data                                        | no data                                       | Air transport: 6.63%                          | no data                                       | Industrial development: 30.10%                 | Industrial development: 90.54%                  |
|                | Power generation/non-renewable sources: 71.61% |                                               | Power generation/non-renewable sources: 89.27% | Industrial development: 11.78%                 |                                                |                                               | Industrial development: 92.36%                |                                               | Power generation/non-renewable sources: 69.90% | Rail transport: 9.46%                           |
|                |                                                |                                               |                                                | Power generation/non-renewable sources: 51.60% |                                                |                                               | Rail transport: 1.01%                         |                                               |                                                |                                                 |
|                |                                                |                                               |                                                | Rail transport: 17.85%                         |                                                |                                               |                                               |                                               |                                                |                                                 |
| **United States**  | Air transport: 52.77%                          | Air transport: 51.12%                         | Air transport: 8.71%                           | Air transport: 44.38%                          | Air transport: 68.94%                          | Industrial development: 91.83%                | Air transport: 59.76%                         | Air transport: 89.99%                         | Air transport: 98.61%                          | Air transport: 39.86%                           |
|                | Industrial development: 27.25%                 | Industrial development: 44.44%                | Industrial development: 31.05%                 | Industrial development: 25.28%                 | Industrial development: 11.36%                 | Power generation/non-renewable sources: 8.17% | Industrial development: 40.21%                | Industrial development: 6.68%                 | Industrial development: 1.14%                  | Industrial development: 42.22%                  |
|                | Power generation/non-renewable sources: 15.25% | Power generation/non-renewable sources: 4.43% | Power generation/non-renewable sources: 60.23% | Power generation/non-renewable sources: 29.64% | Power generation/non-renewable sources: 18.32% |                                               | Power generation/non-renewable sources: 0.03% | Power generation/non-renewable sources: 3.32% | Power generation/non-renewable sources: 0.19%  | Power generation/non-renewable sources: 17.91%  |
|                | Rail transport: 4.73%                          | Rail transport: 0.00%                         | Rail transport: 0.01%                          | Rail transport: 0.70%                          | Rail transport: 1.38%                          |                                               |                                               | Rail transport: 0.01%                         | Rail transport: 0.06%                          | Rail transport: 0.00%                           |`
)}

function _34(md){return(
md`---`
)}

function _35(md){return(
md`## Visualization 3: (20 points)`
)}

function _height(){return(
1000
)}

function _rows(){return(
5
)}

function _cols(){return(
4
)}

function _row(d3,rows,height){return(
d3.scaleBand()
    .domain(d3.range(rows))
    .range([0, height])
    .paddingInner(0.3)
)}

function _col(d3,cols,width){return(
d3.scaleBand()
    .domain(d3.range(cols))
    .range([0, width])
    .paddingInner(0.2)
)}

function _grid(d3,rows,cols){return(
d3.cross(d3.range(rows), d3.range(cols), (row, col) => ({ row, col }))
)}

function _filteredAidData3(d3,filteredAidData){return(
d3.rollup(
  filteredAidData,
  v => d3.sum(v, d => d.amount),
  d => d.donor,
  d => d.recipient,
  d => {
    const start = Math.floor((d.yearInt - 1973) / 3) * 3 + 1973;
    return `${start}-${start + 2}`;
  }
)
)}

function _sortedYearRanges(filteredAidData3)
{
  const yearRangesSet = new Set();
  filteredAidData3.forEach(recipientMap => {
    recipientMap.forEach(yearMap => {
      yearMap.forEach((value, yearRange) => {
        yearRangesSet.add(yearRange);
      });
    });
  });
  const yearRanges = Array.from(yearRangesSet).sort();
  return yearRanges;
}


function _aggregatedAidData3(topDonors,filteredAidData3,topRecipients,sortedYearRanges,grid){return(
topDonors.map((country, i) => {

  const donateAmounts = filteredAidData3.get(country);
  const completeDonate = topRecipients.map((recipient, j) => {
    const receiveAmounts = filteredAidData3.get(country).get(recipient) || new Map();
    const completeReceive = sortedYearRanges.map(yearRange => {
      const record = receiveAmounts.has(yearRange) ? receiveAmounts.get(yearRange) : 0;
      return {
        yearRange,
        amount: record
      }
    });
    return {
      recipient,
      receive: completeReceive
    };
  })
  
  const { row, col } = grid[i] || { row: undefined, col: undefined };
  
  return {
    donor: country,
    donate: completeDonate,
    row,
    col
  };
})
)}

function _45(Swatches,d3,topRecipients){return(
Swatches(d3.scaleOrdinal(topRecipients, d3.schemeCategory10))
)}

function _46(cols,rows,d3,sortedYearRanges,topRecipients,aggregatedAidData3)
{
  const subplotWidth = 250;
  const subplotHeight = 200;
  const margin = { top: 20, right: 30, bottom: 40, left: 30 };

  const svgWidth = cols * subplotWidth + margin.left + margin.right;
  const svgHeight = rows * subplotHeight + margin.top + margin.bottom;

  const x = d3.scalePoint()
    .domain(sortedYearRanges)
    .range([margin.left, subplotWidth - margin.right]);

  const svg = d3.create("svg")
    .attr("width", svgWidth)
    .attr("height", svgHeight);

  const colorScale = d3.scaleOrdinal()
    .domain(topRecipients)
    .range(d3.schemeCategory10);

  aggregatedAidData3.forEach((donorData, i) => {
    const row = donorData.row;
    const col = donorData.col;
    
    const g = svg.append("g")
      .attr("transform", `translate(${col * subplotWidth}, ${row * subplotHeight})`);
    
    g.append("rect")
      .attr("width", subplotWidth)
      .attr("height", subplotHeight)
      .attr("fill", "#ffffff");
    
    g.append("text")
      .attr("x", 40)
      .attr("y", 30)
      .attr("text-anchor", "start")
      .text(donorData.donor)
      .attr("font-size", "11px");
    
    let maxAmount = 0;
    donorData.donate.forEach(recipientData => {
      recipientData.receive.forEach(d => {
        if (d.amount > maxAmount) maxAmount = d.amount;
      });
    });
    if (maxAmount === 0) maxAmount = 1;
    
    const y = d3.scaleLinear()
      .domain([0, maxAmount])
      .range([subplotHeight - margin.bottom, margin.top]);
    
    const line = d3.line()
      .x(d => x(d.yearRange))
      .y(d => y(d.amount));
    
    donorData.donate.forEach(recipientData => {
      g.append("path")
        .datum(recipientData.receive)
        .attr("fill", "none")
        .attr("stroke", colorScale(recipientData.receive))
        .attr("d", line);
    });
    
    const xAxis = d3.axisBottom(x).tickSize(0);
    g.append("g")
      .attr("transform", `translate(0, ${subplotHeight - margin.bottom})`)
      .call(xAxis)
      .selectAll("text")
      .attr("font-size", "8px")
      .attr("transform", "rotate(-45)")
      .attr("text-anchor", "end");
    
    const yAxis = d3.axisLeft(y).ticks(3).tickFormat(d3.format("~s"));
    g.append("g")
      .attr("transform", `translate(${margin.left}, 0)`)
      .call(yAxis)
      .selectAll("text")
      .attr("font-size", "8px");
  });

  svg.append("text")
    .attr("x", 60)
    .attr("y", 15)
    .attr("text-anchor", "start")
    .text("The patterns of donations change over time (for Vis3)")
    .style("font-size", "14pt");
  
  return svg.node();
}


function _47(md){return(
md`### Q1

For this last exercise you have to extend the analysis above to see how the patterns of donations change over time. Focusing again on the top 10 recipients and top 20 donors, how do the patterns of donations (who donates to whom and how much) change over time? Are there sudden changes?

**Answer:** 

1. The patterns of donations over time are in the figure shown above (**The patterns of donations change over time (for Vis3)**).
2. **Yes, there are some sudden changes.** For example, the amount of donations from Germany (subchart in the third column of the first row) to Poland (brown line) suddenly started to rise in 1985 and peaked in 1990, but started to fall abruptly after 1990.

In this problem, I aggregated _aiddata_ sequentially based on _donor_, _recipient_ and _yearInt_ to get _filteredAidData3_. Since the problem relates to time, **I plot a chart with 5*4 subcharts, each subchart representing a line graph of the amount of money donated by one donor to different recipients over time.**

Based on the series of line graphs, I can get the patterns of donations over time. In addition, there are some sudden changes. For example, the amount of donations from Germany (subchart in the third column of the first row) to Poland (brown line) suddenly started to rise in 1985 and peaked in 1990, but started to fall abruptly after 1990.`
)}

function _48(md){return(
md`### Q2 

Are there countries that always donate to other countries? Are there major shifts (say a country used to donate to a specific set of countries and then it changes to other countries)?

**Answer:**

1. **Yes, there are some countries that always donate to other countries.** For example, both United Kingdom (subchart in the fourth column of the first row) and Switzerland (subchart in the fourth column of the second row) always donate to India (blue line).
2. **Yes, there are some major shifts.** For example, France (subchart in the first column of the second row) donated mainly to India (blue line) and Brazil (green line) in 1973-1990, but mainly to Poland (brown line) in 1997-2008. After 2012, France contributed mainly to countries such as Brazil (green line) and Colombia (red line).

In this question, **I have plotted a series of line graphs, with each subgraph representing the amount of money donated by one donor to different recipients in different time periods.**

Through the different line graphs I can find that there are countries that always donate to other countries and there are some major shifts.`
)}

function _49(md){return(
md`-----------------
## Appendix`
)}

function _d3(require){return(
require('d3@7')
)}

function _googleSheetCsvUrl(){return(
'https://docs.google.com/spreadsheets/d/1YiuHdfZv_JZ-igOemKJMRaU8dkucfmHxOP6Od3FraW8/gviz/tq?tqx=out:csv'
)}

export default function define(runtime, observer) {
  const main = runtime.module();
  function toString() { return this.url; }
  const fileAttachments = new Map([
    ["countries-50m.json", {url: new URL("./files/55260abbc777c0a3b8fed19f3929dd822fef9d5118b53b76b2176d20782910e599eac919999ea8ee85a60b783fd37082574f6591fd46c0d70ddf9b00df71ce27.json", import.meta.url), mimeType: "application/json", toString}]
  ]);
  main.builtin("FileAttachment", runtime.fileAttachments(name => fileAttachments.get(name)));
  main.variable(observer()).define(["md"], _1);
  main.variable(observer()).define(["md"], _2);
  main.variable(observer()).define(["Inputs","aiddata"], _3);
  main.variable(observer("aiddata")).define("aiddata", ["d3","googleSheetCsvUrl"], _aiddata);
  main.variable(observer()).define(["md"], _5);
  main.variable(observer("geoJSON")).define("geoJSON", ["FileAttachment"], _geoJSON);
  main.variable(observer()).define(["md"], _7);
  main.variable(observer()).define(["md"], _8);
  main.variable(observer()).define(["md"], _9);
  const child1 = runtime.module(define1);
  main.import("legend", child1);
  main.import("swatches", child1);
  main.import("Legend", child1);
  main.import("Swatches", child1);
  main.variable(observer()).define(["md"], _11);
  main.variable(observer()).define(["md"], _12);
  main.variable(observer()).define(["md"], _14);
  main.variable(observer("aiddataByCountries")).define("aiddataByCountries", ["aiddata","d3"], _aiddataByCountries);
  main.variable(observer("topDonors")).define("topDonors", ["aiddataByCountries"], _topDonors);
  main.variable(observer("topRecipients")).define("topRecipients", ["aiddataByCountries"], _topRecipients);
  main.variable(observer("filteredAidData")).define("filteredAidData", ["aiddata","topDonors","topRecipients"], _filteredAidData);
  main.variable(observer("aggregatedAidData")).define("aggregatedAidData", ["d3","filteredAidData","topDonors","topRecipients"], _aggregatedAidData);
  main.variable(observer("color")).define("color", ["d3","aggregatedAidData"], _color);
  main.variable(observer()).define(["legend","color"], _21);
  main.variable(observer()).define(["d3","topRecipients","topDonors","aggregatedAidData","color"], _22);
  main.variable(observer()).define(["md"], _23);
  main.variable(observer()).define(["md"], _24);
  main.variable(observer()).define(["md"], _25);
  main.variable(observer()).define(["md"], _26);
  main.variable(observer("topPurposes")).define("topPurposes", ["d3","aiddata"], _topPurposes);
  main.variable(observer("filteredAidData2")).define("filteredAidData2", ["aiddata","topDonors","topRecipients","topPurposes"], _filteredAidData2);
  main.variable(observer("aggregatedAidData2")).define("aggregatedAidData2", ["d3","filteredAidData2"], _aggregatedAidData2);
  main.variable(observer()).define(["Swatches","d3","topPurposes"], _30);
  main.variable(observer()).define(["topDonors","topRecipients","d3","topPurposes","aggregatedAidData2"], _31);
  main.variable(observer()).define(["md"], _32);
  main.variable(observer()).define(["md"], _33);
  main.variable(observer()).define(["md"], _34);
  main.variable(observer()).define(["md"], _35);
  main.variable(observer("height")).define("height", _height);
  main.variable(observer("rows")).define("rows", _rows);
  main.variable(observer("cols")).define("cols", _cols);
  main.variable(observer("row")).define("row", ["d3","rows","height"], _row);
  main.variable(observer("col")).define("col", ["d3","cols","width"], _col);
  main.variable(observer("grid")).define("grid", ["d3","rows","cols"], _grid);
  main.variable(observer("filteredAidData3")).define("filteredAidData3", ["d3","filteredAidData"], _filteredAidData3);
  main.variable(observer("sortedYearRanges")).define("sortedYearRanges", ["filteredAidData3"], _sortedYearRanges);
  main.variable(observer("aggregatedAidData3")).define("aggregatedAidData3", ["topDonors","filteredAidData3","topRecipients","sortedYearRanges","grid"], _aggregatedAidData3);
  main.variable(observer()).define(["Swatches","d3","topRecipients"], _45);
  main.variable(observer()).define(["cols","rows","d3","sortedYearRanges","topRecipients","aggregatedAidData3"], _46);
  main.variable(observer()).define(["md"], _47);
  main.variable(observer()).define(["md"], _48);
  main.variable(observer()).define(["md"], _49);
  main.variable(observer("d3")).define("d3", ["require"], _d3);
  main.variable(observer("googleSheetCsvUrl")).define("googleSheetCsvUrl", _googleSheetCsvUrl);
  return main;
}
