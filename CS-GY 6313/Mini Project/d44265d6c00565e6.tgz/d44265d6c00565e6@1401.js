import define1 from "./a33468b95d0b15b0@817.js";

function _1(md){return(
md`# Mini-Project 2 (Time)`
)}

function _2(md){return(
md`## Data

Here we load a [simplified and reduced version](https://docs.google.com/spreadsheets/d/1YiuHdfZv_JZ-igOemKJMRaU8dkucfmHxOP6Od3FraW8/) of the [AidData dataset](https://www.aiddata.org/data/aiddata-core-research-release-level-1-3-1). You are free to change this code as you wish. If you don't want to preprocess your data on Observable, then you can do the preprocessing using whatever languages or tools you'd like and then [upload](/@observablehq/file-attachments) your preprocessed data to Observable. If you take this approach, then you should delete the \`aiddata\` cell below so that you're not loading unnecessary data.

The dataset contains the following columns:
- **yearDate**: year of the commitment as a Date object
- **yearInt**: year of the commitment as an integer
- **donor**: country providing the financial resource
- **recipient**: country receiving the financial resource
- **amount**: the total amount of financial resources provided
- **purpose**: the purpose of the transaction`
)}

function _3(Inputs,aiddata){return(
Inputs.table(aiddata)
)}

async function _aiddata(d3,googleSheetCsvUrl)
{
  const data = await d3.csv(googleSheetCsvUrl, row => ({
    yearDate: d3.timeParse('%Y')(row.year),
    yearInt: +row.year,
    donor: row.donor,
    recipient: row.recipient,
    amount: +row.commitment_amount_usd_constant,
    purpose: row.coalesced_purpose_name,
  }));
  
  data.columns = Object.keys(data[0]);
  
  return data;
}


function _5(md){return(
md`Next we load GeoJSON data for countries. This file is derived from data from [Natural Earth](https://www.naturalearthdata.com).`
)}

function _geoJSON(FileAttachment){return(
FileAttachment("countries-50m.json").json()
)}

function _7(md){return(
md`## Questions

Your goal is to create 3 independent visualizations of the same data set, each one with the intent of answering the questions stated below. For each numbered visualization, you should be able to create a data visualization that answers **all of the questions** specified. These are the 3 visualizations you should create:

- **Visualization 1:** 

  Q1) How does the amount donated vs. amount received change over time for each country? **(10 points)**
  
  Q2) Are there countries that mostly send or mostly receive and countries that have a similar amount of donations they receive and send? **(10 points)** 
  
  Q3) Are there any countries that maintain a balance between giving and receiving, i.e. the amount they donated was close to the amount they received over the long term? **(10 points)**

  Q4) Are there countries that change their role over time? That is, they used to mostly send donations and turn into mostly receiving donations and vice-versa? **(10 points)**

  Aesthetics and Clarity **(10 points)**

- **Visualization 2:** 

  Q1) Focus on the top 10 “Coalesced Purposes” of donations (in terms of amount of disbursement across all countries and all time).   **(10 points)**
  
  Q2) What are the top 10 purposes of disbursements (in terms of total amount of disbursement) and how does their relative amount compare over time? E.g., are there purposes that tend to be prominent for a period of time and others that become more prominent during other periods?  **(10 points)**
  
  Q3) Does the allocation of funds for different donation purposes exhibit cyclical patterns, such as recurring peaks or troughs every few years? **(20 points)**
  
  Hint: looking at the graph one should be able to observe: “Ah! During these years donations were mostly about X but then there were way more donations about Y”. Note: if the purpose is “UNSPECIFIED” it should be removed.

  Aesthetics and Clarity **(10 points)**

- **[OPTIONAL/EXTRA POINTS] Visualization 3:**  **(20 points)**

  Q1) Focusing exclusively on countries that receive donations, how do donations shift geographically over time? 
  
  Q2) Do donations tend to be always in the same regions of the world over the years or they have been shifting over time? 
  
  Q3) Can you build a visualization that shows the “history of donations” so that one can get a sense of which regions of the world have had more need for donations over the years? 

  Note 1: for this visualization you can, if you wish, use interaction (but you don’t have to).

** Note: ** 

  - For this exercise you may want to review the lecture on geographical visualization in which we explain how you can visualize geographical data over time. 
  - If you want, you can aggregate data over a few years (say, group together data at 5 year intervals).

For each visualization add a description of your thought process and why you think your solution is *appropriate* and *effective*.


Note it is okay to submit more than one solution for a given visualization problem if you think there are some competing solutions that work well. When you do that, make sure to compare the solutions by commenting on their advantages and disadvantages.
`
)}

function _8(md){return(
md`### Remember

The questions above are a very useful tool for you to verify whether you are producing a good solution or not. As you go about solving this exercise you can use the questions above as an evaluation tool in two main ways:
1. Verify that you can indeed answer the questions with your visualization. If you can’t fully answer the questions, it means your solution has some problems.
2. Compare multiple solutions to the same problem and ask yourself: “which one makes it easier for me to answer these questions?”, where easier may mean, more accurately, with less effort or faster.
`
)}

function _9(md){return(
md`## Instructions
- Your coded solutions must use D3. Other visualization libraries are not allowed.
- You should feel free to process and transform the data any way you deem relevant and use any tool you prefer for data processing. Data transformation does not necessarily have to be in JavaScript nor within Observable. It’s ok to pre-process the data and then load it in Observable if you prefer.
- You can use Mike Bostock's [Color Legend](/@d3/color-legend) notebook to create your legends.`
)}

function _11(md){return(
md`## Grading Criteria

The main parameters we will use for grading are the following:

- Does the information extracted answer the questions posed in the exercise?
- Does the visualization answer the questions posed in the exercise?
- Is the visual representation clear? Does it have good aesthetics?
  - Review this [notebook on clarity](/@nyuinfovis/contextual-elements-aesthetics-and-clarity) for reference.`
)}

function _12(width){return(
width
)}

function _13(md){return(
md`## Solutions`
)}

function _14(md){return(
md`## Visualization 1`
)}

function _height(){return(
1600
)}

function _rows(){return(
12
)}

function _cols(){return(
4
)}

function _row(d3,rows,height){return(
d3.scaleBand()
    .domain(d3.range(rows))
    .range([0, height])
    .paddingInner(0.3)
)}

function _col(d3,cols,width){return(
d3.scaleBand()
    .domain(d3.range(cols))
    .range([0, width])
    .paddingInner(0.2)
)}

function _grid(d3,rows,cols){return(
d3.cross(d3.range(rows), d3.range(cols), (row, col) => ({ row, col }))
)}

function _21(md){return(
md`### Q1 (10 points)

How does the amount donated vs. amount received change over time for each country?`
)}

function _22(md){return(
md`**Answer:** I have **plotted a chart for this question that shows how the amount of donations and receipts for each country has changed over the years**. In addition, I have written a **table below the chart which describes the process of change for each country.**

First I aggregate the _aiddata_ based on the donors and recipients separately. For each country I aggregate the donor data and the recipient data in time periods of every 5 years (e.g. 1973-1977). As a result, I can get two data _aiddataByDonors_ and _aiddataByRecipients_.`
)}

function _aiddataByDonors(d3,aiddata){return(
new Map(
  Array.from(
    d3.rollup(
      aiddata,
      v => d3.sum(v, d => d.amount),
      d => d.donor,
      d => {
        const bucket = Math.floor((d.yearInt - 1973) / 5);
        const start = 1973 + bucket * 5;
        return `${start}-${start + 4}`;
      }
    ),
    ([donor, yearMap]) => [donor, Array.from(yearMap, ([yearRange, amount]) => ({ yearRange, amount }))]
  )
)
)}

function _aiddataByRecipients(d3,aiddata){return(
new Map(
  Array.from(
    d3.rollup(
      aiddata,
      v => d3.sum(v, d => d.amount),
      d => d.recipient,
      d => {
        const bucket = Math.floor((d.yearInt - 1973) / 5);
        const start = 1973 + bucket * 5;
        return `${start}-${start + 4}`;
      }
    ),
    ([recipient, yearMap]) => [recipient, Array.from(yearMap, ([yearRange, amount]) => ({ yearRange, amount }))]
  )
)
)}

function _sortedYearRanges(aiddataByDonors){return(
Array.from(
  new Set(
    Array.from(aiddataByDonors.values())
      .flat()
      .map(group => group.yearRange)
  )
).sort((a, b) => {
  const startA = parseInt(a.split('-')[0], 10);
  const startB = parseInt(b.split('-')[0], 10);
  return startA - startB;
})
)}

function _allCountries(aiddataByDonors,aiddataByRecipients){return(
Array.from(
  new Set([
    ...Array.from(aiddataByDonors.keys()),
    ...Array.from(aiddataByRecipients.keys())
  ])
)
)}

function _countryData(allCountries,aiddataByDonors,sortedYearRanges,aiddataByRecipients,d3,grid){return(
allCountries.map((country, i) => {
  
    const donateAmounts = aiddataByDonors.get(country) || [];
    const completeDonate = sortedYearRanges.map(yearRange => {
      const record = donateAmounts.find(d => d.yearRange === yearRange);
      return record ? record : { yearRange, amount: 0 };
    });
  
    const receiveAmounts = aiddataByRecipients.get(country) || [];
    const completeReceive = sortedYearRanges.map(yearRange => {
      const record = receiveAmounts.find(d => d.yearRange === yearRange);
      return record ? record : { yearRange, amount: 0 };
    });
    
    const completeDiff = sortedYearRanges.map((yearRange, idx) => {
      return { yearRange, amount: completeDonate[idx].amount - completeReceive[idx].amount };
    });

    const totalDiff = d3.sum(completeDiff, d=>d.amount);
  
    const { row, col } = grid[i] || { row: undefined, col: undefined };
  
    return {
      country,
      donate: completeDonate,
      receive: completeReceive,
      diff: completeDiff,
      totalDiff,
      row,
      col
    };
  })
)}

function _28(md){return(
md`After I get two processed data, I can **plot a chart of donations and receipts over time**. Note that I have **put a country's donations data and receipts data in the same subgraph** so that I can view a country's donations data and receipts data directly in a single subgraph based on _countryData_.

In a subchart, I place the value of 0 in the middle of the y-axis, with the 0 scale above indicating how much a country donated in different years (marked as blue) and the 0 scale below indicating how much a country received in different years (marked as red).`
)}

function _29(Swatches,d3){return(
Swatches(d3.scaleOrdinal(["donations", "recipients"], [d3.schemeRdBu[3][2], d3.schemeRdBu[3][0]]))
)}

function _30(d3,sortedYearRanges,col,width,height,countryData,row)
{
  const margin = ({top: 40, bottom: 40, left: 40, right: 20});

  const x = d3.scaleBand()
    .domain(sortedYearRanges)
    .range([0, col.bandwidth()]);
  
  // create and select an svg element that is the size of the bars plus margins 
  const svg = d3.create('svg')
      .attr('width', width + margin.left + margin.right)
      .attr('height', height + margin.top + margin.bottom);
  
  // append a group element and move it left and down to create space
  // for the left and top margins
  const g = svg.append("g")
      .attr('transform', `translate(${margin.left}, ${margin.top})`);

  const dataToScaleAndArea = Object.fromEntries(
    countryData.map(d => {

      let maxDonateAmount = d3.max(d.donate, d => d.amount);
      if (maxDonateAmount == 0) maxDonateAmount = 100000;

      let maxReceiveAmount = d3.max(d.receive, d => d.amount);
      if (maxReceiveAmount == 0) maxReceiveAmount = 100000;
      
      const yDonate = d3.scaleLinear()
          .domain([0, maxDonateAmount])
          .range([row.bandwidth()/2, 0]);
      const yReceive = d3.scaleLinear()
          .domain([0, maxReceiveAmount])
          .range([row.bandwidth()/2, row.bandwidth()]);
      
      const donateArea = d3.area()
        .x(d => x(d.yearRange))
        .y1(d => yDonate(d.amount))
        .y0(d => yDonate(0));
      const receiveArea = d3.area()
        .x(d => x(d.yearRange))
        .y1(d => yReceive(d.amount))
        .y0(d => yReceive(0));
  
      return [d.country, {yDonate, yReceive, donateArea, receiveArea}];
    })
  )
  
  // create a group for each small multiple
  const cells = g.append('g')
    .selectAll('g')
    .data(countryData)
    .join('g')
      .attr('class', 'cell')
      .attr('transform', d => `translate(${col(d.col)}, ${row(d.row)})`);
  
  // add the area to each cell
  
  cells.append('path')
      // access the area generator for this industry
      .attr('d', d => dataToScaleAndArea[d.country].donateArea(d.donate))
      .attr('fill', d3.schemeRdBu[3][2]);
  cells.append('path')
      // access the area generator for this industry
      .attr('d', d => dataToScaleAndArea[d.country].receiveArea(d.receive))
      .attr('fill', d3.schemeRdBu[3][0]);
  
  // add the y axis for each cell
  cells.each(function(d) {
    const group = d3.select(this);
    group.append('g')
      .attr('class', 'y-donate-axis')
      .call(
        d3.axisLeft(dataToScaleAndArea[d.country].yDonate)
          .ticks(3)
          .tickSizeOuter(0)
          .tickFormat(d3.format("~s"))
      );
    group.append('g')
      .attr('class', 'y-receive-axis')
      .call(
        d3.axisLeft(dataToScaleAndArea[d.country].yReceive)
          .ticks(3)
          .tickSizeOuter(0)
          .tickFormat(d3.format("~s"))
      );
  });

  const xAxis = d3.axisBottom(x)
      .tickSizeOuter(0);

  cells.append('g')
      // move it to the bottom
      .attr('transform', d => `translate(-10, ${row.bandwidth()})`)
      .call(xAxis)
      // remove the baseline
      .call(g => g.select('.domain'))
      .selectAll("text")
      .attr("transform", "rotate(45)")
      .attr("text-anchor", "start")
      .style("font-size", "8px");

  cells.append('g')
    .attr('class', 'x-axis-zero')
    .attr('transform', d => `translate(0, ${dataToScaleAndArea[d.country].yDonate(0)})`)
    .append('line')
      .attr('x1', 0)
      .attr('x2', col.bandwidth())
      .attr('stroke', 'black')
      .attr('stroke-width', 0.5);

  cells.append("text")
    .attr("x", 10)
    .attr("y", 15)
    .text(d => d.country)
    .attr("fill", "black")
    .attr("font-size", "12px")
    .attr("text-anchor", "start");

  svg.append("text")
    .attr("x", width/6)
    .attr("y", 15)
    .text("The amount of donations and recipients for each country in different time period (for Vis1-Q1)")
    .attr("fill", "black")
    .attr("font-size", "20px")
    .attr("text-anchor", "start");
  
  return svg.node();
}


function _31(md){return(
md`Based on this chart, **I have described in the table for each country in the chart how their donations and receipts have changed.**

|Country|How does the amount donated vs. amount received change over time|
|:--:|:--:|
|Saudi Arabia|Saudi Arabia's donations remained at around $500 million until 1988, but no donations were recorded in subsequent periods; its receipts peaked at more than $3 billion in 1993-1998, and were relatively low in other periods.|
|Kuwait|Kuwait's donations peaked at $600 million around 1980 and have declined since then; it received goods of up to $6 billion in the 1980s and had no records of receipts at other times.|
|Qatar|Qatar donated the financial resource about $100 million in 2003-2007 and received the financial resource about $600 million in 1993-1997. There are no records of donations and receipts at other times.|
|Brazil|Brazil began donating financial resources after 2003, increasing to $1 million in 2008-2012, with no recorded donations at other times; Brazil has been receiving financial resources since 1973, with continued increases in subsequent years, peaking in the 1993-1997 and 2008-2012 time ranges.|
|Colombia|Colombia donated around $100 thousand after 1998, and Colombia has received financial resources after 1973 and has continued growing, peaking at $5 billion after 21st century.|
|Estonia|Estonia donated only about $300 thousand in financial resources in 1998-2002; it received financial resources after 1988, and received goods at the peak of more than $100 million around 1993. After 1997 receipts began to decline.|
|Hungary|Hungary was similar to Estonia and donated about $250 thousand in financial resources in 2003-2007; it received goods after 1983, and received over $100 million in goods around 1993. After 1993 receipts declined.|
|United States|United States is the major donor, consistently donating more than $10 billion in financial resources, but after 2003, the amount of donations began to decline. In addition, United States only received financial resources with about $100 million in 2003-2007.|
|Thailand|Thailand donated about $20 million in financial resources during the period 1998-2017, and has no record of donations prior to 1998. Thailand has been a recipient record of financial resources since 1973 and has continued to increase, reaching more than $12 billion around 1993, after which it began to decline.|
|Liechtenstein|Liechtenstein had a record of donating about $1 million in 1978-1982, and  it rose to more than $1.5 million around 2000. Liechtenstein only had a record of receiving about $15 million from 1978-1982.|
|Slovak Republic|Slovak Republic only had a sending record of about $300 thousand around 2003, but had a receiving record of over $400 million in 1993-2007.|
|Monaco|Monaco has no record of receipt but has donated over $400 thousand in financial resources since 2000 and continues to increase the amount.|
|Chile|Chile has a record of giving after 1998 and peaked around 2003 and has since decreased the donated amount. However, Chile has received financial resources since 1973, peaking in 1988-1992, and after 1992 it began to decrease the amount.|
|Taiwan|Taiwan had a record of over $40 million in donations in 1993, but has been declining since then. Taiwan has had 2 peaks in receipt records, respectively in 1980 and 2000.|
|United Arab Emirates|United Arab Emirates had a high donating record in 1973 and a high receiving record in 1983, but since then United Arab Emirates has donated and received very little.|
|Belgium|Belgium has consistently donated around $200 million, except for a peak of about $800 million in 1988, and Belgium has only received financial resources in 1978-1982.|
|Japan|Japan is the major donor, consistently donating more than $10 billion in financial resources, peaking at more than $20 billion in 1993 and declining after 1997. Japan has received about $1 billion in financial resources through the 21st century.|
|Austria|Austria had two peaks in donations of financial resources, in 1983 and 1998, and two peaks in receipts of goods, in 1978 and 1998.|
|Italy|Italy's donations continued to rise, reaching a peak of $1.5 billion in 1993, and Italy had two peaks in receipts, in 1978 and 1993.|
|Germany|Germany's donation amount is relatively stable, peaking only in 1988-1992 at over $15 billion. Germany has only recorded receiving financial resources in 2003-2007.|
|Sweden|Sweden's donation amount has risen steadily since 1973 and declined after 1992, and Sweden has only received financial resources in 1978-1982.|
|Luxembourg|Luxembourg has been donating financial resources since 1998 and has continued to rise, reaching a peak of $40 million in 2008. luxembourg received higher financial resources in 1993 and continued to decline in receipts since then.|
|Spain|Spain received financial resources only in 1978-1982, but Spain has been donating consistently since then, and the amount of donations has continued to rise, reaching a peak of $600 million in 2008.|
|Denmark|Denmark had two peaks in donating financial resources in 1983 and 1993, and then began to decline, while Denmark only received goods from 1978 to 1987.|
|France|France's donation amount have been rising since 1973 and peaked at more than $3 billion in 2008. France has only received financial resources in 1978-1982.|
|Norway|Norway's donation amount has been on a slight decline followed by a steady increase. Norway also received a large amount of financial resources in 1978, after which it began to decline.|
|Portugal|Portugal received financial resources in 1978 and then declined to zero in 1990. After 1990 Portugal began to donate financial resources and reached a peak of $30 million in 2008.|
|Switzerland|Switzerland has three peaks in financial resource contributions, in 1973, 1983 and 1998. Switzerland's receipts only peaked in 1998 and have been declining after that.|
|United Kingdom|United Kingdom is a major donor with a stable amount of donations. United Kingdom has a peak of more than $4 billion in 2003. United Kingdom has only received in 1978.|
|Finland|Finland is relatively stable donor in 1988-2012, which is around $100 million. In 1983-1987 Finland has a record of receipts.|
|Ireland|Ireland's donation amount peaked at over $100 million in 2003 and have been declining since then. Ireland's receipts are relatively low, while being high only in 1998-2002.|
|Australia|Australia's donation amount rose in 1983-1988 and began to fall after 1988. Australia's receipts has two peaks in 1978 and 1998.|
|Canada|Canada's donation amount peaked in 1983 and 1998. Canada's receipts amount declined from 1978.|
|Korea|The amount of donations in Korea has not changed particularly significantly since 2003. However, Korea's receipts had two peaks, in 1978 and 1998.|
|Greece|Greece started to donate financial resources after 1993, reaching a peak in 2003. after 2003 it started to decline. Greece's receipts started to rise in 1973 and decline in 1988.|
|Netherlands|Netherlands was the major donor and it donated more than $1 billion consistently in 1973-1992, after which it began to decline. Netherlands has no record of receiving financial resources.|
|New Zealand|New Zealand's donations rose from 1993 and declined in 2003, and New Zealand only received financial resources from 1978-1982.|
|Cyprus|Cyprus has recorded donations of financial resources only in 2003, amounting to approximately $5 thousand. Receipts of Cyprus began to rise in 1973-1987 and began to decline after 1987.|
|Czech Republic|Czech Republic's donations began to decline in 1993. Czech Republic's receipts began to rise in 1983 and began to decline in 1993.|
|Slovenia|Slovenia has a record of donating financial resources in 2008.Slovenia's receipts started to rise in 1983 and fall in 1993.|
|Iceland|Iceland's donation amount have risen since 2008. Iceland has only recorded receipts in 1978.|
|Poland|Poland has a record of donations only in 2013-2017. The amount of receipts in Poland started to rise in 1978 and fall after peaking in 1988.|
|India|India is the main recipient with no record of donations. India's receipts are relatively stable, with relatively low receipts only in 1998-2002.|
|Lithuania|Lithuania has no record of donations. Lithuania's receipts began to rise in 1988 and declined in 1997.|
|South Africa|South Africa has no record of donations. South Africa's receipts began to rise in 1983 and declined in 2012.|
|Romania|Romania has no record of donations. Romania's receipts began to rise in 1983 and declined in 1998.|
|Latvia|Latvia has no record of donations. Latvia's receipts began to rise in 1983 and declined in 1993.|`
)}

function _32(md){return(
md`### Q2 (10 points)

Are there countries that mostly send or mostly receive and countries that have a similar amount of donations they receive and send?

**Answer: Yes, there are countries that are major senders, major receivers, and countries that donate similar amounts to those that receive.**

- Countries that mostly send: **United States, Japan, Germany, France and United Kingdom** and etc.
- Countries that mostly receive: **Brazil, Colombia, Thailand, Korea, Poland, India and South Africa** and etc.
- Countries that have a similar amount of donations they receive and send: **Liechtenstein, Monaco, Austria and Iceland** and etc.

I use _totalDiff_ of _countryData_ in Q1, which represents the difference between the total donations and the total recipients for each country.

For this problem, I plot the **Diverging bar chart** to represent the total difference of donation and recipient for each country. In this chart, I fix the value of 0 at the center of the chart, the left side of the 0-value axis indicates that the value of donation is less than the value of recipient (marked in red), and the right side indicates that the donation is more than the recipient (marked in blue).`
)}

function _33(countryData){return(
countryData
)}

function _34(countryData,d3,width)
{
  const barHeight = 25;
  const marginTop = 60;
  const marginRight = 100;
  const marginBottom = 10;
  const marginLeft = 100;

  const data = countryData.sort((a, b) => a.totalDiff - b.totalDiff);
  
  const height = Math.ceil((data.length + 0.1) * barHeight) + marginTop + marginBottom;
  
  const x = d3.scaleLinear()
    .domain(d3.extent(data, d => d.totalDiff))
    .rangeRound([marginLeft, width - marginRight]);

  const y = d3.scaleBand()
    .domain(data.map(d => d.country))
    .rangeRound([marginTop, height - marginBottom])
    .padding(0.1);

  const format = d3.format("+,d");
  const tickFormat = d3.formatPrefix("+.1", 1e9);

  const svg = d3.create("svg")
      .attr("viewBox", [0, 0, width, height])
      // .attr("style", "max-width: 100%; height: auto; font: 10px sans-serif;");

  svg.append("g")
    .selectAll()
    .data(data)
    .join("rect")
      .attr("fill", (d) => d3.schemeRdBu[3][d.totalDiff > 0 ? 2 : 0])
      .attr("x", (d) => x(Math.min(d.totalDiff, 0)))
      .attr("y", (d) => y(d.country))
      .attr("width", d => Math.abs(x(d.totalDiff) - x(0)))
      .attr("height", y.bandwidth());

  svg.append("g")
      .attr("font-family", "sans-serif")
      .attr("font-size", 10)
    .selectAll()
    .data(data)
    .join("text")
      .attr("text-anchor", d => d.totalDiff < 0 ? "end" : "start")
      .attr("x", (d) => x(d.totalDiff) + Math.sign(d.totalDiff - 0) * 4)
      .attr("y", (d) => y(d.country) + y.bandwidth() / 2)
      .attr("dy", "0.35em")
      .text(d => format(d.totalDiff));

  svg.append("g")
    .attr("transform", `translate(0,${marginTop})`)
    .call(d3.axisTop(x).ticks(width / 80).tickFormat(tickFormat))
    .call(g => g.selectAll(".tick line").clone()
          .attr("y2", height - marginTop - marginBottom)
          .attr("stroke-opacity", 0.1))
    .call(g => g.select(".domain").remove());

  svg.append("g")
    .attr("transform", `translate(${x(0)},0)`)
    .call(d3.axisLeft(y).tickSize(0).tickPadding(6))
    .call(g => g.selectAll(".tick text").filter((d, i) => data[i].totalDiff < 0)
        .attr("text-anchor", "start")
        .attr("x", 6));

  svg.append("text")
    .attr("x", width/6)
    .attr("y", 15)
    .text("The total difference of donation and recipient for each country (for Vis1-Q2)")
    .attr("fill", "black")
    .attr("font-size", "20px")
    .attr("text-anchor", "start");

  return svg.node();
}


function _35(md){return(
md`Using the Diverging bar chart, I can get some countries that mostly send, mostly receive and countries that have a similar amount of donations they receive and send:

- Countries that mostly send: United States, Japan, Germany, France and United Kingdom and etc.
- Countries that mostly receive: Brazil, Colombia, Thailand, Korea, Poland, India and South Africa and etc.
- Countries that have a similar amount of donations they receive and send: Liechtenstein, Monaco, Austria and Iceland and etc.`
)}

function _36(d3,countryData){return(
d3.filter(countryData, d => d.totalDiff > 10000000000).map(d => d.country)
)}

function _37(d3,countryData){return(
d3.filter(countryData, d => d.totalDiff < -10000000000).map(d => d.country)
)}

function _38(d3,countryData){return(
d3.filter(countryData, d => d.totalDiff < 100000000 && d.totalDiff > -100000000).map(d => d.country)
)}

function _39(md){return(
md`### Q3 (10 points) 

Are there any countries that maintain a balance between giving and receiving, i.e. the amount they donated was close to the amount they received over the long term?

**Answer:** **Yes, Liechtenstein, Monaco and Iceland** maintain a balance between giving and receiving.

Based on the _countryData_ obtained in *Q1*, I calculate the difference between donations and receipts for each country over a range of years (_diff = donation - recipient_). This allows us to create a graph based on the _diff_ value, with **each subgraph in the graph showing the difference between donations and receipts for each country over different time periods**.

For each subplot, I place the value of 0 in the middle of the y-axis, with positive values indicating that donations amount is more than recipients amount in the time period, and negative values indicating that recipients amount is more than donations amount in the time period.

For this question, I need to look at the subplot for each country. **If the line is consistently around the value of 0, it indicates that this country maintain a balance between giving and receiving.**`
)}

function _40(d3,sortedYearRanges,col,width,height,countryData,row)
{
  const margin = ({top: 40, bottom: 40, left: 40, right: 20});

  const x = d3.scaleBand()
    .domain(sortedYearRanges)
    .range([0, col.bandwidth()]);
  
  // create and select an svg element that is the size of the bars plus margins 
  const svg = d3.create('svg')
      .attr('width', width + margin.left + margin.right)
      .attr('height', height + margin.top + margin.bottom);
  
  // append a group element and move it left and down to create space
  // for the left and top margins
  const g = svg.append("g")
      .attr('transform', `translate(${margin.left}, ${margin.top})`);

  const dataToScaleAndArea = Object.fromEntries(
    countryData.map(d => {
      let maxAmount = Math.max(Math.abs(d3.max(d.diff, d => d.amount)), Math.abs(d3.min(d.diff, d => d.amount)));
      
      maxAmount = Math.max(maxAmount, 500000000);
      
      const y = d3.scaleLinear()
          .domain([-maxAmount, maxAmount])
          .range([row.bandwidth(), 0]);
      
      const area = d3.area()
        .x(d => x(d.yearRange))
        .y1(d => y(d.amount))
        .y0(d => y(0));
  
      return [d.country, {y, area}];
    })
  )
  
  // create a group for each small multiple
  const cells = g.append('g')
    .selectAll('g')
    .data(countryData)
    .join('g')
      .attr('class', 'cell')
      .attr('transform', d => `translate(${col(d.col)}, ${row(d.row)})`);
  
  // add the area to each cell
  
  cells.append('path')
      // access the area generator for this industry
      .attr('d', d => dataToScaleAndArea[d.country].area(d.diff))
      .attr('fill', 'steelblue');
  
  // add the y axis for each cell
  cells.each(function(d) {
    // select the group for this cell
    const group = d3.select(this);

    // get the y-scale for this industry
    const yAxis = d3.axisLeft(dataToScaleAndArea[d.country].y)
        .ticks(3)
        .tickSizeOuter(0)
        .tickFormat(d3.format("~s"));
    
    group.call(yAxis)
        .call(g => g.select('.domain'));
  });

  const xAxis = d3.axisBottom(x)
      .tickSizeOuter(0);

  cells.append('g')
      // move it to the bottom
      .attr('transform', d => `translate(-10, ${row.bandwidth()})`)
      .call(xAxis)
      // remove the baseline
      .call(g => g.select('.domain'))
      .selectAll("text")
      .attr("transform", "rotate(45)")
      .attr("text-anchor", "start")
      .style("font-size", "8px");

  cells.append('g')
    .attr('class', 'x-axis-zero')
    .attr('transform', d => `translate(0, ${dataToScaleAndArea[d.country].y(0)})`)
    .append('line')
      .attr('x1', 0)
      .attr('x2', col.bandwidth())
      .attr('stroke', 'black')
      .attr('stroke-width', 0.5);

  cells.append("text")
    .attr("x", 10)
    .attr("y", 15)
    .text(d => d.country)
    .attr("fill", "black")
    .attr("font-size", "12px")
    .attr("text-anchor", "start");

  svg.append("text")
    .attr("x", margin.left)
    .attr("y", 15)
    .text("The difference of donation and recipient for each country in different time period (for Vis1-Q3,Q4)")
    .attr("fill", "black")
    .attr("font-size", "20px")
    .attr("text-anchor", "start");
  
  return svg.node();
}


function _41(md){return(
md`Thus, based on the above subcharts, I can get the countries that maintain a balance between giving and receiving: **Liechtenstein, Monaco and Iceland**.`
)}

function _42(md){return(
md`### Q4 (10 points)

Are there countries that change their role over time? That is, they used to mostly send donations and turn into mostly receiving donations and vice-versa?

**Answer:** **Yes, Spain, Australia and Canada** are countries that change their role over time.

**I use the chart plotted in Q3 in this question to answer this question.** For this question, I need to see which countries **have a line below the 0-value axis at one time and above the 0-value axis at another time**.

It can be seen that Spain, Australia and Canada fulfill the conditions given in the question. For Spain and Canada, these two countries had higher receipts in the time period 1973-1978 and after that they had higher donations. In addition, Australia had higher receipts in the time period 1973-1978 and 1988-1998, and their donations were higher in the other time periods.`
)}

function _43(md){return(
md`## Visualization 2`
)}

function _44(md){return(
md`### Q1 (10 points) 

Focus on the top 10 "Coalesced Purposes" of donations (in terms of amount of disbursement across all countries and all time).

Note: **if the purpose is "UNSPECIFIED" it should be removed.**

**Answer:** **The top 10 Coalesced Purposes are shown below:**

1. Air transport
2. Rail transport
3. Industrial development
4. Power generation/non-renewable sources
5. RESCHEDULING AND REFINANCING
6. Import support (capital goods)
7. Social/ welfare services
8. Telecommunications
9. Power generation/renewable sources
10. Mineral/Metal prospection and exploration

For this problem, I need to aggregate the _aiddata_ by _purpose_ to get the data _aiddataByPurpose_. In this data, I add an additional parameter called _total_, which represents the transportation amount of the Coalesced Purpose for all countries and all time. **Finally I get the data _purposeData_ that can be plotted on the charts.** This data can be used to answer Q2.`
)}

function _aiddataByPurposes(d3,aiddata){return(
new Map(
  Array.from(
    d3.rollup(
      aiddata,
      v => d3.sum(v, d => d.amount),
      d => d.purpose,
      d => d.yearInt
    ),
    ([purpose, yearMap]) => [purpose, Array.from(yearMap, ([year, amount]) => ({ year, amount }))]
  )
)
)}

function _allPurposes(aiddataByPurposes){return(
Array.from(aiddataByPurposes.keys())
)}

function _yearRanges(d3){return(
d3.range(1973, 2014)
)}

function _purposeData(allPurposes,aiddataByPurposes,yearRanges){return(
allPurposes.map((purpose, i) => {

  const donateAmounts = aiddataByPurposes.get(purpose) || [];
  const completeDonate = yearRanges.map(year => {
    const record = donateAmounts.find(d => d.year === year);
    return record ? record : { year, amount: 0 };
  });
  const total = completeDonate.reduce((acc, cur) => acc + cur.amount, 0);

  return {
    purpose,
    total,
    donate: completeDonate
  };
})
)}

function _49(md){return(
md`However, it is important to note that the title mentions this sentence: **if the purpose is "UNSPECIFIED" it should be removed.**

This statement indicates that I need to **remove all unspecified purposes when filtering for purpose**. After the necessary data preprocessing, I can get the top-10 Coalesced Purposes called _top10PurposeData_ and plot the **bar chart** showing the total amount of disbursement across all countries and all time for each purpose.`
)}

function _50(purposeData,d3,width)
{
  const height = 400;
  const margin = ({top: 60, bottom: 25, left: 250, right: 30});

  const data = purposeData
    .filter(d => !d.purpose.toLowerCase().includes("specified"))
    .sort((a, b) => b.total - a.total)
    .slice(0, 10);
  
  const x = d3.scaleLinear()
    .domain([0, d3.max(data, d => d.total)])
    .range([margin.left, width - margin.right]);

  const y = d3.scaleBand()
    .domain(data.map(d => d.purpose))
    .range([margin.top, height - margin.bottom])
    .paddingInner(0.2)
    .paddingOuter(0.3);
  
  // create and select an svg element
  const svg = d3.create('svg')
      .attr('width', width)
      .attr('height', height);

  // Draw the bars
  svg.append('g')
    .selectAll('rect')
    .data(data)
    .join('rect')
      // set attributes for each bar
      .attr('x', x(0)) // each bar starts at the same x position
      .attr('y', d => y(d.purpose)) // pass the name to the y-scale to get y position
      .attr('width', d => x(d.total) - x(0)) // pass the population to the x-scale to get the width
      .attr('height', y.bandwidth()) // get the width of each band in the scale
      .attr('fill', 'steelblue');

  const format = d3.format('~s');
  const xAxis = d3.axisTop(x).tickFormat(format);
  const yAxis = d3.axisLeft(y);
  
  // Draw the y-axis
  svg.append('g')
      // move to the right in order to account for the margin
      .attr('transform', `translate(${margin.left})`)
      // draw the axis
      .call(yAxis)
      // remove the baseline
      .call(g => g.select('.domain').remove());
  
  // Draw the x-axis
  svg.append('g')
      // we have to move it down to the bottom of the vis
      .attr('transform', `translate(0, ${margin.top*1.1})`)
      .call(xAxis)
      .call(g => g.select('.domain').remove())
    // add a label for the x-axis
    .append('text')
      .attr('fill', 'black')
      .attr('font-family', 'sans-serif')
      .attr('x', width / 2)
      .attr('y', -25)
      .text("Amount of Disbursement");

  svg.append("text")
    .attr("x", margin.left)
    .attr("y", 15)
    .text("The amount of donations across all countries and all time (for Vis2-Q1)")
    .attr("fill", "black")
    .attr("font-size", "20px")
    .attr("text-anchor", "center");
  
  return svg.node();
}


function _top10PurposeData(purposeData){return(
purposeData.filter(d => d.purpose !== 'Sectors not specified')
  .sort((a, b) => b.total - a.total)
  .slice(0, 10)
)}

function _52(md){return(
md`### Q2 (10 points) 

What are the top 10 purposes of disbursements (in terms of total amount of disbursement) and how does their relative amount compare over time? E.g., are there purposes that tend to be prominent for a period of time and others that become more prominent during other periods?

**Answer:** **The top-10 purposes of disbursements are as follows** (shown in Q1):

1. Air transport
2. Rail transport
3. Industrial development
4. Power generation/non-renewable sources
5. RESCHEDULING AND REFINANCING
6. Import support (capital goods)
7. Social/ welfare services
8. Telecommunications
9. Power generation/renewable sources
10. Mineral/Metal prospection and exploration

In addition, the relative number of top-10 purposes has changed over time, and **the process of change is as follows:**

- "Air transport" dominates the amount around 1980.
- "Social/ welfare services" are donated more in 1988-1990.
- "Social/ welfare services" and "Power generation/renewable sources" dominate disbursement amount around 1992.
- In the period 1994 and 2000, "Air transport" amount became more.
- "Rail transport" is more donated around 2010.
- In other periods, no single purpose is dominant.

Based on Q1, I got the data _top10Purposes_. `
)}

function _unspecifiedPurpose(purposeData){return(
purposeData
  .filter(d => d.purpose.toLowerCase().includes("specified"))
  .map(d => d.purpose)
)}

function _top10Purposes(purposeData){return(
purposeData
  .filter(d => !d.purpose.toLowerCase().includes("specified"))
  .sort((a, b) => b.total - a.total)
  .slice(0, 10)
  .map(d => d.purpose)
)}

function _55(md){return(
md`For this problem, I use _purposeData_ to take out the data of top-10 purposes, which indicates the trade amount of purpose from 1973 to 2013. I plot a **line chart** to show the change in transportation amount for different purposes in different years.`
)}

function _56(Swatches,d3,top10Purposes){return(
Swatches(d3.scaleOrdinal(top10Purposes, d3.schemeTableau10), {
  columns: "180px"
})
)}

function _57(width,d3,top10PurposeData,yearRanges)
{
  const svgWidth = width;
  const svgHeight = 400;
  const margin = ({top: 40, bottom: 20, left: 40, right: 20});
  
  const svg = d3.create('svg')
      .attr('width', svgWidth)
      .attr('height', svgHeight);

  const maxAmount = d3.max(top10PurposeData, d => d3.max(d.donate, r => r.amount));

  const x = d3.scaleBand()
      .domain(yearRanges)
      .range([margin.left, svgWidth-margin.right]);
  const y = d3.scaleLinear()
      .domain([0, maxAmount])
      .nice()
      .range([svgHeight-margin.bottom, margin.top]);

  const xAxis = d3.axisBottom(x)
      .tickValues(yearRanges.filter((d, i) => i % 5 === 0))
      .tickFormat(d => d);
  const yAxis = d3.axisLeft(y)
      .tickFormat(d3.format(".2s"));

  const line = d3.line()
      .x(d => x(d.year))
      .y(d => y(d.amount));
  
  svg.append('g')
      // move x-axis to the bottom 
      .attr('transform', `translate(-10, ${svgHeight - margin.bottom})`)
      .call(xAxis);

  svg.append('g')
      .attr('transform', `translate(${margin.left})`)
      .call(yAxis)
      .call(g => g.select('.domain').remove())
      .call(g => g.selectAll(".tick line").clone()
          .attr("x2", svgWidth - margin.left - margin.right)
          .attr("stroke-opacity", 0.1))
    // add axis label
      .append('text')
        .attr('fill', 'black')
        .attr('text-anchor', 'start')
        .attr('dominant-baseline', 'hanging')
        .attr('font-weight', 'bold')
        .attr('y', 10)
        .attr('x', -margin.left)
        .text('Amount');

  const color = d3.scaleOrdinal(d3.schemeCategory10)
      .domain(top10PurposeData.map(d => d.purpose));

  top10PurposeData.forEach(p => {
    svg.append("path")
       .datum(p.donate)
       .attr("fill", "none")
       .attr("stroke", color(p.purpose))
       .attr("stroke-width", 1.5)
       .attr("d", line);
  });

  svg.append("text")
    .attr("x", svgWidth/4)
    .attr("y", 20)
    .text("The amount of donation for each purpose (for Vis2-Q2)")
    .attr("fill", "black")
    .attr("font-size", "20px")
    .attr("text-anchor", "start");
  
  return svg.node();
}


function _58(md){return(
md`Based on this line chart, I can see which purposes used to dominate in donations in a particular year:

- "Air transport" dominates the amount around 1980.
- "Social/ welfare services" are donated more in 1988-1990.
- "Social/ welfare services" and "Power generation/renewable sources" dominate disbursement amount around 1992.
- In the period 1994 and 2000, "Air transport" amount became more.
- "Rail transport" is more donated around 2010.
- In other periods, no single purpose is dominant.`
)}

function _59(md){return(
md`### Q3 (20 points)

Does the allocation of funds for different donation purposes exhibit cyclical patterns, such as recurring peaks or troughs every few years?

**Answer:** **Yes, there are some donation purposes whose allocation of funds exhibit cyclical patterns, such as "Air transport", "Power generation/renewable sources" and etc.**

For this question, I use the _top10PurposeData_ obtained in Q1 and Q2 and I use it to plot a chart where each sub-chart represents the allocation of funds of the top-10 purposes in different years. Based on the chart, we can see that there are some donation purposes that show a cyclical pattern in the allocation of funds. 

Based on the chart, we can see that there are some donation purposes that show a cyclical pattern in the allocation of funds. For example, when we look at the allocation of funds for **"Air transport" (which is the sub-chart in the first row and the first column)**, we can see that this purpose will be at its peak every 5-8 years. Specifically, it peaks in 1980, 1993, and 1999. In addition, the allocation of **"Power generation/renewable sources" (which is the sub-chart in the third row and the first column)** is on a 2-3 year cycle.

Of course, not all of the donation purposes show a cyclical allocation of funds. I take "Import support (capital goods)" (sub-chart in the second row and the second column) as an example. This purpose only got a peak around 1991, while the amount of disbursement is relatively low at other times.`
)}

function _60(d3,width,top10PurposeData,yearRanges)
{
  const height = 400;
  const margin = ({top: 40, bottom: 20, left: 40, right: 20});

  const rows = 3;
  const cols = 4;

  const row = d3.scaleBand()
    .domain(d3.range(rows))
    .range([0, height])
    .paddingInner(0.2);
  const col = d3.scaleBand()
    .domain(d3.range(cols))
    .range([0, width])
    .paddingInner(0.2);

  const grid = d3.cross(d3.range(rows), d3.range(cols), (row, col) => ({ row, col }));

  const data = top10PurposeData.map((d, i) => ({
    ...d,
    row: grid[i].row,
    col: grid[i].col
  }));

  const dataToScaleAndArea = Object.fromEntries(
    data.map(d => {

      let maxAmount = d3.max(d.donate, d => d.amount);
      
      if (maxAmount == 0) maxAmount = 100000;
      
      const y = d3.scaleLinear()
          .domain([0, maxAmount])
          .range([row.bandwidth(), 0]);
      
      const area = d3.area()
        .x(d => x(d.year))
        .y1(d => y(d.amount))
        .y0(d => y(0));
  
      return [d.purpose, {y, area}];
    })
  );
  
  const x = d3.scaleBand()
    .domain(yearRanges)
    .range([0, col.bandwidth()]);
  
  // create and select an svg element that is the size of the bars plus margins 
  const svg = d3.create('svg')
      .attr('width', width + margin.left + margin.right)
      .attr('height', height + margin.top + margin.bottom);
  
  // append a group element and move it left and down to create space
  // for the left and top margins
  const g = svg.append("g")
      .attr('transform', `translate(${margin.left}, ${margin.top})`);
  
  // create a group for each small multiple
  const cells = g.append('g')
    .selectAll('g')
    .data(data)
    .join('g')
      .attr('class', 'cell')
      .attr('transform', d => `translate(${col(d.col)}, ${row(d.row)})`);
  
  // add the area to each cell
  
  cells.append('path')
      // access the area generator for this industry
      .attr('d', d => dataToScaleAndArea[d.purpose].area(d.donate))
      .attr('fill', 'steelblue');
  
  // add the y axis for each cell
  cells.each(function(d) {
    // select the group for this cell
    const group = d3.select(this);

    // get the y-scale for this industry
    const yAxis = d3.axisLeft(dataToScaleAndArea[d.purpose].y)
        .ticks(3)
        .tickSizeOuter(0)
        .tickFormat(d3.format("~s"));
    
    group.call(yAxis)
        .call(g => g.select('.domain'));
  });

  const xAxis = d3.axisBottom(x)
      .tickValues(yearRanges.filter((d, i) => i % 5 === 0))
      .tickSizeOuter(0);

  cells.append('g')
      // move it to the bottom
      .attr('transform', d => `translate(0,${row.bandwidth()})`)
      .call(xAxis)
      // remove the baseline
      .call(g => g.select('.domain'))
      .selectAll("text")
      .style("font-size", "8px");

  cells.append("text")
    .attr("x", 10)
    .attr("y", 10)
    .text(d => d.purpose)
    .attr("fill", "black")
    .attr("font-size", "10px")
    .attr("text-anchor", "start");

  svg.append("text")
    .attr("x", width/3)
    .attr("y", 15)
    .text("The amount of donation for each purpose (for Vis2-Q3)")
    .attr("fill", "black")
    .attr("font-size", "20px")
    .attr("text-anchor", "start");
  
  return svg.node();
}


function _61(md){return(
md`As a result, there are some donation purposes whose allocation of funds exhibit cyclical patterns.`
)}

function _62(md){return(
md`## Visualization 3`
)}

function _63(md){return(
md`### Q1 

Focusing exclusively on countries that receive donations, how do donations shift geographically over time?

**Answer:** **The process of changing the receipt amount for different regions is shown below:**

1. India is always the country with the highest amount of receipts.
2. In 1978-1982, the donations amount shifted to Canada (the color of Canada became redder) to some extent.
3. In 1983-1987, the amount of receipts in countries other than India is decreasing slightly, especially in North America.
4. In 1988-1992, the donations amount shifted to Europe, especially to Poland.
5. In 1993-1997, the donations amount from India decreased and shifted to Southeast Asia (e.g. Thailand) and South America (e.g. Brazil).
6. After 1998, the amount of donations per country starts to decrease.
7. Since 2003, the donations amount has shifted to India.

For this problem, I processed _aiddataByRecipients_ (obtained in Vis1-Q1) to get the data _recipientData_, representing the amount of receipts for each country in different time ranges.`
)}

function _recipientData(aiddataByRecipients,sortedYearRanges)
{
  let data = {};

  let countryNameMapping = {
    "United States": "United States of America",
    "Korea": "South Korea",
    "Slovak Republic": "Slovakia",
    "Czech Republic": "Czechia",
  };

  aiddataByRecipients.forEach((records, country) => {
    let geo = country;
    if (countryNameMapping[country]) geo = countryNameMapping[country];
    let obj = {
      country: country,
      geoName: geo
    }
    
    sortedYearRanges.forEach(yearRange => {
      const rec = records.find(d => d.yearRange === yearRange);
      obj[yearRange] = rec ? rec.amount : 0;
    });
    data[geo] = obj;
  });

  return data;
}


function _65(md){return(
md`In this problem, I used _recipientData_ to **draw a chart that show how the amount of donations for each country has changed over time. In this chart, I plotted several world maps, each representing the amount of donations received in a different time period.** In the map, countries that receive more money are colored redder.`
)}

function _colorScale(d3,aiddataByRecipients){return(
d3.scaleSequential()
  .domain([0, d3.max(Array.from(aiddataByRecipients.values()).flat(), d => d.amount)])
  .interpolator(d3.interpolateRgb("#ffeeee", "#ff0000"))
)}

function _67(Legend,colorScale){return(
Legend(colorScale, {
  title: "Received Amount (USD)",
  tickFormat: "+s"
})
)}

function _68(htl){return(
htl.html`<p style="text-align: center;">The process of of receipts change for each country over time(for Vis3-Q1,Q2,Q3)</p>`
)}

function _69(sortedYearRanges,d3,geoJSON,recipientData,colorScale)
{
  const smallWidth = 200;
  const smallHeight = 200;

  const maps = sortedYearRanges.map(timePeriod => {
    const svg = d3.create('svg')
      .attr('width', smallWidth)
      .attr('height', smallHeight);
    const projection = d3.geoMercator().fitSize([smallWidth, smallHeight], geoJSON);
    const path = d3.geoPath().projection(projection);

    svg.selectAll('path')
      .data(geoJSON.features)
      .join('path')
        .attr('class', 'country')
        .attr('d', path)
        .attr('stroke', 'white')
        .attr('stroke-width', 0.5)
        .attr('fill', d => {
          const countryName = d.properties.NAME;
          if (!recipientData[countryName]) return '#ccc';
          const record = recipientData[countryName][String(timePeriod)];
          if (record === undefined) return '#ccc';
          return colorScale(record);
        })
        .append("title")
        .text(d => {
          const country = d.properties.NAME;
          return `${country}`;
        });

    svg.append("text")
      .attr("x", 5)
      .attr("y", 15)
      .attr("fill", "black")
      .attr("font-size", "12px")
      .text(timePeriod);

    return svg.node();
  });

  const container = d3.create("div")
    .style("display", "grid")
    .style("grid-template-columns", "repeat(4, 1fr)")
    .style("gap", "1px");

  maps.forEach(mapSvg => {
    container.append(() => mapSvg);
  });

  return container.node();
}


function _70(md){return(
md`Through this series of maps over time, I can see how do donations shift geographically over time:

1. India is always the country with the highest amount of receipts.
2. In 1978-1982, the donations amount shifted to Canada (the color of Canada became redder) to some extent.
3. In 1983-1987, the amount of receipts in countries other than India is decreasing slightly, especially in North America.
4. In 1988-1992, the donations amount shifted to Europe, especially to Poland.
5. In 1993-1997, the donations amount from India decreased and shifted to Southeast Asia (e.g. Thailand) and South America (e.g. Brazil).
6. After 1998, the amount of donations per country starts to decrease.
7. Since 2003, the donations amount has shifted to India.`
)}

function _71(md){return(
md`### Q2 

Do donations tend to be always in the same regions of the world over the years or they have been shifting over time?

**Answer: Donations tend to shift over time.**

In Vis3-Q1, **I plotted a series of maps of the amount of money received by each country at different times**. From these maps I can see these things:

- In 1978-1982 donations shifted to North America (e.g. Canada)
- In 1988-1992, donations shifted to Europe (e.g. Poland)
- In 1993-1997, donations shifted to Southeast Asia (e.g. Thailand) and South America (e.g. Brazil)
- After 2003, donations shifted to South Asia (e.g., India).

As a result, the amount of donations tends to shift over time.`
)}

function _72(md){return(
md`### Q3

Can you build a visualization that shows the "history of donations" so that one can get a sense of which regions of the world have had more need for donations over the years?

Answer: Yes, **I use the chart drawn in Vis3-Q1 to show history of donations**, which shows the amount of money received by different regions at different times. According to this chart, **there is a greater need for donations in South Asia (e.g. India), South East Asia (e.g. Thailand), South America (e.g. Brazil) and Europe (e.g. Poland)**.`
)}

function _73(Legend,colorScale){return(
Legend(colorScale, {
  title: "Donations Amount (USD)",
  tickFormat: "+s"
})
)}

function _74(htl){return(
htl.html`<p style="text-align: center;">History of donations</p>`
)}

function _75(sortedYearRanges,d3,geoJSON,recipientData,colorScale)
{
  const smallWidth = 200;
  const smallHeight = 200;

  const maps = sortedYearRanges.map(timePeriod => {
    const svg = d3.create('svg')
      .attr('width', smallWidth)
      .attr('height', smallHeight);
    const projection = d3.geoMercator().fitSize([smallWidth, smallHeight], geoJSON);
    const path = d3.geoPath().projection(projection);

    svg.selectAll('path')
      .data(geoJSON.features)
      .join('path')
        .attr('class', 'country')
        .attr('d', path)
        .attr('stroke', 'white')
        .attr('stroke-width', 0.5)
        .attr('fill', d => {
          const countryName = d.properties.NAME;
          if (!recipientData[countryName]) return '#ccc';
          const record = recipientData[countryName][String(timePeriod)];
          if (record === undefined) return '#ccc';
          return colorScale(record);
        })
        .append("title")
        .text(d => {
          const country = d.properties.NAME;
          return `${country}`;
        });

    svg.append("text")
      .attr("x", 5)
      .attr("y", 15)
      .attr("fill", "black")
      .attr("font-size", "12px")
      .text(timePeriod);

    return svg.node();
  });

  const container = d3.create("div")
    .style("display", "grid")
    .style("grid-template-columns", "repeat(4, 1fr)")
    .style("gap", "1px");

  maps.forEach(mapSvg => {
    container.append(() => mapSvg);
  });

  return container.node();
}


function _76(md){return(
md`-----------------
## Appendix`
)}

function _d3(require){return(
require('d3@7')
)}

function _googleSheetCsvUrl(){return(
'https://docs.google.com/spreadsheets/d/1YiuHdfZv_JZ-igOemKJMRaU8dkucfmHxOP6Od3FraW8/gviz/tq?tqx=out:csv'
)}

export default function define(runtime, observer) {
  const main = runtime.module();
  function toString() { return this.url; }
  const fileAttachments = new Map([
    ["countries-50m.json", {url: new URL("./files/55260abbc777c0a3b8fed19f3929dd822fef9d5118b53b76b2176d20782910e599eac919999ea8ee85a60b783fd37082574f6591fd46c0d70ddf9b00df71ce27.json", import.meta.url), mimeType: "application/json", toString}]
  ]);
  main.builtin("FileAttachment", runtime.fileAttachments(name => fileAttachments.get(name)));
  main.variable(observer()).define(["md"], _1);
  main.variable(observer()).define(["md"], _2);
  main.variable(observer()).define(["Inputs","aiddata"], _3);
  main.variable(observer("aiddata")).define("aiddata", ["d3","googleSheetCsvUrl"], _aiddata);
  main.variable(observer()).define(["md"], _5);
  main.variable(observer("geoJSON")).define("geoJSON", ["FileAttachment"], _geoJSON);
  main.variable(observer()).define(["md"], _7);
  main.variable(observer()).define(["md"], _8);
  main.variable(observer()).define(["md"], _9);
  const child1 = runtime.module(define1);
  main.import("legend", child1);
  main.import("swatches", child1);
  main.import("Legend", child1);
  main.import("Swatches", child1);
  main.variable(observer()).define(["md"], _11);
  main.variable(observer()).define(["width"], _12);
  main.variable(observer()).define(["md"], _13);
  main.variable(observer()).define(["md"], _14);
  main.variable(observer("height")).define("height", _height);
  main.variable(observer("rows")).define("rows", _rows);
  main.variable(observer("cols")).define("cols", _cols);
  main.variable(observer("row")).define("row", ["d3","rows","height"], _row);
  main.variable(observer("col")).define("col", ["d3","cols","width"], _col);
  main.variable(observer("grid")).define("grid", ["d3","rows","cols"], _grid);
  main.variable(observer()).define(["md"], _21);
  main.variable(observer()).define(["md"], _22);
  main.variable(observer("aiddataByDonors")).define("aiddataByDonors", ["d3","aiddata"], _aiddataByDonors);
  main.variable(observer("aiddataByRecipients")).define("aiddataByRecipients", ["d3","aiddata"], _aiddataByRecipients);
  main.variable(observer("sortedYearRanges")).define("sortedYearRanges", ["aiddataByDonors"], _sortedYearRanges);
  main.variable(observer("allCountries")).define("allCountries", ["aiddataByDonors","aiddataByRecipients"], _allCountries);
  main.variable(observer("countryData")).define("countryData", ["allCountries","aiddataByDonors","sortedYearRanges","aiddataByRecipients","d3","grid"], _countryData);
  main.variable(observer()).define(["md"], _28);
  main.variable(observer()).define(["Swatches","d3"], _29);
  main.variable(observer()).define(["d3","sortedYearRanges","col","width","height","countryData","row"], _30);
  main.variable(observer()).define(["md"], _31);
  main.variable(observer()).define(["md"], _32);
  main.variable(observer()).define(["countryData"], _33);
  main.variable(observer()).define(["countryData","d3","width"], _34);
  main.variable(observer()).define(["md"], _35);
  main.variable(observer()).define(["d3","countryData"], _36);
  main.variable(observer()).define(["d3","countryData"], _37);
  main.variable(observer()).define(["d3","countryData"], _38);
  main.variable(observer()).define(["md"], _39);
  main.variable(observer()).define(["d3","sortedYearRanges","col","width","height","countryData","row"], _40);
  main.variable(observer()).define(["md"], _41);
  main.variable(observer()).define(["md"], _42);
  main.variable(observer()).define(["md"], _43);
  main.variable(observer()).define(["md"], _44);
  main.variable(observer("aiddataByPurposes")).define("aiddataByPurposes", ["d3","aiddata"], _aiddataByPurposes);
  main.variable(observer("allPurposes")).define("allPurposes", ["aiddataByPurposes"], _allPurposes);
  main.variable(observer("yearRanges")).define("yearRanges", ["d3"], _yearRanges);
  main.variable(observer("purposeData")).define("purposeData", ["allPurposes","aiddataByPurposes","yearRanges"], _purposeData);
  main.variable(observer()).define(["md"], _49);
  main.variable(observer()).define(["purposeData","d3","width"], _50);
  main.variable(observer("top10PurposeData")).define("top10PurposeData", ["purposeData"], _top10PurposeData);
  main.variable(observer()).define(["md"], _52);
  main.variable(observer("unspecifiedPurpose")).define("unspecifiedPurpose", ["purposeData"], _unspecifiedPurpose);
  main.variable(observer("top10Purposes")).define("top10Purposes", ["purposeData"], _top10Purposes);
  main.variable(observer()).define(["md"], _55);
  main.variable(observer()).define(["Swatches","d3","top10Purposes"], _56);
  main.variable(observer()).define(["width","d3","top10PurposeData","yearRanges"], _57);
  main.variable(observer()).define(["md"], _58);
  main.variable(observer()).define(["md"], _59);
  main.variable(observer()).define(["d3","width","top10PurposeData","yearRanges"], _60);
  main.variable(observer()).define(["md"], _61);
  main.variable(observer()).define(["md"], _62);
  main.variable(observer()).define(["md"], _63);
  main.variable(observer("recipientData")).define("recipientData", ["aiddataByRecipients","sortedYearRanges"], _recipientData);
  main.variable(observer()).define(["md"], _65);
  main.variable(observer("colorScale")).define("colorScale", ["d3","aiddataByRecipients"], _colorScale);
  main.variable(observer()).define(["Legend","colorScale"], _67);
  main.variable(observer()).define(["htl"], _68);
  main.variable(observer()).define(["sortedYearRanges","d3","geoJSON","recipientData","colorScale"], _69);
  main.variable(observer()).define(["md"], _70);
  main.variable(observer()).define(["md"], _71);
  main.variable(observer()).define(["md"], _72);
  main.variable(observer()).define(["Legend","colorScale"], _73);
  main.variable(observer()).define(["htl"], _74);
  main.variable(observer()).define(["sortedYearRanges","d3","geoJSON","recipientData","colorScale"], _75);
  main.variable(observer()).define(["md"], _76);
  main.variable(observer("d3")).define("d3", ["require"], _d3);
  main.variable(observer("googleSheetCsvUrl")).define("googleSheetCsvUrl", _googleSheetCsvUrl);
  return main;
}
