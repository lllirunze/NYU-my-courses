import define1 from "./a33468b95d0b15b0@817.js";

function _1(md){return(
md`# Mini-Project 1 (Geo) - S25`
)}

function _2(md){return(
md`## Data

Here we load a [simplified and reduced version](https://drive.google.com/file/d/1m3fw2Pq2fDOp7A-1JUGtc4D2IeXCwHvI/view?usp=sharing) of a dataset pulled from the [UN Comtrade Database](https://comtradeplus.un.org/). 

You are free to change this code as you wish. If you don't want to preprocess your data on Observable, then you can do the preprocessing using whatever languages or tools you'd like and then [upload](/@observablehq/file-attachments) your preprocessed data to Observable. If you take this approach, then you should delete the \`tradedata\` cell below so that you're not loading unnecessary data.

The dataset contains the following columns:
- **Year**: Year of the transaction as an integer
- **Reporter**: The country who reported the transaction
- **ImportOrExport**: Whether the transaction was imported to or exported from the reporter 
- **Partner**: The other country involved in the transaction
- **Description**: The type of goods being imported/exported
- **Value_USD**: The value of the goods imported/exported in USD`
)}

function _3(Inputs,tradedata){return(
Inputs.table(tradedata)
)}

async function _tradedata(d3,googleSheetCsvUrl)
{
  const data = await d3.csv(googleSheetCsvUrl, row => ({
    Year:(row.Year),
    Reporter: row.Reporter,
    ImportOrExport: row.ImportOrExport,
    Partner: row.Partner,
    Description: row.Description,
    Value_USD: row.Value_USD,
  }));
  
  data.columns = Object.keys(data[0]);
  
  return data;
}


function _5(md){return(
md`Next we load GeoJSON data for countries. This file is derived from data from [Natural Earth](https://www.naturalearthdata.com).`
)}

function _geoJSON(FileAttachment){return(
FileAttachment("countries-50m.json").json()
)}

function _7(md){return(
md`## Questions

Your goal is to create 3 independent visualizations of the same data set, each one with the intent of answering the questions stated below. For each numbered visualization, you should be able to create a data visualization that answers **all** of the questions specified. These are the 3 visualizations you should create:

- **Visualization 1:** 

  Q1) Which countries import more goods than they export? Which countries export more goods than they import? **(20 points)** 

  Q2) Are the biggest importers all clustered in one area, or are they distributed across the world? What about the biggest exporters? **(10 points)**

  Q3) Are there neighboring countries that have radically different patterns in terms of how much they import vs. how much they export?  **(10 points)**

  Aesthetics and Clarity **(10 points)**

- **Visualization 2:** 

  Q1) Does each country tend to trade with nearby countries, or do they tend to trade with countries that are father away? **(20 points)**

  Q2) Does this pattern differ for imports versus exports? (That is, if a country primarily imports goods from its neighbors, does it also primarily export goods to its neighbors? Or worldwide?) **(20 points)**

  Aesthetics and Clarity: **(10 points)**


- **[OPTIONAL / EXTRA POINTS] Visualization 3:** 

  Q1) What are the top 5 types of traded goods (imports or exports)? Which countries are the primary exporters of these goods? Are they all in the same geographic region, or are they distributed around the world? **(15 points)**

  Q2) Are there countries that tend to receive more of certain types of goods than others? (Note: it would be more interesting to look at the top 5 types of goods locally, for each individual country, but visualizing the results may be even harder. If you want to try out a solution for this harder case it would be nice to see it). **(15 points)**

### For each visualization add a description of your thought process and why you think your solution is *appropriate* and *effective*.


Note it is okay to submit more than one solution for a given visualization problem if you think there are some competing solutions that work well. When you do that, make sure to compare the solutions by commenting on their advantages and disadvantages.
`
)}

function _8(md){return(
md`### Remember

The questions above are a very useful tool for you to verify whether you are producing a good solution or not. As you go about solving this exercise you can use the questions above as an evaluation tool in two main ways:
1. Verify that you can indeed answer the questions with your visualization. If you can’t fully answer the questions, it means your solution has some problems.
2. Compare multiple solutions to the same problem and ask yourself: “which one makes it easier for me to answer these questions?”, where easier may mean, more accurately, with less effort or faster.
`
)}

function _9(md){return(
md`## Instructions
- Your coded solutions must use D3. Other visualization libraries are not allowed.
- You should feel free to process and transform the data any way you deem relevant and use any tool you prefer for data processing. Data transformation does not necessarily have to be in JavaScript nor within Observable. It’s ok to pre-process the data and then load it in Observable if you prefer.
- You can use Mike Bostock's [Color Legend](/@d3/color-legend) notebook to create your legends.`
)}

function _11(md){return(
md`## Grading Criteria

The main parameters we will use for grading are the following:

- Does the information extracted answer the questions posed in the exercise?
- Does the visualization answer the questions posed in the exercise?
- Is the visual representation clear? Does it have good aesthetics?
  - Review this [notebook on clarity](/@nyuinfovis/contextual-elements-aesthetics-and-clarity?collection=@nyuinfovis/guides-and-examples) for reference.`
)}

function _12(md){return(
md`## Solutions`
)}

function _13(width){return(
width
)}

function _14(md){return(
md`## Visualization 1`
)}

function _15(md){return(
md`In the first part of Vis1, we need to process the dataset first to get the _countryTrade_ array, which represents the **imports, exports, and the difference (the value of exports minus imports)** for each country or region.`
)}

function _countryTrade(tradedata)
{
  let countryTrade = {};

  let countryNameMapping = {
    "USA": "United States of America",
    "Rep. of Korea": "South Korea",
    "Other Asia, nes": "Taiwan",
    "China, Hong Kong SAR": "Hong Kong",
    "Russian Federation": "Russia",
    "China, Macao SAR": "Macao",
    "Türkiye": "Turkey",
    "Viet Nam": "Vietnam",
    "Brunei Darussalam": "Brunei",
    "Sudan (...2011)": "S. Sudan",
    "Côte d'Ivoire": "CÃ´te d'Ivoire",
    "Bolivia (Plurinational State of)": "Bolivia",
    "State of Palestine": "Palestine",
    "United Rep. of Tanzania": "Tanzania",
    "Dem. Rep. of the Congo": "Dem. Rep. Congo",
    "Lao People's Dem. Rep.": "Laos",
    "North Macedonia": "Macedonia",
  };

  tradedata.forEach(d => {
    let country = d.Reporter;
    if (countryNameMapping[country]) country = countryNameMapping[country];
    
    const value = parseFloat(d.Value_USD);

    if (!countryTrade[country]) {
      countryTrade[country] = {
        country: "",
        geoName: "",
        import: 0,
        export: 0,
        diff: 0
      };
    }

    countryTrade[country].country = d.Reporter;
    countryTrade[country].geoName = country;
    if (d.ImportOrExport === 'Import') {countryTrade[country].import += value; countryTrade[country].diff -= value;}
    else {countryTrade[country].export += value; countryTrade[country].diff += value;}
  });
  
  return countryTrade;
}


function _extent(d3,countryTrade){return(
d3.extent(Object.values(countryTrade).map(d => d.diff))
)}

function _18(md){return(
md`### Q1 (20 points)`
)}

function _19(md){return(
md`(1) Which countries import more goods than they export?   

**Answer:** We draw a map from _countryTrade_ to answer this question Vis1-Q1.

The map represents **the difference between imports and exports (value of exports minus value of imports)** for each country and region. In the map, **Blue** indicates that import of the country is more than export, while **Red** indicates more exports.`
)}

function _20(Legend,d3){return(
Legend(d3.scaleSqrt().domain([-25000000000000, 0, 5000000000000]).range(["blue", "white", "red"]), {
  title: "Trade Difference (USD)",
  tickFormat: "+s"
})
)}

function _21(width,d3,geoJSON,countryTrade)
{
  const height = width;
  
  const svg = d3.create('svg')
    .attr('width', width/2)
    .attr('height', height/2);

  const projection = d3.geoMercator()
    .scale(80)
    .translate([width/4, height/4]);

  const path = d3.geoPath().projection(projection);

  const colorScale = d3.scaleSqrt()
  .domain([-25000000000000, 0, 5000000000000])
  .range(["blue", "white", "red"]);

  svg.selectAll('path')
    .data(geoJSON.features)
    .join('path')
    .attr('d', path)
    .attr('fill', d => {
        const country = d.properties.NAME;
        const trade = countryTrade[country];
        if (!trade) return '#ccc';
        else return colorScale(trade.diff);
    })
    .attr('stroke', 'white')
    .attr('stroke-width', 0.5)
    .append("title")
    .text(d => {
      const country = d.properties.NAME;
      const tradeData = countryTrade[country];
      return `${country}:\nImport ${tradeData ? tradeData.import : 'N/A'} USD\nExport ${tradeData ? tradeData.export : 'N/A'} USD`;
    });

  svg.append("text")
    .attr("x", width / 4)
    .attr("y", 20)
    .attr("text-anchor", "middle")
    .text("Trade Difference (for Vis1-Q1)");

  return svg.node();
}


function _22(md){return(
md`As a result, according to _countryTrade_ and this map, countries with more imports can be identified by checking if \`diff\` is less than 0 (marked as Blue). In the first map, these countries are marked in blue. **USA, Italy, United Kingdom and etc.** are the countries which import more goods than they export. **The list of countries is shown in the following array _countriesWithMoreImports_.**`
)}

function _countriesWithMoreImports(countryTrade){return(
Object.values(countryTrade)
  .filter(d => d.diff < 0)
  .map(d => d.country)
)}

function _24(md){return(
md`(2) Which countries export more goods than they import?   

**Answer:** According to _countryTrade_ and this map, countries with more imports can be identified by checking if \`diff\` is greater than 0 (marked as Red). In the first map, these countries are marked in red. **Germany, Iran, China and etc.** are the countries which export more goods than they import. **The list of countries is shown in the following array _countriesWithMoreExports_.**`
)}

function _countriesWithMoreExports(countryTrade){return(
Object.values(countryTrade)
  .filter(d => d.diff > 0)
  .map(d => d.country)
)}

function _26(md){return(
md`### Q2 (10 points)`
)}

function _27(md){return(
md`(1) Are the biggest importers all clustered in one area, or are they distributed across the world?

**Answer:** The biggest importers are **distributed across the world.**

For this question, I use the _import_ attribute in the _countryTrade_ array to draw the map. Where countries with more imports are shown on the map in a brighter blue color.

In addition, I have selected the **10 countries with the largest imports**: the United States, China, Germany, etc. (as shown in the array _topImporters_). I marked these countries with **blue circles** in the map to determine whether they are clustered in a certain region or spread around the world.

With the blue circles in the map, we can see that the biggest importers are distributed across the world.`
)}

function _topImporters(countryTrade){return(
Object.values(countryTrade)
    .sort((a, b) => b.import - a.import)
    .slice(0, 10)
    .map(d => d.geoName)
)}

function _29(Legend,d3,countryTrade){return(
Legend(d3.scaleSequentialSqrt(d3.extent(Object.values(countryTrade).map(d => d.import)), d3.interpolateBlues), {
  title: "Import (USD)",
  tickFormat: "+s"
})
)}

function _30(width,d3,topImporters,geoJSON,countryTrade)
{
  const height = width;
  
  const svg = d3.create('svg')
    .attr('width', width/2)
    .attr('height', height/2);

  const projection = d3.geoMercator()
    .scale(80)
    .translate([width/4, height/4]);

  const path = d3.geoPath().projection(projection);

  const importerCoordinates = topImporters.map(country => {
    const feature = geoJSON.features.find(f => f.properties.NAME === country);
    const centroid = d3.geoCentroid(feature);
    return centroid;
  });

  const colorScale = d3.scaleSequentialSqrt()
    .domain(d3.extent(Object.values(countryTrade).map(d => d.import)))
    .interpolator(d3.interpolateBlues);

  svg.selectAll('path')
    .data(geoJSON.features)
    .join('path')
    .attr('d', path)
    .attr('fill', d => {
        const country = d.properties.NAME;
        const trade = countryTrade[country];
        if (!trade) return '#ccc';
        else return colorScale(trade.import);
    })
    .attr('stroke', 'white')
    .attr('stroke-width', 0.5)
    .append("title")
    .text(d => {
      const country = d.properties.NAME;
      const tradeData = countryTrade[country];
      return `${country}: ${tradeData ? tradeData.import : 'N/A'} USD`
    });

  svg.selectAll("circle")
    .data(importerCoordinates)
    .join("circle")
    .attr("cx", d => projection(d)[0])
    .attr("cy", d => projection(d)[1])
    .attr("r", 20)
    .attr("fill", "blue")
    .attr("stroke", "black")
    .attr("stroke-width", 1)
    .attr("opacity", 0.5);

  svg.append("text")
    .attr("x", width / 4)
    .attr("y", 20)
    .attr("text-anchor", "middle")
    .text("Country imports (for Vis1-Q2(1))");

  return svg.node();
}


function _31(md){return(
md`(2) What about the biggest exporters?

**Answer:** The biggest exporters are **distributed across the world.**

In this question, the method is consistent with the previous part, with the largest exporting countries marked by red circles as shown below. We can find that the biggest exporters are distributed across the world.`
)}

function _topExporters(countryTrade){return(
Object.values(countryTrade)
    .sort((a, b) => b.export - a.export)
    .slice(0, 10)
    .map(d => d.geoName)
)}

function _33(Legend,d3,countryTrade){return(
Legend(d3.scaleSequentialSqrt(d3.extent(Object.values(countryTrade).map(d => d.export)), d3.interpolateReds), {
  title: "Export (USD)",
  tickFormat: "+s"
})
)}

function _34(width,d3,topExporters,geoJSON,countryTrade)
{
  const height = width;
  
  const svg = d3.create('svg')
    .attr('width', width/2)
    .attr('height', height/2);

  const projection = d3.geoMercator()
    .scale(80)
    .translate([width/4, height/4]);

  const path = d3.geoPath().projection(projection);

  const exporterCoordinates = topExporters.map(country => {
    const feature = geoJSON.features.find(f => f.properties.NAME === country);
    const centroid = d3.geoCentroid(feature);
    return centroid;
  });

  const colorScale = d3.scaleSequentialSqrt()
    .domain(d3.extent(Object.values(countryTrade).map(d => d.export)))
    .interpolator(d3.interpolateReds);

  svg.selectAll('path')
    .data(geoJSON.features)
    .join('path')
    .attr('d', path)
    .attr('fill', d => {
        const country = d.properties.NAME;
        const trade = countryTrade[country];
        if (!trade) return '#ccc';
        else return colorScale(trade.export);
    })
    .attr('stroke', 'white')
    .attr('stroke-width', 0.5)
    .append("title")
    .text(d => {
      const country = d.properties.NAME;
      const tradeData = countryTrade[country];
      return `${country}: ${tradeData ? tradeData.export : 'N/A'} USD`
    });

  svg.selectAll("circle")
    .data(exporterCoordinates)
    .join("circle")
    .attr("cx", d => projection(d)[0])
    .attr("cy", d => projection(d)[1])
    .attr("r", 20)
    .attr("fill", "red")
    .attr("stroke", "black")
    .attr("stroke-width", 1)
    .attr("opacity", 0.5);

  svg.append("text")
    .attr("x", width / 4)
    .attr("y", 20)
    .attr("text-anchor", "middle")
    .text("Country Exports (for Vis1-Q2(2))");

  return svg.node();
}


function _35(md){return(
md`### Q3 (10 points)`
)}

function _36(md){return(
md`Are there neighboring countries that have radically different patterns in terms of how much they import vs. how much they export? (10 points)

**Answer:** **Yes**. There are some neighboring countries with different import and export patterns which are evident **in the map plotted in Q1**.

For example, **the United States of America**, located in North America, is colored blue in the map, indicating that it is a country that imports more than it exports, but its two neighbors, **Canada and Mexico**, are both colored red, indicating that they are countries that export more than they import.

In addition, **France (blue) and Germany (red)** in Europe, and **China (red) and India (blue)** in Asia, are neighbors that fit the question.`
)}

function _37(Legend,d3){return(
Legend(d3.scaleSqrt().domain([-25000000000000, 0, 5000000000000]).range(["blue", "white", "red"]), {
  title: "Trade Difference (USD)",
  tickFormat: "+s"
})
)}

function _38(width,d3,geoJSON,countryTrade)
{
  const height = width;
  
  const svg = d3.create('svg')
    .attr('width', width/2)
    .attr('height', height/2);

  const projection = d3.geoMercator()
    .scale(80)
    .translate([width/4, height/4]);

  const path = d3.geoPath().projection(projection);

  const colorScale = d3.scaleSqrt()
  .domain([-25000000000000, 0, 5000000000000])
  .range(["blue", "white", "red"]);

  svg.selectAll('path')
    .data(geoJSON.features)
    .join('path')
    .attr('d', path)
    .attr('fill', d => {
        const country = d.properties.NAME;
        const trade = countryTrade[country];
        if (!trade) return '#ccc';
        else return colorScale(trade.diff);
    })
    .attr('stroke', 'white')
    .attr('stroke-width', 0.5)
    .append("title")
    .text(d => {
      const country = d.properties.NAME;
      const tradeData = countryTrade[country];
      return `${country}:\nImport ${tradeData ? tradeData.import : 'N/A'} USD\nExport ${tradeData ? tradeData.export : 'N/A'} USD`;
    });

  svg.append("text")
    .attr("x", width / 4)
    .attr("y", 20)
    .attr("text-anchor", "middle")
    .text("Trade Difference (same as Vis1-Q1)");

  return svg.node();
}


function _39(md){return(
md`---

## Visualization 2`
)}

function _40(md){return(
md`### Q1 (20 points) `
)}

function _41(md){return(
md`Does each country tend to trade with nearby countries, or do they tend to trade with countries that are father away? 

**Answer:** **Not all countries trade with neighboring countries, and not all countries trade with countries that are father away.** 

In this question, we can give two **counter-examples (France and Brazil)** to illustrate this.`
)}

function _42(md){return(
md`First of all, we take the trade amount of **France** in Europe as an example, we first process the array _tradeDataWithFrance_, which represents the trade amount of France with each country. By drawing the **bar chart** and **map** shown below, we can find that **France mainly trades with Germany, Italy, Belgium and other European countries**, which are all located in Europe and are all relatively close to France.`
)}

function _tradeDataWithFrance(tradedata,d3)
{
  let trade = {};

  let countryNameMapping = {
    "USA": "United States of America",
    "Rep. of Korea": "South Korea",
    "Other Asia, nes": "Taiwan",
    "China, Hong Kong SAR": "Hong Kong",
    "Russian Federation": "Russia",
    "China, Macao SAR": "Macao",
    "Türkiye": "Turkey",
    "Viet Nam": "Vietnam",
    "Brunei Darussalam": "Brunei",
    "Sudan (...2011)": "S. Sudan",
    "Côte d'Ivoire": "CÃ´te d'Ivoire",
    "Bolivia (Plurinational State of)": "Bolivia",
    "State of Palestine": "Palestine",
    "United Rep. of Tanzania": "Tanzania",
    "Dem. Rep. of the Congo": "Dem. Rep. Congo",
    "Lao People's Dem. Rep.": "Laos",
    "North Macedonia": "Macedonia",
  };

  tradedata.forEach(d => {
    if (d.Reporter === 'France') {
      let country = d.Partner;
      if (countryNameMapping[country]) country = countryNameMapping[country];
      const value = parseFloat(d.Value_USD);

      if (!trade[country]) {
        trade[country] = {
          country: "",
          geoName: "",
          importAndExport: 0,
          percent: 0
        };
      }

      trade[country].country = d.Partner;
      trade[country].geoName = country;
      trade[country].importAndExport += value;
    }
  });

  const total = d3.sum(Object.values(trade).map(d => d.importAndExport));
  Object.values(trade).forEach(d => {
    d.percent = (d.importAndExport / total) * 100;
  });

  return trade;
}


function _44(width,tradeDataWithFrance,d3)
{
  const height = width/2;
  const margin = { top: 60, right: 30, bottom: 40, left: 120 };

  const sortedTrade = Object.entries(tradeDataWithFrance)
    .sort((a, b) => b[1].importAndExport - a[1].importAndExport)
    .slice(0, 20)
    .reduce((acc, [key, value]) => {
      acc[key] = value;
      return acc;
    }, {});

  const svg = d3.create('svg')
    .attr('width', width)
    .attr('height', height);

  const x = d3.scaleLinear()
    .domain([0, d3.max(Object.values(sortedTrade), d => d.importAndExport)])
    .range([margin.left, width - margin.right]);

  const y = d3.scaleBand()
    .domain(Object.values(sortedTrade).map(d => d.country))
    .range([margin.top, height - margin.bottom])
    .paddingInner(0.2)
    .paddingOuter(0.5);

  svg.append('g')
    .selectAll('rect')
    .data(Object.values(sortedTrade))
    .join('rect')
      .attr('x', x(0))
      .attr('y', d => y(d.country))
      .attr('width', d => x(d.importAndExport) - x(0))
      .attr('height', y.bandwidth())
      .attr('fill', 'steelblue');

  const xAxis = d3.axisTop(x).tickFormat(d3.format('~s'));
  const yAxis = d3.axisLeft(y);

  svg.append('g')
      .attr('transform', `translate(${margin.left})`)
      .call(yAxis)
      .call(g => g.select('.domain').remove());

  svg.append('g')
      .attr('transform', `translate(0, ${margin.top})`)
      .call(xAxis)
      .call(g => g.select('.domain').remove())
    .append('text')
      .attr('fill', 'black')
      .attr('font-family', 'sans-serif')
      .attr('x', width / 2)
      .attr('y', -30)
      .text("Total Trade Amount of France");

  return svg.node();
}


function _45(Legend,d3,tradeDataWithFrance){return(
Legend(d3.scaleSequentialSqrt([0, d3.max(Object.values(tradeDataWithFrance).map(d => d.importAndExport))], d3.interpolateBlues), {
  title: "Total Trade Amount of France (USD)",
  tickFormat: "+s"
})
)}

function _46(width,d3,tradeDataWithFrance,geoJSON)
{
  const height = width;
  
  const svg = d3.create('svg')
    .attr('width', width/2)
    .attr('height', height/2);

  const projection = d3.geoMercator()
    .scale(80)
    .translate([width/4, height/4]);

  const path = d3.geoPath().projection(projection);

  const colorScale = d3.scaleSequentialSqrt()
    .domain([0, d3.max(Object.values(tradeDataWithFrance).map(d => d.importAndExport))])
    .interpolator(d3.interpolateBlues);

  svg.selectAll('path')
    .data(geoJSON.features)
    .join('path')
    .attr('d', path)
    .attr('fill', d => {
        const country = d.properties.NAME;
        if (country === 'France') return 'black';
        const trade = tradeDataWithFrance[country];
        if (!trade) return '#ccc';
        else return colorScale(trade.importAndExport);
    })
    .attr('stroke', 'white')
    .attr('stroke-width', 0.5)
    .append("title")
    .text(d => {
      const country = d.properties.NAME;
      const tradeData = tradeDataWithFrance[country];
      return `${country}: ${tradeData ? tradeData.importAndExport : '0'} USD`
    });

  svg.append("text")
    .attr("x", width / 4)
    .attr("y", 20)
    .attr("text-anchor", "middle")
    .text("Trade Amount of France with each country (for Vis2-Q1)");

  return svg.node();
}


function _47(md){return(
md`However, not all countries trade with neighboring countries. Here we take **Brazil** in South America as an example. We process the array _tradeDataWithBrazil_ and draw the **bar chart** and **map** shown below, we can see that **Brazil's trade partners are mainly China and the United States**, but these countries are located in Asia and North America, and Brazil are farther away.`
)}

function _tradeDataWithBrazil(tradedata,d3)
{
  
  let trade = {};

  let countryNameMapping = {
    "USA": "United States of America",
    "Rep. of Korea": "South Korea",
    "Other Asia, nes": "Taiwan",
    "China, Hong Kong SAR": "Hong Kong",
    "Russian Federation": "Russia",
    "China, Macao SAR": "Macao",
    "Türkiye": "Turkey",
    "Viet Nam": "Vietnam",
    "Brunei Darussalam": "Brunei",
    "Sudan (...2011)": "S. Sudan",
    "Côte d'Ivoire": "CÃ´te d'Ivoire",
    "Bolivia (Plurinational State of)": "Bolivia",
    "State of Palestine": "Palestine",
    "United Rep. of Tanzania": "Tanzania",
    "Dem. Rep. of the Congo": "Dem. Rep. Congo",
    "Lao People's Dem. Rep.": "Laos",
    "North Macedonia": "Macedonia",
  };

  tradedata.forEach(d => {
    if (d.Reporter === 'Brazil') {
      let country = d.Partner;
      if (countryNameMapping[country]) country = countryNameMapping[country];
      const value = parseFloat(d.Value_USD);

      if (!trade[country]) {
        trade[country] = {
          country: "",
          geoName: "",
          importAndExport: 0,
          percent: 0
        };
      }

      trade[country].country = d.Partner;
      trade[country].geoName = country;
      trade[country].importAndExport += value;
    }
  });

  const total = d3.sum(Object.values(trade).map(d => d.importAndExport));
  Object.values(trade).forEach(d => {
    d.percent = (d.importAndExport / total) * 100;
  });

  return trade;
}


function _49(width,tradeDataWithBrazil,d3)
{
  const height = width/2;
  const margin = { top: 60, right: 30, bottom: 40, left: 120 };

  const sortedTrade = Object.entries(tradeDataWithBrazil)
    .sort((a, b) => b[1].importAndExport - a[1].importAndExport)
    .slice(0, 20)
    .reduce((acc, [key, value]) => {
      acc[key] = value;
      return acc;
    }, {});

  const svg = d3.create('svg')
    .attr('width', width)
    .attr('height', height);

  const x = d3.scaleLinear()
    .domain([0, d3.max(Object.values(sortedTrade), d => d.importAndExport)])
    .range([margin.left, width - margin.right]);

  const y = d3.scaleBand()
    .domain(Object.values(sortedTrade).map(d => d.country))
    .range([margin.top, height - margin.bottom])
    .paddingInner(0.2)
    .paddingOuter(0.5);

  svg.append('g')
    .selectAll('rect')
    .data(Object.values(sortedTrade))
    .join('rect')
      .attr('x', x(0))
      .attr('y', d => y(d.country))
      .attr('width', d => x(d.importAndExport) - x(0))
      .attr('height', y.bandwidth())
      .attr('fill', 'lightgreen');

  const xAxis = d3.axisTop(x).tickFormat(d3.format('~s'));
  const yAxis = d3.axisLeft(y);

  svg.append('g')
      .attr('transform', `translate(${margin.left})`)
      .call(yAxis)
      .call(g => g.select('.domain').remove());

  svg.append('g')
      .attr('transform', `translate(0, ${margin.top})`)
      .call(xAxis)
      .call(g => g.select('.domain').remove())
    .append('text')
      .attr('fill', 'black')
      .attr('font-family', 'sans-serif')
      .attr('x', width / 2)
      .attr('y', -30)
      .text("Total Trade Amount of Brazil");

  return svg.node();
}


function _50(Legend,d3,tradeDataWithBrazil){return(
Legend(d3.scaleSequentialSqrt([0, d3.max(Object.values(tradeDataWithBrazil).map(d => d.importAndExport))], d3.interpolateGreens), {
  title: "Total Trade Amount of Brazil (USD)",
  tickFormat: "+s"
})
)}

function _51(width,d3,tradeDataWithBrazil,geoJSON)
{
  const height = width;
  
  const svg = d3.create('svg')
    .attr('width', width/2)
    .attr('height', height/2);

  const projection = d3.geoMercator()
    .scale(80)
    .translate([width/4, height/4]);

  const path = d3.geoPath().projection(projection);

  const colorScale = d3.scaleSequentialSqrt()
    .domain([0, d3.max(Object.values(tradeDataWithBrazil).map(d => d.importAndExport))])
    .interpolator(d3.interpolateGreens);

  svg.selectAll('path')
    .data(geoJSON.features)
    .join('path')
    .attr('d', path)
    .attr('fill', d => {
        const country = d.properties.NAME;
        if (country === 'Brazil') return 'black';
        const trade = tradeDataWithBrazil[country];
        if (!trade) return '#ccc';
        else return colorScale(trade.importAndExport);
    })
    .attr('stroke', 'white')
    .attr('stroke-width', 0.5)
    .append("title")
    .text(d => {
      const country = d.properties.NAME;
      const tradeData = tradeDataWithBrazil[country];
      return `${country}: ${tradeData ? tradeData.importAndExport : '0'} USD`
    });

  svg.append("text")
    .attr("x", width / 4)
    .attr("y", 20)
    .attr("text-anchor", "middle")
    .text("Trade Amount of Brazil with each country (for Vis2-Q1)");

  return svg.node();
}


function _52(md){return(
md`As a result, not all countries trade with neighboring countries, and not all countries trade with countries that are father away.`
)}

function _53(md){return(
md`### Q2 (20 points)`
)}

function _54(md){return(
md`Does this pattern differ for imports versus exports? (That is, if a country primarily imports goods from its neighbors, does it also primarily export goods to its neighbors? Or worldwide?) 

**Answer:** **Yes, the pattern of some countries differs for imports versus exports**.

In this question, we take **Chinese import and export trade with other countries** as an example. First we extract all Chinese import and export trade totals from _tradedata_, categorized by different trading countries, and call them _chinaTrade_.`
)}

function _chinaTrade(tradedata)
{
  let chinaTrade = {};
  
  let countryNameMapping = {
    "USA": "United States of America",
    "Rep. of Korea": "South Korea",
    "Other Asia, nes": "Taiwan",
    "China, Hong Kong SAR": "Hong Kong",
    "Russian Federation": "Russia",
    "China, Macao SAR": "Macao",
    "Türkiye": "Turkey",
    "Viet Nam": "Vietnam",
    "Brunei Darussalam": "Brunei",
    "Sudan (...2011)": "S. Sudan",
    "Côte d'Ivoire": "CÃ´te d'Ivoire",
    "Bolivia (Plurinational State of)": "Bolivia",
    "State of Palestine": "Palestine",
    "United Rep. of Tanzania": "Tanzania",
    "Dem. Rep. of the Congo": "Dem. Rep. Congo",
    "Lao People's Dem. Rep.": "Laos",
    "North Macedonia": "Macedonia",
  };
  
  const data = tradedata.filter(d => d.Reporter === "China");
  let totalImport = 0;
  let totalExport = 0;

  data.forEach(d => {
    let country = d.Partner;
    if (countryNameMapping[country]) country = countryNameMapping[country];
    let value = parseFloat(d.Value_USD);

    if (!chinaTrade[country]) {
      chinaTrade[country] = { 
        country: "",
        geoName: "",
        import: 0, 
        export: 0 
      };
    }

    chinaTrade[country].country = d.Partner;
    chinaTrade[country].geoName = country;
    if (d.ImportOrExport === 'Import') {
      chinaTrade[country].import += value;
      totalImport += value;
    }
    else {
      chinaTrade[country].export += value;
      totalExport += value;
    }
  });

  Object.values(chinaTrade).forEach(country => {
    country.importPercentage = country.import / totalImport;
    country.exportPercentage = country.export / totalExport;
  }); 
  return chinaTrade;
}


function _56(md){return(
md`We first sort _chinaTrade_ based on exports and imports with different countries, and get two arrays _chinaTradeSortedByExport_ and _chinaTradeSortedByImport_.`
)}

function _chinaTradeSortedByExport(chinaTrade){return(
Object.fromEntries(Object.entries(chinaTrade)
    .sort((a, b) => b[1].export - a[1].export)
    .slice(0, 30)
    .map(([key, value]) => [key, { 
      country: value.country, 
      geoName: value.geoName, 
      import: value.import, 
      export: value.export, 
      importPercentage: value.importPercentage,
      exportPercentage: value.exportPercentage
    }
  ]))
)}

function _chinaTradeSortedByImport(chinaTrade){return(
Object.fromEntries(Object.entries(chinaTrade)
    .sort((a, b) => b[1].import - a[1].import)
    .slice(0, 30)
    .map(([key, value]) => [key, { 
      country: value.country, 
      geoName: value.geoName, 
      import: value.import, 
      export: value.export, 
      importPercentage: value.importPercentage,
      exportPercentage: value.exportPercentage
    }
  ]))
)}

function _59(md){return(
md`Next, we draw **two diverging bar charts**, as shown in the figure below. For the diverging bar chart, we fix the y-axis in the middle, with exports (marked in Red) on the left side of the y-axis and imports (marked in Blue) on the right side.

The reason for this chart is that **we need to determine whether China's import and export ratios for different countries match**. For example, if we know that China exports to various countries around the world, it is easy to look at the proportion of imports from these countries in the diverging bar chart, because each line corresponds to the proportion of exports (left) and imports (right) from China to one of these countries or regions.

From the two Diverging bar charts (the first is sorted by exports and the second is sorted by imports). It can be seen that **China relies mainly on neighboring countries and regions (e.g., Japan, South Korea, and Taiwan), but exports to various countries and regions around the world (e.g., the United States, Hong Kong, and Japan).** Specifically, while China exports about 15% to Hong Kong, it imports less than 1% from Hong Kong.`
)}

function _60(Swatches,d3){return(
Swatches(d3.scaleOrdinal(["Export", "Import"], ["rgba(255, 0, 0, 0.3)", "rgba(0, 0, 255, 0.3)"]))
)}

function _61(chinaTradeSortedByExport,d3,html)
{
  let svgWidth = 900;
  let svgHeight = 600;
  let margin = { top: 60, right: 20, bottom: 40, left: 40 };
  let width = svgWidth - margin.left - margin.right;
  let height = svgHeight - margin.top - margin.bottom;
  const trade = chinaTradeSortedByExport;

  let exportX = d3.scaleLinear()
    .domain([0, d3.max(Object.values(trade), d => d.exportPercentage)])
    .range([width / 2, 0]);

  let importX =  d3.scaleLinear()
    .domain([0, d3.max(Object.values(trade), d => d.importPercentage)])
    .range([0, width / 2]);
  
  let y = d3.scaleBand()
    .domain(Object.keys(trade))
    .range([0, height])
    .padding(0.1);
  
  let svg = d3.select(html`<svg width="${svgWidth}" height="${svgHeight}"></svg>`);
  
  svg.append("g")
    .attr("transform", `translate(${margin.left + width/2}, ${margin.top})`)
    .call(d3.axisLeft(y));
  
  svg.append("g")
    .attr("transform", `translate(${margin.left}, ${margin.top})`)
    .selectAll(".export-bar")
    .data(Object.entries(trade))
    .join("rect")
    .attr("class", "export-bar")
    .attr("x", d => exportX(d[1].exportPercentage))
    .attr("y", d => y(d[0]))
    .attr("width", d => width/2-exportX(d[1].exportPercentage))
    .attr("height", y.bandwidth())
    .attr("fill", "rgba(255, 0, 0, 0.3)");
  
  svg.append("g")
    .attr("transform", `translate(${margin.left + width / 2}, ${margin.top})`)
    .selectAll(".import-bar")
    .data(Object.entries(trade))
    .join("rect")
    .attr("class", "import-bar")
    .attr("x", d => 0)
    .attr("y", d => y(d[0]))
    .attr("width", d => importX(d[1].importPercentage))
    .attr("height", y.bandwidth())
    .attr("fill", "rgba(0, 0, 255, 0.3)");
  
  svg.append("g")
    .attr("transform", `translate(${margin.left + width / 2}, ${margin.top})`)
    .call(d3.axisTop(importX).ticks(5).tickFormat(d3.format(".0%")));

  svg.append("g")
    .attr("transform", `translate(${margin.left}, ${margin.top})`)
    .call(d3.axisTop(exportX).ticks(5).tickFormat(d3.format(".0%")));
  
  svg.append("text")
    .attr("x", svgWidth / 2)
    .attr("y", margin.top / 2)
    .attr("text-anchor", "middle")
    .text("China Imports and Exports sorted by export (for Vis2-Q2)");
  
  return svg.node();
}


function _62(Swatches,d3){return(
Swatches(d3.scaleOrdinal(["Export", "Import"], ["rgba(255, 0, 0, 0.3)", "rgba(0, 0, 255, 0.3)"]))
)}

function _63(chinaTradeSortedByImport,d3,html)
{
  let svgWidth = 900;
  let svgHeight = 600;
  let margin = { top: 60, right: 20, bottom: 40, left: 40 };
  let width = svgWidth - margin.left - margin.right;
  let height = svgHeight - margin.top - margin.bottom;
  const trade = chinaTradeSortedByImport;

  let exportX = d3.scaleLinear()
    .domain([0, d3.max(Object.values(trade), d => d.exportPercentage)])
    .range([width / 2, 0]);

  let importX =  d3.scaleLinear()
    .domain([0, d3.max(Object.values(trade), d => d.importPercentage)])
    .range([0, width / 2]);
  
  let y = d3.scaleBand()
    .domain(Object.keys(trade))
    .range([0, height])
    .padding(0.1);
  
  let svg = d3.select(html`<svg width="${svgWidth}" height="${svgHeight}"></svg>`);
  
  svg.append("g")
    .attr("transform", `translate(${margin.left + width/2}, ${margin.top})`)
    .call(d3.axisLeft(y));
  
  svg.append("g")
    .attr("transform", `translate(${margin.left}, ${margin.top})`)
    .selectAll(".export-bar")
    .data(Object.entries(trade))
    .join("rect")
    .attr("class", "export-bar")
    .attr("x", d => exportX(d[1].exportPercentage))
    .attr("y", d => y(d[0]))
    .attr("width", d => width/2-exportX(d[1].exportPercentage))
    .attr("height", y.bandwidth())
    .attr("fill", "rgba(255, 0, 0, 0.3)");
  
  svg.append("g")
    .attr("transform", `translate(${margin.left + width / 2}, ${margin.top})`)
    .selectAll(".import-bar")
    .data(Object.entries(trade))
    .join("rect")
    .attr("class", "import-bar")
    .attr("x", d => 0)
    .attr("y", d => y(d[0]))
    .attr("width", d => importX(d[1].importPercentage))
    .attr("height", y.bandwidth())
    .attr("fill", "rgba(0, 0, 255, 0.3)");
  
  svg.append("g")
    .attr("transform", `translate(${margin.left + width / 2}, ${margin.top})`)
    .call(d3.axisTop(importX).ticks(5).tickFormat(d3.format(".0%")));

  svg.append("g")
    .attr("transform", `translate(${margin.left}, ${margin.top})`)
    .call(d3.axisTop(exportX).ticks(5).tickFormat(d3.format(".0%")));
  
  svg.append("text")
    .attr("x", svgWidth / 2)
    .attr("y", margin.top / 2)
    .attr("text-anchor", "middle")
    .text("China Imports and Exports sorted by import (for Vis2-Q2)");
  
  return svg.node();
}


function _64(md){return(
md`Thus, the pattern of some countries differs for imports versus exports.`
)}

function _65(md){return(
md`---

## Visualization 3`
)}

function _66(md){return(
md`### Q1 (15 points)`
)}

function _67(md){return(
md`(1) What are the top 5 types of traded goods (imports or exports)?

**Answer:** The top-5 types of traded goods are:

- **Machinery, appliances, and tools**
- **Minerals, stone, and their products**
- **Vehicles and their parts**
- **Metals**
- **Chemicals and pharmaceuticals**

In this question, we aggregate the _tradedata_ by item type (_description_) to get the array _tradeDataGroupByDescription_. With this array we can get the total amount of traded goods and draw a **bar chart** to know the top-5 types of traded goods are _Machinery, appliances, and tools_, _Minerals, stone, and their products_, _Vehicles and their parts_, _Metals_ and _Chemicals and pharmaceuticals_.`
)}

function _tradeDataGroupByDescription(tradedata){return(
tradedata.reduce((acc, d) => {
    const description = d.Description;
    if (!acc[description]) {
      acc[description] = [];
    }
    acc[description].push(d);
    return acc;
  }, {})
)}

function _tradeGoods(tradeDataGroupByDescription){return(
Object.keys(tradeDataGroupByDescription).map(description => {
  let items = tradeDataGroupByDescription[description];

  let total = items.reduce((sum, item) => {
    return sum + parseFloat(item.Value_USD);
  }, 0);

  let countrySummary = items.reduce((acc, item) => {
    const country = item.Reporter;
    if (!acc[country]) {
      acc[country] = {
        import: 0, 
        export: 0 
      };
    }

    if (item.ImportOrExport === 'Import') {
      acc[country].import += parseFloat(item.Value_USD);
    } else {
      acc[country].export += parseFloat(item.Value_USD);
    }

    return acc;
  }, {});

  return {
    description: description,
    total: total,
    countryDetails: Object.entries(countrySummary).map(([country, value]) => ({
      country: country,
      import: value.import,
      export: value.export,
    }))
  };
})
)}

function _70(width,tradeGoods,d3)
{
  const height = width/2;
  const margin = { top: 60, right: 30, bottom: 40, left: 200 };

  const sortedtradeGoods = tradeGoods.sort((a, b) => b.total - a.total);

  const svg = d3.create('svg')
    .attr('width', width)
    .attr('height', height);

  const x = d3.scaleLinear()
    .domain([0, d3.max(Object.values(sortedtradeGoods), d => d.total)])
    .range([margin.left, width - margin.right]);

  const y = d3.scaleBand()
    .domain(Object.values(sortedtradeGoods).map(d => d.description))
    .range([margin.top, height - margin.bottom])
    .paddingInner(0.2)
    .paddingOuter(0.5);

  svg.append('g')
    .selectAll('rect')
    .data(Object.values(sortedtradeGoods))
    .join('rect')
      .attr('x', x(0))
      .attr('y', d => y(d.description))
      .attr('width', d => x(d.total) - x(0))
      .attr('height', y.bandwidth())
      .attr('fill', 'steelblue');

  const xAxis = d3.axisTop(x).tickFormat(d3.format('~s'));
  const yAxis = d3.axisLeft(y);

  svg.append('g')
      .attr('transform', `translate(${margin.left})`)
      .call(yAxis)
      .call(g => g.select('.domain').remove());

  svg.append('g')
      .attr('transform', `translate(0, ${margin.top})`)
      .call(xAxis)
      .call(g => g.select('.domain').remove())
    .append('text')
      .attr('fill', 'black')
      .attr('font-family', 'sans-serif')
      .attr('x', width / 2)
      .attr('y', -30)
      .text("USD");

  svg.append("text")
    .attr("x", width / 4)
    .attr("y", 15)
    .attr("text-anchor", "middle")
    .text("Total Goods Transactions (for Vis3-Q1(1))");

  return svg.node();
}


function _71(tradeGoods){return(
tradeGoods.sort((a, b) => b.total - a.total).slice(0, 5).map(d => d.description)
)}

function _72(md){return(
md`(2) Which countries are the primary exporters of these goods?

**Answer:** The primary exporters of these goods are **China, USA, Germany, Japan, Rep. of Korea, Hong Kong, United Kingdom, Canada, Mexico, France** (top-10) and etc.

`
)}

function _73(md){return(
md`In Vis3 Q1(1), we have got the top-5 types of traded goods. So we can filter out all the trade records related to these goods. For each of these goods, we have added a nested array called _countryDetails_ indicating the amount of trade for each country and region for that goods. The final result is the array _top5Goods_.`
)}

function _top5Goods(tradeGoods){return(
tradeGoods.sort((a, b) => b.total - a.total).slice(0, 5)
)}

function _75(md){return(
md`After that, we transform _top5Goods_. Specifically, we categorize these goods by country and count the exports of the top-5 types of traded goods for each country to get the array _countryExports_.`
)}

function _countryExports(top5Goods)
{
  let countryExports = {};

  let countryNameMapping = {
    "USA": "United States of America",
    "Rep. of Korea": "South Korea",
    "Other Asia, nes": "Taiwan",
    "China, Hong Kong SAR": "Hong Kong",
    "Russian Federation": "Russia",
    "China, Macao SAR": "Macao",
    "Türkiye": "Turkey",
    "Viet Nam": "Vietnam",
    "Brunei Darussalam": "Brunei",
    "Sudan (...2011)": "S. Sudan",
    "Côte d'Ivoire": "CÃ´te d'Ivoire",
    "Bolivia (Plurinational State of)": "Bolivia",
    "State of Palestine": "Palestine",
    "United Rep. of Tanzania": "Tanzania",
    "Dem. Rep. of the Congo": "Dem. Rep. Congo",
    "Lao People's Dem. Rep.": "Laos",
    "North Macedonia": "Macedonia",
  };

  top5Goods.forEach(d => {
    d.countryDetails.forEach(item => {
      let country = item.country;
      if (countryNameMapping[country]) country = countryNameMapping[country];
      const exp = parseFloat(item.export);
      if (!countryExports[country]) {
        countryExports[country] = {
          country: "",
          geoName: "",
          amount: 0
        }
      }
      countryExports[country].country = item.country;
      countryExports[country].geoName = country;
      countryExports[country].amount += exp;
    })
  });

  return countryExports;
}


function _77(md){return(
md`Using _countryExports_, we then plot a **bar chart** depicting each country's exports of these goods. In this chart, we only list the top-10 countries and regions.`
)}

function _78(width,countryExports,d3)
{
  const height = width/2;
  const margin = { top: 60, right: 30, bottom: 40, left: 150 };

  const sortedCountryExports = Object.values(countryExports).sort((a, b) => b.amount - a.amount).slice(0, 10);

  const svg = d3.create('svg')
    .attr('width', width)
    .attr('height', height);

  const x = d3.scaleLinear()
    .domain([0, d3.max(Object.values(sortedCountryExports), d => d.amount)])
    .range([margin.left, width - margin.right]);

  const y = d3.scaleBand()
    .domain(Object.values(sortedCountryExports).map(d => d.country))
    .range([margin.top, height - margin.bottom])
    .paddingInner(0.2)
    .paddingOuter(0.5);

  svg.append('g')
    .selectAll('rect')
    .data(Object.values(sortedCountryExports))
    .join('rect')
      .attr('x', x(0))
      .attr('y', d => y(d.country))
      .attr('width', d => x(d.amount) - x(0))
      .attr('height', y.bandwidth())
      .attr('fill', 'steelblue');

  const xAxis = d3.axisTop(x).tickFormat(d3.format('~s'));
  const yAxis = d3.axisLeft(y);

  svg.append('g')
      .attr('transform', `translate(${margin.left})`)
      .call(yAxis)
      .call(g => g.select('.domain').remove());

  svg.append('g')
      .attr('transform', `translate(0, ${margin.top})`)
      .call(xAxis)
      .call(g => g.select('.domain').remove())
    .append('text')
      .attr('fill', 'black')
      .attr('font-family', 'sans-serif')
      .attr('x', width / 2)
      .attr('y', -30)
      .text("USD");

  svg.append("text")
    .attr("x", width / 3)
    .attr("y", 15)
    .attr("text-anchor", "middle")
    .text("Primary Exporters of top-5 types of Traded Goods (for Vis3-Q1(2))");

  return svg.node();
}


function _79(countryExports){return(
Object.values(countryExports).sort((a, b) => b.amount - a.amount).slice(0, 10).map(d => d.country)
)}

function _80(md){return(
md`(3) Are they all in the same geographic region, or are they distributed around the world?

**Answer:** **They are distributed around the world.**

In the previous problem, we got the primary exporters of these goods, so we plotted a **map** with each country's exports marked in blue and **the primary exporters marked with blue circles** to clearly see if they are clustered together or spread out.

The map shows that primary exporters are distributed around the world.`
)}

function _81(Legend,d3,countryExports){return(
Legend(d3.scaleSequentialSqrt([0, d3.max(Object.values(countryExports).map(d => d.amount))], d3.interpolateBlues), {
  title: "Total Export Amount of Top-5 Traded Goods (USD)",
  tickFormat: "+s"
})
)}

function _82(width,d3,countryExports,geoJSON)
{
  const height = width;
  
  const svg = d3.create('svg')
    .attr('width', width/2)
    .attr('height', height/2);

  const projection = d3.geoMercator()
    .scale(80)
    .translate([width/4, height/4]);

  const path = d3.geoPath().projection(projection);

  const sortedCountryExports = Object.values(countryExports).sort((a, b) => b.amount - a.amount).slice(0, 10);

  const importerCoordinates = sortedCountryExports.map(country => {
    const feature = geoJSON.features.find(f => f.properties.NAME === country.geoName);
    const centroid = d3.geoCentroid(feature);
    return centroid;
  });

  const colorScale = d3.scaleSequentialSqrt()
    .domain(d3.extent(Object.values(countryExports).map(d => d.amount)))
    .interpolator(d3.interpolateBlues);

  svg.selectAll('path')
    .data(geoJSON.features)
    .join('path')
    .attr('d', path)
    .attr('fill', d => {
        const country = d.properties.NAME;
        const trade = countryExports[country];
        if (!trade) return '#ccc';
        else return colorScale(trade.amount);
    })
    .attr('stroke', 'white')
    .attr('stroke-width', 0.5)
    .append("title")
    .text(d => {
      const country = d.properties.NAME;
      const tradeData = countryExports[country];
      return `${country}: ${tradeData ? tradeData.amount : 'N/A'} USD`
    });

  svg.selectAll("circle")
    .data(importerCoordinates)
    .join("circle")
    .attr("cx", d => projection(d)[0])
    .attr("cy", d => projection(d)[1])
    .attr("r", 20)
    .attr("fill", "blue")
    .attr("stroke", "black")
    .attr("stroke-width", 1)
    .attr("opacity", 0.5);

  svg.append("text")
    .attr("x", width / 4)
    .attr("y", 20)
    .attr("text-anchor", "middle")
    .text("Trade Amount of Top-5 Traded Goods (for Vis3-Q1(3))");

  return svg.node();
}


function _83(md){return(
md`### Q2 (15 points)`
)}

function _84(md){return(
md`Are there countries that tend to receive more of certain types of goods than others? (Note: it would be more interesting to look at the top 5 types of goods locally, for each individual country, but visualizing the results may be even harder. If you want to try out a solution for this harder case it would be nice to see it). 

**Answer:** **Yes**. Some countries and regions tend to receive more of certain types of goods than others.

In that problem, we aggregated _tradedata_ by different countries and counted the import amount of each country for different goods in the internal array. We got the array _tradeGoodsGroupByCountries_.`
)}

function _tradeGoodsGroupByCountries(tradeGoods)
{
  let countryImports = {};

  tradeGoods.forEach(d => {
    d.countryDetails.forEach(item => {
      const country = item.country;
      const importAmount = item.import;
      if (!countryImports[country]) {
        countryImports[country] = { 
          country: "",
          totalImport: 0, 
          goods: [] 
        };
      }
      countryImports[country].country = country;
      countryImports[country].totalImport += importAmount;
      countryImports[country].goods.push({
        description: d.description,
        import: importAmount
      });
    });
  });

  return countryImports;
}


function _tidy(tradeGoodsGroupByCountries)
{
  let transformedData = [];

  const selectedCountries = ["China", "USA", "Germany", "Japan", "Rep. of Korea", "China, Hong Kong SAR", "United Kingdom", "Canada", "Mexico", "France"];

  Object.keys(tradeGoodsGroupByCountries).forEach(country => {
    if (selectedCountries.includes(country)) {
      const goods = tradeGoodsGroupByCountries[country].goods;
      goods.forEach(good => {
        transformedData.push({
          country: country,
          description: good.description,
          import: good.import
        });
      });
    }
  });
  return transformedData;
}


function _87(md){return(
md`We choose to use **normalized stacked bar chart** for judgment in that problem. Normalized stacked bar chart makes the total length of each bar consistent, and each part of each bar (each goods type) takes up a corresponding percentage. This means that **it is straightforward to see what proportion of each country's total imports is accounted for by the different types**. Through normalization, each country's trade structure can be compared on the same scale, giving a clear picture of the proportion of each country's imports. In addition, **such a chart provides a clear view of the share of different countries in their imports of traded goods, and in particular, which item types stand out in the imports of certain countries**.

In this chart, we take out some countries and regions (e.g., the United States, China, etc.) to view their import ratios for different commodities.`
)}

function _88(Swatches,d3,tradeGoods){return(
Swatches(d3.scaleOrdinal(tradeGoods.map(d => d.description), d3.schemeSet1), {
  columns: "180px"
})
)}

function _89(Plot,tradeGoods,tidy){return(
Plot.plot({
  x: { axis: "top", percent: true },
  marginLeft: 130,
  color: { 
    scheme: "Set1",
    domain: tradeGoods.map(d => d.description)
  },
  marks: [
    Plot.barX(tidy, {
      offset: "normalize",
      y: "country",
      x: "import",
      fill: "description",
    })
  ]
})
)}

function _90(md){return(
md`We find that **Hong Kong and Mexico import significantly more Machinery, appliances, and tools (the red bar) than other goods.** In addition, other countries also imported more machinery, appliances, and tools than other goods to some extent.

As a result, there are some countries and regions which tend to receive more of certain types of goods than others.`
)}

function _91(md){return(
md`-----------------
## Appendix`
)}

function _d3(require){return(
require('d3@7')
)}

function _googleSheetCsvUrl(){return(
'https://docs.google.com/spreadsheets/d/1XM-sE3HuHRLwIalSSSCOw8G-0E3VgCcYG5qqB1mBRd0/gviz/tq?tqx=out:csv'
)}

export default function define(runtime, observer) {
  const main = runtime.module();
  function toString() { return this.url; }
  const fileAttachments = new Map([
    ["countries-50m.json", {url: new URL("./files/55260abbc777c0a3b8fed19f3929dd822fef9d5118b53b76b2176d20782910e599eac919999ea8ee85a60b783fd37082574f6591fd46c0d70ddf9b00df71ce27.json", import.meta.url), mimeType: "application/json", toString}]
  ]);
  main.builtin("FileAttachment", runtime.fileAttachments(name => fileAttachments.get(name)));
  main.variable(observer()).define(["md"], _1);
  main.variable(observer()).define(["md"], _2);
  main.variable(observer()).define(["Inputs","tradedata"], _3);
  main.variable(observer("tradedata")).define("tradedata", ["d3","googleSheetCsvUrl"], _tradedata);
  main.variable(observer()).define(["md"], _5);
  main.variable(observer("geoJSON")).define("geoJSON", ["FileAttachment"], _geoJSON);
  main.variable(observer()).define(["md"], _7);
  main.variable(observer()).define(["md"], _8);
  main.variable(observer()).define(["md"], _9);
  const child1 = runtime.module(define1);
  main.import("legend", child1);
  main.import("swatches", child1);
  main.import("Legend", child1);
  main.import("Swatches", child1);
  main.variable(observer()).define(["md"], _11);
  main.variable(observer()).define(["md"], _12);
  main.variable(observer()).define(["width"], _13);
  main.variable(observer()).define(["md"], _14);
  main.variable(observer()).define(["md"], _15);
  main.variable(observer("countryTrade")).define("countryTrade", ["tradedata"], _countryTrade);
  main.variable(observer("extent")).define("extent", ["d3","countryTrade"], _extent);
  main.variable(observer()).define(["md"], _18);
  main.variable(observer()).define(["md"], _19);
  main.variable(observer()).define(["Legend","d3"], _20);
  main.variable(observer()).define(["width","d3","geoJSON","countryTrade"], _21);
  main.variable(observer()).define(["md"], _22);
  main.variable(observer("countriesWithMoreImports")).define("countriesWithMoreImports", ["countryTrade"], _countriesWithMoreImports);
  main.variable(observer()).define(["md"], _24);
  main.variable(observer("countriesWithMoreExports")).define("countriesWithMoreExports", ["countryTrade"], _countriesWithMoreExports);
  main.variable(observer()).define(["md"], _26);
  main.variable(observer()).define(["md"], _27);
  main.variable(observer("topImporters")).define("topImporters", ["countryTrade"], _topImporters);
  main.variable(observer()).define(["Legend","d3","countryTrade"], _29);
  main.variable(observer()).define(["width","d3","topImporters","geoJSON","countryTrade"], _30);
  main.variable(observer()).define(["md"], _31);
  main.variable(observer("topExporters")).define("topExporters", ["countryTrade"], _topExporters);
  main.variable(observer()).define(["Legend","d3","countryTrade"], _33);
  main.variable(observer()).define(["width","d3","topExporters","geoJSON","countryTrade"], _34);
  main.variable(observer()).define(["md"], _35);
  main.variable(observer()).define(["md"], _36);
  main.variable(observer()).define(["Legend","d3"], _37);
  main.variable(observer()).define(["width","d3","geoJSON","countryTrade"], _38);
  main.variable(observer()).define(["md"], _39);
  main.variable(observer()).define(["md"], _40);
  main.variable(observer()).define(["md"], _41);
  main.variable(observer()).define(["md"], _42);
  main.variable(observer("tradeDataWithFrance")).define("tradeDataWithFrance", ["tradedata","d3"], _tradeDataWithFrance);
  main.variable(observer()).define(["width","tradeDataWithFrance","d3"], _44);
  main.variable(observer()).define(["Legend","d3","tradeDataWithFrance"], _45);
  main.variable(observer()).define(["width","d3","tradeDataWithFrance","geoJSON"], _46);
  main.variable(observer()).define(["md"], _47);
  main.variable(observer("tradeDataWithBrazil")).define("tradeDataWithBrazil", ["tradedata","d3"], _tradeDataWithBrazil);
  main.variable(observer()).define(["width","tradeDataWithBrazil","d3"], _49);
  main.variable(observer()).define(["Legend","d3","tradeDataWithBrazil"], _50);
  main.variable(observer()).define(["width","d3","tradeDataWithBrazil","geoJSON"], _51);
  main.variable(observer()).define(["md"], _52);
  main.variable(observer()).define(["md"], _53);
  main.variable(observer()).define(["md"], _54);
  main.variable(observer("chinaTrade")).define("chinaTrade", ["tradedata"], _chinaTrade);
  main.variable(observer()).define(["md"], _56);
  main.variable(observer("chinaTradeSortedByExport")).define("chinaTradeSortedByExport", ["chinaTrade"], _chinaTradeSortedByExport);
  main.variable(observer("chinaTradeSortedByImport")).define("chinaTradeSortedByImport", ["chinaTrade"], _chinaTradeSortedByImport);
  main.variable(observer()).define(["md"], _59);
  main.variable(observer()).define(["Swatches","d3"], _60);
  main.variable(observer()).define(["chinaTradeSortedByExport","d3","html"], _61);
  main.variable(observer()).define(["Swatches","d3"], _62);
  main.variable(observer()).define(["chinaTradeSortedByImport","d3","html"], _63);
  main.variable(observer()).define(["md"], _64);
  main.variable(observer()).define(["md"], _65);
  main.variable(observer()).define(["md"], _66);
  main.variable(observer()).define(["md"], _67);
  main.variable(observer("tradeDataGroupByDescription")).define("tradeDataGroupByDescription", ["tradedata"], _tradeDataGroupByDescription);
  main.variable(observer("tradeGoods")).define("tradeGoods", ["tradeDataGroupByDescription"], _tradeGoods);
  main.variable(observer()).define(["width","tradeGoods","d3"], _70);
  main.variable(observer()).define(["tradeGoods"], _71);
  main.variable(observer()).define(["md"], _72);
  main.variable(observer()).define(["md"], _73);
  main.variable(observer("top5Goods")).define("top5Goods", ["tradeGoods"], _top5Goods);
  main.variable(observer()).define(["md"], _75);
  main.variable(observer("countryExports")).define("countryExports", ["top5Goods"], _countryExports);
  main.variable(observer()).define(["md"], _77);
  main.variable(observer()).define(["width","countryExports","d3"], _78);
  main.variable(observer()).define(["countryExports"], _79);
  main.variable(observer()).define(["md"], _80);
  main.variable(observer()).define(["Legend","d3","countryExports"], _81);
  main.variable(observer()).define(["width","d3","countryExports","geoJSON"], _82);
  main.variable(observer()).define(["md"], _83);
  main.variable(observer()).define(["md"], _84);
  main.variable(observer("tradeGoodsGroupByCountries")).define("tradeGoodsGroupByCountries", ["tradeGoods"], _tradeGoodsGroupByCountries);
  main.variable(observer("tidy")).define("tidy", ["tradeGoodsGroupByCountries"], _tidy);
  main.variable(observer()).define(["md"], _87);
  main.variable(observer()).define(["Swatches","d3","tradeGoods"], _88);
  main.variable(observer()).define(["Plot","tradeGoods","tidy"], _89);
  main.variable(observer()).define(["md"], _90);
  main.variable(observer()).define(["md"], _91);
  main.variable(observer("d3")).define("d3", ["require"], _d3);
  main.variable(observer("googleSheetCsvUrl")).define("googleSheetCsvUrl", _googleSheetCsvUrl);
  return main;
}
